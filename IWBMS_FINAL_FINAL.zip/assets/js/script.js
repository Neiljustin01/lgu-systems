// Mobile sidebar toggle
document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.getElementById('sidebarToggle');
  var sidebar = document.querySelector('.sidebar');
  var overlay = document.getElementById('sidebarOverlay');

  function openSidebar() {
    if (sidebar) sidebar.classList.add('open');
    if (overlay) overlay.classList.add('show');
  }
  function closeSidebar() {
    if (sidebar) sidebar.classList.remove('open');
    if (overlay) overlay.classList.remove('show');
  }

  if (toggle && sidebar) {
    toggle.addEventListener('click', function () {
      sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
    });
  }
  // Tapping the dark backdrop closes the sidebar
  if (overlay) {
    overlay.addEventListener('click', closeSidebar);
  }
  // Closing the sidebar automatically after picking a nav link on mobile
  if (sidebar) {
    sidebar.querySelectorAll('a.nav-link').forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.innerWidth <= 880) closeSidebar();
      });
    });
  }
  // Collapse the mobile sidebar if the viewport is resized back to desktop width
  window.addEventListener('resize', function () {
    if (window.innerWidth > 880) closeSidebar();
  });

  // Generic "confirm before delete" for any link/button with data-confirm
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (e) {
      if (!confirm(el.getAttribute('data-confirm'))) {
        e.preventDefault();
      }
    });
  });

  // Any link marked data-post gets turned into a real POST submission
  // (with the CSRF token attached) instead of a plain GET navigation.
  // Used for delete/toggle actions that used to be "?id=123" links.
  // Combine with data-confirm on the same element for a confirmation dialog
  // — that handler runs first (it's registered above) and can cancel the
  // click before this one ever builds/submits the form.
  var csrfMeta = document.querySelector('meta[name="csrf-token"]');
  var csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';
  document.querySelectorAll('a[data-post]').forEach(function (el) {
    el.addEventListener('click', function (e) {
      if (e.defaultPrevented) return; // a data-confirm handler already cancelled it
      e.preventDefault();

      var form = document.createElement('form');
      form.method = 'post';
      form.action = el.getAttribute('href');
      form.style.display = 'none';

      var tokenInput = document.createElement('input');
      tokenInput.type = 'hidden';
      tokenInput.name = 'csrf_token';
      tokenInput.value = csrfToken;
      form.appendChild(tokenInput);

      document.body.appendChild(form);
      form.submit();
    });
  });

  // Alerts: add a dismiss (×) button and auto-hide flash messages after a few seconds
  function dismissAlert(el) {
    el.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    el.style.opacity = '0';
    el.style.transform = 'translateY(-6px)';
    setTimeout(function () { el.remove(); }, 300);
  }
  document.querySelectorAll('.alert').forEach(function (el) {
    var closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'alert-close';
    closeBtn.setAttribute('aria-label', 'Dismiss');
    closeBtn.innerHTML = '&times;';
    closeBtn.addEventListener('click', function () { dismissAlert(el); });
    el.appendChild(closeBtn);
  });
  document.querySelectorAll('.alert[data-autohide]').forEach(function (el) {
    setTimeout(function () { dismissAlert(el); }, 4000);
  });

  // Prevent accidental double-submits (e.g. double-clicking "Generate Bills" or "Save Payment")
  document.querySelectorAll('form').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      var btn = e.submitter || form.querySelector('button[type="submit"], input[type="submit"]');
      if (btn && !btn.disabled) {
        btn.disabled = true;
        btn.style.opacity = '0.7';
        btn.dataset.origHtml = btn.innerHTML;
        btn.innerHTML = '⏳ Please wait…';
        // safety net: re-enable if the page hasn't navigated away after a few seconds
        setTimeout(function () {
          if (btn.disabled) {
            btn.disabled = false;
            btn.style.opacity = '';
            if (btn.dataset.origHtml) btn.innerHTML = btn.dataset.origHtml;
          }
        }, 8000);
      }
    });
  });

  // Auto-compute consumption preview on reading forms
  var prevInput = document.getElementById('previous_reading');
  var currInput = document.getElementById('current_reading');
  var consumptionPreview = document.getElementById('consumptionPreview');
  function updateConsumption() {
    if (!prevInput || !currInput || !consumptionPreview) return;
    var prev = parseFloat(prevInput.value) || 0;
    var curr = parseFloat(currInput.value) || 0;
    var diff = curr - prev;
    consumptionPreview.textContent = (diff >= 0 ? diff : 0).toFixed(2) + ' m\u00B3';
    consumptionPreview.style.color = diff < 0 ? '#c23b3b' : '';
  }
  if (prevInput && currInput) {
    prevInput.addEventListener('input', updateConsumption);
    currInput.addEventListener('input', updateConsumption);
    updateConsumption();
  }

  // Add/remove bracket rows on the Rates & Connection Types form
  var tierWrap = document.getElementById('tier-rows');
  var addTierBtn = document.getElementById('add-tier-btn');
  if (tierWrap && addTierBtn) {
    addTierBtn.addEventListener('click', function () {
      var rows = tierWrap.querySelectorAll('.tier-row');
      var clone = rows[rows.length - 1].cloneNode(true);
      clone.querySelectorAll('input').forEach(function (inp) { inp.value = ''; });
      tierWrap.appendChild(clone);
    });
    tierWrap.addEventListener('click', function (e) {
      if (e.target.classList.contains('remove-tier-btn')) {
        var rows = tierWrap.querySelectorAll('.tier-row');
        if (rows.length > 1) {
          e.target.closest('.tier-row').remove();
        } else {
          rows[0].querySelectorAll('input').forEach(function (inp) { inp.value = ''; });
        }
      }
    });
  }

  // Global "/" shortcut: jump straight into this page's search box
  // (every list page uses name="q" for its search field), so a clerk can
  // start typing a name/account number without reaching for the mouse.
  // Ignored while already typing in any field, so it never eats a "/"
  // someone meant to type into an address or remarks box.
  document.addEventListener('keydown', function (e) {
    if (e.key !== '/') return;
    var tag = (e.target.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable) return;
    var searchBox = document.querySelector('input[name="q"]');
    if (searchBox) {
      e.preventDefault();
      searchBox.focus();
      searchBox.select();
    }
  });
});
