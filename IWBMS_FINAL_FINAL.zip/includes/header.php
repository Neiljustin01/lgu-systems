<?php
/**
 * Shared header: opens <html>, renders sidebar + topbar, opens .content
 * Expects (optionally) these variables set by the calling page BEFORE include:
 *   $pageTitle   - string, shown in <title> and topbar
 *   $pageSub     - string, small subtitle under the title
 *   $activeNav   - string key matching one of the nav-link data-nav values
 */
require_once __DIR__ . '/auth.php';

$pageTitle = $pageTitle ?? 'Dashboard';
$pageSub   = $pageSub ?? '';
$activeNav = $activeNav ?? '';
// Optional "back" link, set by the calling page BEFORE include:
//   $backUrl   - string, relative or BASE_URL-prefixed href
//   $backLabel - string, e.g. "Back to Consumers" (defaults to "Back")
$backUrl   = $backUrl ?? '';
$backLabel = $backLabel ?? 'Back';
$systemName = get_setting($pdo, 'system_name', 'Water Billing & Collection System');
$muniName   = get_setting($pdo, 'municipality_name', 'Municipality');

function nav_active($key, $activeNav) {
    return $key === $activeNav ? ' active' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?= h(csrf_token()) ?>">
<title><?= h($pageTitle) ?> · <?= h($systemName) ?></title>
<link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/logo/watersystem.png">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/fonts.css?v=<?= asset_v('assets/css/fonts.css') ?>">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css?v=<?= asset_v('assets/css/style.css') ?>">
</head>
<body>
<div class="app-shell">

  <aside class="sidebar">
    <div class="brand">
      <div class="brand-logos">
        <img src="<?= BASE_URL ?>/assets/logo/seal.png" alt="<?= h($muniName) ?> Seal" class="brand-logo" width="40" height="40">
        <img src="<?= BASE_URL ?>/assets/logo/watersystem.png" alt="<?= h($systemName) ?> Logo" class="brand-logo" width="40" height="40">
      </div>
      <div>
        <p class="brand-title"><?= h($systemName) ?></p>
        <p class="brand-sub"><?= h($muniName) ?></p>
      </div>
    </div>

    <nav>
      <div class="nav-label">Overview</div>
      <a href="<?= BASE_URL ?>/index.php" class="nav-link<?= nav_active('dashboard', $activeNav) ?>">
        <span class="ico">📊</span> Dashboard
      </a>

      <div class="nav-label">Records</div>
      <a href="<?= BASE_URL ?>/consumers/list.php" class="nav-link<?= nav_active('consumers', $activeNav) ?>">
        <span class="ico">👤</span> Consumers
      </a>
      <a href="<?= BASE_URL ?>/readings/grid.php" class="nav-link<?= nav_active('readings', $activeNav) ?>">
        <span class="ico">🧮</span> Meter Readings
      </a>
      <a href="<?= BASE_URL ?>/billing/list.php" class="nav-link<?= nav_active('billing', $activeNav) ?>">
        <span class="ico">🧾</span> Billing
      </a>

      <div class="nav-label">Reports</div>
      <a href="<?= BASE_URL ?>/reports/monthly_summary.php" class="nav-link<?= nav_active('summary', $activeNav) ?>">
        <span class="ico">📅</span> Monthly Summary
      </a>
      <a href="<?= BASE_URL ?>/reports/consumer_statement.php" class="nav-link<?= nav_active('statement', $activeNav) ?>">
        <span class="ico">📄</span> Consumer Statement
      </a>
      <a href="<?= BASE_URL ?>/reports/export.php" class="nav-link<?= nav_active('export', $activeNav) ?>">
        <span class="ico">📦</span> Export &amp; Backup
      </a>

      <div class="nav-label">System</div>
      <a href="<?= BASE_URL ?>/settings/meter_readers.php" class="nav-link<?= nav_active('meter_readers', $activeNav) ?>">
        <span class="ico">🚶</span> Meter Readers
      </a>
      <a href="<?= BASE_URL ?>/settings/rates.php" class="nav-link<?= nav_active('rates', $activeNav) ?>">
        <span class="ico">💲</span> Rates &amp; Types
      </a>
      <a href="<?= BASE_URL ?>/settings/general.php" class="nav-link<?= nav_active('settings', $activeNav) ?>">
        <span class="ico">⚙️</span> General Settings
      </a>
    </nav>

    <div class="sidebar-footer">
      Logged in as <strong style="color:#fff;"><?= h($_SESSION['admin_name'] ?? 'Admin') ?></strong><br>
      <a href="<?= BASE_URL ?>/logout.php" style="color:#9fcfe8;">Log out</a>
    </div>
  </aside>

  <div class="sidebar-overlay no-print" id="sidebarOverlay"></div>

  <div class="main">
    <div class="topbar">
      <div style="display:flex; align-items:center;">
        <button id="sidebarToggle" class="btn btn-outline btn-sm no-print" aria-label="Toggle menu" title="Toggle menu">☰</button>
        <?php if ($backUrl): ?>
          <a href="<?= h($backUrl) ?>" class="btn btn-outline btn-sm no-print back-btn" title="<?= h($backLabel) ?>">← <?= h($backLabel) ?></a>
        <?php endif; ?>
        <div>
          <h1><?= h($pageTitle) ?></h1>
          <?php if ($pageSub): ?><div class="page-sub"><?= h($pageSub) ?></div><?php endif; ?>
        </div>
      </div>
      <div class="user-chip">
        <span><?= date('l, F j, Y') ?></span>
        <div class="avatar"><?= strtoupper(substr($_SESSION['admin_name'] ?? 'A', 0, 1)) ?></div>
      </div>
    </div>

    <div class="content">
      <?php $flash = get_flash(); if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] === 'error' ? 'danger' : $flash['type'] ?>" data-autohide>
          <?= h($flash['message']) ?>
        </div>
      <?php endif; ?>
