<?php
/**
 * Session bootstrap + login guard.
 * Include this (via header.php) at the very top of every protected page.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

// Figure out how many folders deep the current script is, so the
// redirect back to login.php works no matter which page triggered it.
function base_url()
{
    // Path of this includes/ folder relative to document root, minus "includes"
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
    $root   = str_replace('\\', '/', dirname(dirname(__FILE__)));
    // Determine the web-accessible base path of the project
    $docRoot = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'] ?? '');
    $base = str_replace($docRoot, '', $root);
    return rtrim($base, '/');
}

define('BASE_URL', base_url());

if (empty($_SESSION['admin_id'])) {
    redirect(BASE_URL . '/login.php');
}
