    </div><!-- /.content -->
    <footer class="app-footer no-print">
      <span>&copy; <?= date('Y') ?> <?= h($muniName ?? 'Municipality') ?> Water System. All rights reserved.</span>
      <span class="app-footer-credit">Developed by <strong>Neil Justine Peras</strong></span>
    </footer>
  </div><!-- /.main -->
</div><!-- /.app-shell -->
<script src="<?= BASE_URL ?>/assets/js/script.js?v=<?= asset_v('assets/js/script.js') ?>"></script>
</body>
</html>
