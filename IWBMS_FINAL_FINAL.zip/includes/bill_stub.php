<?php
/**
 * Shared "Statement of Account" stub renderer.
 * ---------------------------------------------------------------
 * This is the small bordered coupon a meter reader hands to each
 * consumer on their monthly round (and that doubles as a
 * disconnection notice) — six of these are printed per A4 sheet, see
 * billing/print_bulk.php + billing/print_bulk_output.php.
 *
 * billing/print.php (the single full-page "Print Bill" reprint used
 * from the Billing list/View pages) has its own larger, plain-language
 * layout instead of this compact stub — it only reuses
 * bill_stub_select_sql() below for the query, not render_bill_stub().
 */

/** CSS for the compact 6-per-sheet stub (billing/print_bulk_output.php). */
function bill_stub_css()
{
    return <<<CSS
    .stub {
      border: 1.8px solid #000;
      padding: 2mm 3mm;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 9px;
      line-height: 1.15;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      background: #fff;
      color: #000;
    }
    .stub table { width: 100%; border-collapse: collapse; table-layout: fixed; margin-bottom: 0.9mm; }
    .stub table td, .stub table th {
      border: 1px solid #000;
      padding: 1.1px 4px;
      vertical-align: middle;
      overflow: hidden;
    }
    .stub .lbl { color: #1a3d8f; font-size: 7px; display: block; line-height: 1.1; }
    .stub .val { font-weight: 700; font-size: 9.4px; line-height: 1.15; }
    .stub-header {
      position: relative;
      text-align: center;
      border-bottom: 1.4px solid #000;
      padding: 0 32px 2px;
      margin-bottom: 2px;
      min-height: 20px;
    }
    .stub-header img {
      position: absolute; top: 50%; transform: translateY(-50%); width: 30px; height: 30px;
      border-radius: 50%; object-fit: cover; background: #fff;
    }
    .stub-header img.stub-logo-left { left: 0; }
    .stub-header img.stub-logo-right { right: 0; }
    .stub-header .muni,
    .stub-header .office,
    .stub-header .addr {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .stub-header .muni { color: #1a3d8f; font-weight: 700; font-size: 10px; line-height: 1.2; }
    .stub-header .office,
    .stub-header .addr { color: #1a3d8f; font-size: 6.3px; line-height: 1.25; }
    .stub-header .title { font-weight: 700; font-size: 8.6px; margin-top: 1px; letter-spacing: 0.3px; }
    .stub-consumer { text-align: center; margin: 2px 0 2px; }
    .stub-consumer .name { font-weight: 700; font-size: 11.5px; line-height: 1.2; }
    .stub-consumer .addr { font-size: 8px; color: #333; }
    .stub-period-row { display: flex; justify-content: space-between; font-size: 8.6px; margin: 2px 0; padding: 0 1px; }
    .stub-notice { font-size: 6.8px; color: #444; text-align: center; margin-top: auto; padding: 2px 2mm 1px; line-height: 1.2; }
    .stub-thanks { text-align: center; font-weight: 700; font-style: italic; font-size: 9px; margin-bottom: 1px; }
    .stub-footer { display: flex; border: 1.2px solid #000; margin-top: 1px; }
    .stub-footer .idnum { flex: 0 0 38px; border-right: 1.2px solid #000; text-align: center; padding: 2px; }
    .stub-footer .idnum .val { color: #b00; font-size: 9.5px; }
    .stub-footer .total { flex: 1; display: flex; justify-content: space-between; align-items: center; padding: 2px 6px; }
    .stub-footer .total .lbl { font-weight: 700; font-size: 7.8px; color: #000; }
    .stub-footer .total .amt { font-weight: 700; font-size: 13px; }
    .stub-disconnected { color: #b00000; }
    CSS;
}

/**
 * Render one stub's inner HTML for a single joined bill row.
 * Expected keys on $bill: everything from `billing` + `first_name`,
 * `last_name`, `account_number`, `purok`, `barangay`, `address`,
 * `meter_number`, `type_name`, `route_sequence`, `consumer_id`,
 * and `reading_date` (the CURRENT reading's date, from the readings
 * table — the "to" side of Period Covered).
 */
function render_bill_stub($pdo, $bill)
{
    $muniName   = get_setting($pdo, 'municipality_name', 'Municipality');
    $officeName = get_setting($pdo, 'office_name', 'Water Works Office');
    $officeAddr = get_setting($pdo, 'office_address', '');

    $fromDate = get_previous_reading_date($pdo, $bill['consumer_id'], $bill['billing_period']);
    $toDate   = $bill['reading_date'] ?? null;
    $periodCovered = $fromDate
        ? date('M j', strtotime($fromDate)) . ' – ' . ($toDate ? date('M j', strtotime($toDate)) : '—')
        : 'First Reading' . ($toDate ? ' (as of ' . date('M j', strtotime($toDate)) . ')' : '');

    $dcDate = bill_disconnection_date($pdo, $bill);
    $dcLabel = $dcDate ? format_date($dcDate) : 'NONE';
    $dcClass = $dcDate ? 'stub-disconnected' : '';

    ob_start();
    ?>
    <div class="stub-header">
      <img src="<?= h($bill['_logo_left'] ?? '../assets/logo/seal.png') ?>" class="stub-logo-left" alt="">
      <img src="<?= h($bill['_logo_right'] ?? '../assets/logo/watersystem.png') ?>" class="stub-logo-right" alt="">
      <div class="muni"><?= h($muniName) ?></div>
      <div class="office"><?= h($officeName) ?></div>
      <?php if ($officeAddr): ?><div class="addr"><?= h($officeAddr) ?></div><?php endif; ?>
      <div class="title">STATEMENT OF ACCOUNT</div>
    </div>

    <table>
      <tr>
        <td style="width:60%;"><span class="lbl">Billing Month</span><span class="val"><?= h(billing_month_label($bill['billing_period'])) ?></span></td>
        <td><span class="lbl">Account No.</span><span class="val"><?= h($bill['account_number']) ?></span></td>
      </tr>
      <tr>
        <td><span class="lbl">Meter Serial Number</span><span class="val"><?= h($bill['meter_number'] ?: '—') ?></span></td>
        <td><span class="lbl">Type</span><span class="val"><?= h($bill['type_name']) ?></span></td>
      </tr>
      <tr>
        <td colspan="2"><span class="lbl">Disconnection Date</span><span class="val <?= $dcClass ?>"><?= h($dcLabel) ?></span></td>
      </tr>
    </table>

    <div class="stub-consumer">
      <div class="name"><?= h($bill['last_name'] . ', ' . $bill['first_name']) ?></div>
      <div class="addr"><?= h(format_consumer_address($bill)) ?></div>
    </div>

    <table>
      <tr>
        <td colspan="2" style="text-align:left;"><span class="lbl">Period Covered</span><span class="val"><?= h($periodCovered) ?></span></td>
        <td colspan="2"><span class="lbl">Due Date</span><span class="val"><?= format_date($bill['due_date']) ?></span></td>
      </tr>
      <tr>
        <td><span class="lbl">Present</span><span class="val"><?= number_format($bill['current_reading'], 0) ?></span></td>
        <td><span class="lbl">Previous</span><span class="val"><?= number_format($bill['previous_reading'], 0) ?></span></td>
        <td><span class="lbl">Cu.M Used</span><span class="val"><?= number_format($bill['consumption'], 0) ?></span></td>
        <td><span class="lbl">Water Charge</span><span class="val"><?= number_format($bill['water_amount'], 2) ?></span></td>
      </tr>
    </table>

    <table>
      <tr>
        <td><span class="lbl">Previous Balance</span><span class="val"><?= number_format($bill['previous_balance'], 2) ?></span></td>
        <td><span class="lbl">Surcharge</span><span class="val"><?= number_format($bill['surcharge_amount'], 2) ?></span></td>
      </tr>
      <tr>
        <td><span class="lbl">SCF</span><span class="val"><?= number_format($bill['scf_amount'], 2) ?></span></td>
        <td><span class="lbl">Electricity</span><span class="val"><?= number_format($bill['electricity_amount'], 2) ?></span></td>
      </tr>
      <tr>
        <td><span class="lbl">Service Loan</span><span class="val"><?= number_format($bill['service_loan'], 2) ?></span></td>
        <td><span class="lbl">Others</span><span class="val"><?= number_format($bill['others_amount'], 2) ?></span></td>
      </tr>
    </table>

    <div class="stub-notice">
      This bill also serves as a disconnection notice. Please pay on or before the due date to avoid disconnection of your water service.
    </div>
    <div class="stub-thanks">THANK YOU!</div>

    <div class="stub-footer">
      <div class="idnum"><span class="lbl">ID NUM</span><span class="val"><?= h($bill['route_sequence'] ?? '—') ?></span></div>
      <div class="total"><span class="lbl">TOTAL AMOUNT DUE</span><span class="amt"><?= money($pdo, $bill['total_amount']) ?></span></div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * The shared SQL used to fetch one or many bills fully joined with
 * everything render_bill_stub() needs (consumer, connection type,
 * and the current reading's own reading_date).
 */
function bill_stub_select_sql($whereSql)
{
    return "
        SELECT b.*, c.first_name, c.last_name, c.account_number, c.purok, c.barangay, c.address,
               c.meter_number, c.route_sequence, c.id AS consumer_id, ct.type_name,
               rd.reading_date
        FROM billing b
        JOIN consumers c ON c.id = b.consumer_id
        JOIN connection_types ct ON ct.id = c.connection_type_id
        LEFT JOIN readings rd ON rd.id = b.reading_id
        $whereSql
    ";
}
