<?php
/**
 * Shared helper functions.
 * This file is included by every page (through header.php).
 */

/** Escape output safely */
function h($value)
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Cache-busting query string for a static asset (CSS/JS), based on the
 * file's last-modified time. This guarantees that after you edit
 * style.css or script.js, browsers fetch the new version instead of an
 * old cached copy. Usage: assets/css/style.css?v=<?= asset_v('assets/css/style.css') ?>
 */
function asset_v($relativePathFromProjectRoot)
{
    $full = dirname(__DIR__) . '/' . ltrim($relativePathFromProjectRoot, '/');
    return @filemtime($full) ?: '1';
}

/** Redirect helper */
function redirect($url)
{
    header("Location: $url");
    exit;
}

/** Flash messages (stored one request in session) */
function set_flash($type, $message)
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash()
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/** Read a value from the settings table, with a fallback default */
function get_setting($pdo, $key, $default = '')
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
        foreach ($stmt->fetchAll() as $row) {
            $cache[$row['setting_key']] = $row['setting_value'];
        }
    }
    return $cache[$key] ?? $default;
}

/** Update (or insert) a setting value */
function set_setting($pdo, $key, $value)
{
    $stmt = $pdo->prepare("
        INSERT INTO settings (setting_key, setting_value)
        VALUES (:k, :v)
        ON DUPLICATE KEY UPDATE setting_value = :v2
    ");
    $stmt->execute(['k' => $key, 'v' => $value, 'v2' => $value]);
}

/** Format a number as currency using the configured currency symbol */
function money($pdo, $amount)
{
    $symbol = get_setting($pdo, 'currency_symbol', 'PHP');
    return $symbol . ' ' . number_format((float)$amount, 2);
}

/** Format YYYY-MM-DD (or date object) into a readable month, e.g. "July 2026" */
function format_month($dateStr)
{
    return date('F Y', strtotime($dateStr));
}

function format_date($dateStr, $fmt = 'M d, Y')
{
    if (empty($dateStr) || $dateStr === '0000-00-00') return '—';
    return date($fmt, strtotime($dateStr));
}

/** Turn a datetime string into "3 days ago" / "today" / "2 months ago" etc. */
function time_ago($dateTimeStr)
{
    if (empty($dateTimeStr)) return null;
    $then = strtotime($dateTimeStr);
    if (!$then) return null;
    $days = (int)floor((time() - $then) / 86400);
    if ($days <= 0) return 'today';
    if ($days === 1) return 'yesterday';
    if ($days < 30) return "$days days ago";
    $months = (int)floor($days / 30);
    if ($months === 1) return 'about a month ago';
    if ($months < 12) return "about $months months ago";
    $years = (int)floor($months / 12);
    return $years === 1 ? 'about a year ago' : "about $years years ago";
}

/**
 * Generate the next sequential account number for a new consumer,
 * in the form YYYY-0001, YYYY-0002, ...
 */
function generate_account_number($pdo)
{
    $year = date('Y');
    $stmt = $pdo->prepare("
        SELECT account_number FROM consumers
        WHERE account_number LIKE :prefix
        ORDER BY id DESC LIMIT 1
    ");
    $stmt->execute(['prefix' => $year . '-%']);
    $last = $stmt->fetchColumn();

    if ($last) {
        $parts = explode('-', $last);
        $next  = intval(end($parts)) + 1;
    } else {
        $next = 1;
    }
    return $year . '-' . str_pad($next, 4, '0', STR_PAD_LEFT);
}

/**
 * Generate the next sequential bill number, e.g. BILL-2026-07-000123
 */
function generate_bill_number($pdo, $billingPeriod)
{
    $prefix = 'BILL-' . date('Y-m', strtotime($billingPeriod)) . '-';
    $stmt = $pdo->prepare("
        SELECT bill_number FROM billing
        WHERE bill_number LIKE :prefix
        ORDER BY id DESC LIMIT 1
    ");
    $stmt->execute(['prefix' => $prefix . '%']);
    $last = $stmt->fetchColumn();

    if ($last) {
        $parts = explode('-', $last);
        $next  = intval(end($parts)) + 1;
    } else {
        $next = 1;
    }
    return $prefix . str_pad($next, 6, '0', STR_PAD_LEFT);
}

/**
 * Get the currently active rate for a connection type.
 * "Active" = latest effective_date that is <= today, and is_active = 1.
 * This is what makes rates flexible: add a new row any time you need
 * to change prices, and old bills keep using the rate that applied
 * at the time they were generated.
 */
function get_active_rate($pdo, $connectionTypeId, $asOfDate = null)
{
    $asOfDate = $asOfDate ?: date('Y-m-d');
    $stmt = $pdo->prepare("
        SELECT * FROM rates
        WHERE connection_type_id = :ctid
          AND is_active = 1
          AND effective_date <= :asof
        ORDER BY effective_date DESC, id DESC
        LIMIT 1
    ");
    $stmt->execute(['ctid' => $connectionTypeId, 'asof' => $asOfDate]);
    $rate = $stmt->fetch();

    if ($rate) {
        return $rate;
    }

    // No rate was effective as of $asOfDate — this happens when a bill is
    // back-dated to before the earliest rate on record (e.g. rates were
    // seeded with today's date at install time, and staff pick an earlier
    // Billing Date). Rather than leaving the reading with no rate at all
    // (which silently blocks bill generation), fall back to the oldest
    // active rate on record for this connection type and use that. This
    // keeps generation working for any billing date; it just means very
    // old back-dated bills use the earliest rate we have instead of none.
    $fallback = $pdo->prepare("
        SELECT * FROM rates
        WHERE connection_type_id = :ctid
          AND is_active = 1
        ORDER BY effective_date ASC, id ASC
        LIMIT 1
    ");
    $fallback->execute(['ctid' => $connectionTypeId]);
    return $fallback->fetch();
}

/**
 * Fetch the progressive tiers (brackets) configured for a rate, ordered
 * from lowest to highest. An empty result means the rate is flat — just
 * use its rate_per_cubic for everything beyond the minimum.
 */
function get_rate_tiers($pdo, $rateId)
{
    $stmt = $pdo->prepare("SELECT * FROM rate_tiers WHERE rate_id = :rid ORDER BY tier_order ASC");
    $stmt->execute(['rid' => $rateId]);
    return $stmt->fetchAll();
}

/**
 * Core billing calculation. Given consumption + a rate row, returns
 * an array with the excess consumption/amount and total.
 *
 * Supports two pricing modes:
 *  - Flat (legacy): a single rate_per_cubic applied to every m³ beyond
 *    minimum_consumption.
 *  - Tiered/progressive: brackets from rate_tiers, where the price per
 *    m³ increases the more a consumer uses (e.g. 11-20 m³ at one rate,
 *    21-30 m³ at a higher rate, 31+ m³ at a higher rate still). Tiers
 *    are defined in terms of consumption *beyond the minimum*.
 */
function calculate_bill_amount($pdo, $consumption, $rate)
{
    $minConsumption = (float)$rate['minimum_consumption'];
    $minCharge      = (float)$rate['minimum_charge'];
    $consumption    = (float)$consumption;

    $excessConsumption = max(0, $consumption - $minConsumption);
    $tiers = get_rate_tiers($pdo, $rate['id']);

    if (empty($tiers)) {
        // Legacy flat-rate mode: one price for everything beyond the minimum.
        $excessAmount = $excessConsumption * (float)$rate['rate_per_cubic'];
    } else {
        // Progressive mode: walk each bracket, charging its rate only for
        // the portion of excess consumption that falls inside it.
        $excessAmount = 0;
        $tierFloor = 0;
        foreach ($tiers as $tier) {
            $tierCeiling = $tier['upto_consumption'] !== null ? (float)$tier['upto_consumption'] : INF;
            $consumedInTier = max(0, min($excessConsumption, $tierCeiling) - $tierFloor);
            $excessAmount += $consumedInTier * (float)$tier['rate_per_cubic'];
            if ($excessConsumption <= $tierCeiling) break;
            $tierFloor = $tierCeiling;
        }
    }

    $total = $minCharge + $excessAmount;

    return [
        'excess_consumption' => $excessConsumption,
        'excess_amount'      => $excessAmount,
        'total_amount'       => $total,
    ];
}

/**
 * Human-readable summary of a rate's pricing, for display in Settings.
 * e.g. "11-20 m3: PHP 9.55/m3, 21-30 m3: PHP 10.55/m3, 31+ m3: PHP 11.55/m3"
 * Returns null for a flat rate (no tiers configured) so the caller can
 * fall back to showing the plain rate_per_cubic instead.
 */
function format_tier_summary($pdo, $rate, $tiers)
{
    if (empty($tiers)) {
        return null;
    }
    $minConsumption = (float)$rate['minimum_consumption'];
    $parts = [];
    $floor = 0;
    foreach ($tiers as $tier) {
        $ceiling = $tier['upto_consumption'] !== null ? (float)$tier['upto_consumption'] : null;
        $from = $minConsumption + $floor + 1;
        if ($ceiling === null) {
            $label = number_format($from, 0) . '+ m³';
        } else {
            $to = $minConsumption + $ceiling;
            $label = number_format($from, 0) . '–' . number_format($to, 0) . ' m³';
        }
        $parts[] = $label . ': ' . money($pdo, $tier['rate_per_cubic']) . '/m³';
        $floor = $ceiling !== null ? $ceiling : $floor;
    }
    return implode(', ', $parts);
}

/**
 * Senior Citizen Fund (SCF).
 * If consumption is below the configured threshold (default 50 m³), SCF
 * is a flat base amount (default 10). Once consumption reaches/exceeds
 * the threshold, SCF becomes (consumption - threshold) + base amount.
 */
function calculate_scf($pdo, $consumption)
{
    $threshold   = (float)get_setting($pdo, 'scf_threshold', 50);
    $baseAmount  = (float)get_setting($pdo, 'scf_base_amount', 10);
    $consumption = (float)$consumption;

    if ($consumption < $threshold) {
        return round($baseAmount, 2);
    }
    return round(($consumption - $threshold) + $baseAmount, 2);
}

/**
 * Consistent, single source of truth for displaying a consumer's address
 * anywhere in the system (consumer list/view, meter reading grid, bills,
 * statements, reports, exports, etc).
 *
 * New consumers (added via consumers/add.php) only fill in the "address"
 * field — purok/barangay are left blank. Older consumers (added before
 * that change) may only have purok/barangay filled in, with "address"
 * blank. This function shows whichever one the record actually has, so
 * every page displays something instead of a blank cell.
 *
 * @param array $row Any array/row containing some of: address, purok, barangay
 * @param string $empty What to return if there's nothing to show at all.
 */
function format_consumer_address($row, $empty = '—')
{
    $address = trim((string)($row['address'] ?? ''));
    if ($address !== '') {
        return $address;
    }

    $purok = trim((string)($row['purok'] ?? ''));
    $barangay = trim((string)($row['barangay'] ?? ''));
    $legacy = trim($purok . ' ' . $barangay);
    if ($legacy !== '') {
        return $legacy;
    }

    return $empty;
}

/**
 * CSRF protection.
 * ---------------------------------------------------------------
 * Every page that changes data (POST forms, and the handful of
 * "delete" / "toggle" links converted to POST-only actions) must:
 *   1. Print csrf_field() somewhere inside the <form>.
 *   2. Call require_csrf() as the very first thing in the handler
 *      that processes that submission.
 * Tokens are per-session (not per-form/per-request), which is the
 * normal approach for a single-admin, server-rendered app like this
 * one — it stops cross-site requests forged from another site/email/
 * link, without expiring mid-edit if someone leaves a form open.
 */

/** Returns the current session's CSRF token, generating one if needed. */
function csrf_token()
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Hidden <input> to drop inside any <form method="post">. */
function csrf_field()
{
    return '<input type="hidden" name="csrf_token" value="' . h(csrf_token()) . '">';
}

/**
 * Call at the top of any POST (or state-changing) handler, before
 * touching the database. Stops the request with a clear message if
 * the token is missing/wrong instead of silently proceeding.
 */
function require_csrf()
{
    $submitted = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
    $expected = $_SESSION['csrf_token'] ?? '';

    if ($expected === '' || !hash_equals($expected, $submitted)) {
        set_flash('error', 'Your session expired or this action could not be verified. Please try again.');
        $base = defined('BASE_URL') ? BASE_URL : '';
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        // Only trust the referer if it points back into this app; otherwise
        // fall back to a safe default rather than redirecting off-site.
        $back = ($base !== '' && $referer !== '' && strpos($referer, $base) !== false)
            ? $referer
            : ($base !== '' ? $base . '/index.php' : 'login.php');
        redirect($back);
    }
}

/**
 * Barangays/sitios whose water system runs on an electric pump.
 * Only consumers whose address matches one of these get charged
 * Electricity on their bill — everyone else (e.g. "Others" addresses
 * outside the service area) is charged 0. Keep this list in sync with
 * the dropdown in consumers/add.php (and edit.php, if it gets updated too).
 */
function get_electrified_addresses()
{
    return [
        'BATUAN, LINAO',
        'INOPACAN VILLE, TINAGO',
        'TAO-TAON, TAGAYTAY',
        'KATOTONG, TINAGO',
        'MALOY-A, TAO-TAON',
        'MAGATAS, TINAGO',
        'TAWID, TINAGO',
    ];
}

/** True if the given address is one of the electrified barangays/sitios. */
function is_electrified_address($address)
{
    $known = array_map('strtoupper', get_electrified_addresses());
    return in_array(strtoupper(trim((string)$address)), $known, true);
}

/**
 * Electricity charge: consumption (m³) × the configured electricity rate
 * (default 6.5) — but only for consumers whose address is one of the
 * electrified barangays/sitios (see get_electrified_addresses()).
 * Everyone else is charged 0.
 */
function calculate_electricity($pdo, $consumption, $address)
{
    if (!is_electrified_address($address)) {
        return 0;
    }
    $rate = (float)get_setting($pdo, 'electricity_rate', 6.5);
    return round((float)$consumption * $rate, 2);
}

/**
 * Add up every component of a bill into the final Total Amount Due:
 * Water Charge + Previous Balance + SCF + Electricity + Service Loan +
 * Surcharge + Others.
 */
function calculate_grand_total($waterAmount, $previousBalance, $scf, $electricity, $serviceLoan, $surcharge, $others)
{
    return round(
        (float)$waterAmount + (float)$previousBalance + (float)$scf + (float)$electricity +
        (float)$serviceLoan + (float)$surcharge + (float)$others,
        2
    );
}

/**
 * "Add-and-add until paid" carry-forward.
 * ---------------------------------------------------------------
 * Looks up a consumer's most recent PRIOR bill (the one immediately
 * before the given billing period) and works out how much of each
 * recurring component should roll into the NEW bill being generated:
 *
 *  - previous_balance: the prior bill's own Water Charge, PLUS
 *    whatever Previous Balance it was already carrying — so this
 *    keeps growing every month the account stays unpaid.
 *  - scf_carry / electricity_carry: same idea — each is already a
 *    running total on the prior bill (see billing/generate.php, where
 *    SCF/Electricity are stored as fresh-amount-plus-carry each time),
 *    so if the prior bill isn't paid, its whole SCF/Electricity
 *    amount rolls forward as-is and the new period's fresh SCF/
 *    Electricity gets added on top of that.
 *  - surcharge_carry: the prior bill's own Surcharge amount, which
 *    the new bill will add a fresh increment on top of (see
 *    calculate_surcharge_increment()).
 *  - prior_consumption / prior_rate_per_cubic: the prior bill's own
 *    Consumption (cu.m) and the Rate per Cubic Meter it was billed
 *    at — passed straight through so calculate_surcharge_increment()
 *    can compute the fresh Surcharge increment as
 *    Consumption x Rate, regardless of whether the prior bill is
 *    fully unpaid or only partially paid.
 *
 * SIMPLIFICATION FOR PARTIAL PAYMENTS: payments are recorded as one
 * lump sum against a bill's total (see billing/pay.php), so there is
 * no reliable way to know which specific component (Water Charge vs
 * SCF vs Electricity vs Surcharge) a partial payment actually covered.
 * So: if the prior bill is fully unpaid (no payment at all), each
 * component carries forward separately as described above. If the
 * prior bill was PARTIALLY paid, the entire remaining balance rolls
 * forward as one lump "Previous Balance" line instead, and SCF/
 * Electricity carry-forward is 0 for that transition (the new period
 * still gets its own fresh SCF/Electricity as normal) — but the fresh
 * Surcharge increment (Consumption x Rate) still applies either way,
 * since the prior bill is still not fully paid. This keeps every peso
 * accounted for without guessing.
 *
 * Returns null if there is no prior bill, or the prior bill is fully
 * paid (nothing to carry, nothing to surcharge).
 */
function carry_forward_charges($pdo, $consumerId, $periodDate)
{
    $stmt = $pdo->prepare("
        SELECT * FROM billing
        WHERE consumer_id = :cid AND billing_period < :period
        ORDER BY billing_period DESC, id DESC
        LIMIT 1
    ");
    $stmt->execute(['cid' => $consumerId, 'period' => $periodDate]);
    $prior = $stmt->fetch();

    if (!$prior || $prior['status'] === 'paid' || (float)$prior['balance'] <= 0.01) {
        return null;
    }

    $fullyUnpaid = (float)$prior['amount_paid'] <= 0.01;

    if ($fullyUnpaid) {
        return [
            'previous_balance'    => round((float)$prior['previous_balance'] + (float)$prior['water_amount'], 2),
            'scf_carry'           => (float)$prior['scf_amount'],
            'electricity_carry'   => (float)$prior['electricity_amount'],
            'surcharge_carry'     => (float)$prior['surcharge_amount'],
            'prior_consumption'   => (float)$prior['consumption'],
            'prior_rate_per_cubic' => (float)$prior['rate_per_cubic'],
            'lump_sum'            => false,
            'prior_bill_id'       => $prior['id'],
            'prior_overdue'       => $prior['status'] === 'overdue',
        ];
    }

    // Partially paid — roll the whole remaining balance forward as one
    // lump Previous Balance line; don't guess how to split it further.
    // The fresh Surcharge increment still applies (see doc comment above).
    return [
        'previous_balance'    => round((float)$prior['balance'], 2),
        'scf_carry'           => 0.0,
        'electricity_carry'   => 0.0,
        'surcharge_carry'     => 0.0,
        'prior_consumption'   => (float)$prior['consumption'],
        'prior_rate_per_cubic' => (float)$prior['rate_per_cubic'],
        'lump_sum'            => true,
        'prior_bill_id'       => $prior['id'],
        'prior_overdue'       => $prior['status'] === 'overdue',
    ];
}

/**
 * New Surcharge increment to add on top of whatever Surcharge is
 * already carrying forward (see carry_forward_charges()).
 *
 * Formula (per Neil's municipal ordinance): the prior bill's own
 * Consumption (cu.m) x the Rate per Cubic Meter it was billed at —
 * i.e. the surcharge equals a second Water Charge, computed fresh
 * every time a new bill is generated while that prior bill is still
 * not fully paid (unpaid, partial, or overdue — carry_forward_charges()
 * already returns null once a bill is fully paid, so by the time this
 * is called there IS an unpaid prior bill to surcharge).
 */
function calculate_surcharge_increment($priorConsumption, $priorRatePerCubic)
{
    $priorConsumption   = (float)$priorConsumption;
    $priorRatePerCubic  = (float)$priorRatePerCubic;
    if ($priorConsumption <= 0 || $priorRatePerCubic <= 0) {
        return 0.0;
    }
    return round($priorConsumption * $priorRatePerCubic, 2);
}

/**
 * Informational "Disconnection Date" printed on the bill: Due Date +
 * the configured grace period, shown only once a bill is actually
 * overdue (unpaid past its due date). Returns null otherwise (the
 * bill/receipt should print "NONE" in that case). This never affects
 * any charge — it's purely the notice printed on the statement.
 */
function bill_disconnection_date($pdo, $bill)
{
    if (($bill['status'] ?? '') !== 'overdue') {
        return null;
    }
    $graceDays = (int)get_setting($pdo, 'disconnection_grace_days', 15);
    return date('Y-m-d', strtotime($bill['due_date'] . " +$graceDays days"));
}

/**
 * The date the PREVIOUS meter reading was physically taken, for a
 * given consumer + billing period — i.e. the "From" side of the
 * Period Covered range printed on the bill (the "To" side is just the
 * current reading's own reading_date, already on the readings row).
 * Falls back to null if there's no prior reading on file (first-ever
 * bill for that consumer), so the caller can print "—" instead.
 */
function get_previous_reading_date($pdo, $consumerId, $periodDate)
{
    $stmt = $pdo->prepare("
        SELECT reading_date FROM readings
        WHERE consumer_id = :cid AND reading_period < :period
        ORDER BY reading_period DESC LIMIT 1
    ");
    $stmt->execute(['cid' => $consumerId, 'period' => $periodDate]);
    $date = $stmt->fetchColumn();
    return $date ?: null;
}

/**
 * The From/To dates for the "Period Covered" range printed on a bill:
 * From = the date the PREVIOUS meter reading was taken (see
 * get_previous_reading_date()); To = the date THIS bill's own reading
 * was taken (straight off the readings row). Either can come back
 * null (e.g. a consumer's very first bill has no prior reading date).
 */
function get_bill_period_covered($pdo, $bill)
{
    $from = get_previous_reading_date($pdo, $bill['consumer_id'], $bill['billing_period']);
    $stmt = $pdo->prepare("SELECT reading_date FROM readings WHERE id = :id");
    $stmt->execute(['id' => $bill['reading_id']]);
    $to = $stmt->fetchColumn();
    return ['from' => $from ?: null, 'to' => $to ?: null];
}

/**
 * Stream an array of rows to the browser as a downloadable CSV file and
 * stop execution. Adds a UTF-8 BOM so Excel opens special characters
 * (like ₱) correctly instead of showing garbled text.
 *
 * $headers - array of column titles, e.g. ['Account #', 'Name', ...]
 * $rows    - array of arrays/associative arrays; only values are used,
 *            in the same order as $headers.
 */
function export_csv($filename, $headers, $rows)
{
    if (ob_get_length()) {
        @ob_end_clean();
    }
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9_\-.]/', '_', $filename) . '"');
    header('Pragma: no-cache');
    header('Expires: 0');

    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel shows ₱ and other symbols correctly
    fputcsv($out, $headers);
    foreach ($rows as $row) {
        fputcsv($out, array_values($row));
    }
    fclose($out);
    exit;
}

/**
 * Build a complete, restorable SQL backup of every table in the database
 * (schema + data) as a plain string, without needing phpMyAdmin, mysqldump,
 * shell_exec, or any command-line tool — everything is done through the
 * same PDO connection the rest of the app already uses. This is the
 * "Full Database Backup" download used in Reports -> Export & Backup.
 *
 * The resulting .sql file can be restored the same way as any phpMyAdmin
 * export: phpMyAdmin -> Import -> choose the file -> Go.
 */
function generate_sql_backup($pdo, $filename = null)
{
    // Sends the backup straight to the browser as it's generated, the same
    // way export_csv() does, instead of building the whole file as one PHP
    // string first — on a database that's been running a few years, that
    // string (plus MySQL's own buffering of each SELECT *) can be well over
    // 100MB and exhausts PHP's memory_limit before the download ever starts.
    if (ob_get_length()) {
        @ob_end_clean();
    }
    $filename = $filename ?: 'water_billing_backup_' . date('Ymd_His') . '.sql';
    header('Content-Type: application/sql; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9_\-.]/', '_', $filename) . '"');
    header('Pragma: no-cache');
    header('Expires: 0');

    $out = fopen('php://output', 'w');
    fwrite($out, "-- Water Billing System — full backup\n");
    fwrite($out, "-- Generated: " . date('Y-m-d H:i:s') . "\n");
    fwrite($out, "-- Restore via phpMyAdmin: select the database, Import tab, choose this file, Go.\n\n");
    fwrite($out, "SET FOREIGN_KEY_CHECKS=0;\n\n");

    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

    // Unbuffered mode: without this, PDO's MySQL driver still reads each
    // SELECT * result set fully into its own memory before we get to loop
    // over it row by row, which defeats the point of streaming below for
    // large tables. It's restored to buffered (the normal/safe default for
    // the rest of the app) in the finally block no matter how this exits.
    $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);

    try {
        foreach ($tables as $table) {
            // --- Schema ---
            $createRow = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_ASSOC);
            $createSql = $createRow['Create Table'] ?? null;
            if (!$createSql) continue;

            fwrite($out, "-- ----------------------------\n-- Table: $table\n-- ----------------------------\n");
            fwrite($out, "DROP TABLE IF EXISTS `$table`;\n");
            fwrite($out, $createSql . ";\n\n");

            // Figure out which columns are real (not auto-generated/virtual,
            // e.g. readings.consumption) — generated columns can't be
            // INSERTed into and MySQL fills them in automatically.
            $colInfo = $pdo->query("SHOW COLUMNS FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
            $insertableCols = [];
            foreach ($colInfo as $col) {
                $extra = strtoupper($col['Extra'] ?? '');
                if (strpos($extra, 'GENERATED') !== false || strpos($extra, 'VIRTUAL') !== false) {
                    continue;
                }
                $insertableCols[] = $col['Field'];
            }
            if (empty($insertableCols)) continue;

            $quotedCols = '`' . implode('`, `', $insertableCols) . '`';

            // --- Data (unbuffered fetch + immediate write, one row at a time) ---
            $rowStmt = $pdo->query("SELECT * FROM `$table`");
            $rowCount = 0;
            while ($row = $rowStmt->fetch(PDO::FETCH_ASSOC)) {
                $values = [];
                foreach ($insertableCols as $col) {
                    $val = $row[$col];
                    $values[] = $val === null ? 'NULL' : $pdo->quote($val);
                }
                fwrite($out, "INSERT INTO `$table` ($quotedCols) VALUES (" . implode(', ', $values) . ");\n");
                $rowCount++;
                // Hand completed chunks to the browser instead of letting
                // PHP's own output buffer grow for the whole table.
                if ($rowCount % 500 === 0) {
                    flush();
                }
            }
            $rowStmt->closeCursor();
            if ($rowCount > 0) fwrite($out, "\n");
        }

        fwrite($out, "SET FOREIGN_KEY_CHECKS=1;\n");
    } finally {
        $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
    }

    fclose($out);
    exit;
}

/** Every consumer account status, in the order they should appear in dropdowns/filters. */
function consumer_statuses()
{
    return ['active', 'new', 'temporary', '50/50', 'inactive', 'disconnected'];
}

/**
 * Statuses that behave just like 'active' for billing/meter-reading purposes
 * (i.e. they show up in the reading grid and get billed by default).
 */
function active_like_statuses()
{
    return ['active', 'new', 'temporary', '50/50'];
}

/** Small helper to render a status badge consistently everywhere */
function status_badge($status)
{
    $map = [
        'active'      => 'badge-success',
        'new'         => 'badge-info',
        'temporary'   => 'badge-accent',
        '50/50'       => 'badge-teal',
        'inactive'    => 'badge-muted',
        'disconnected'=> 'badge-danger',
        'unpaid'      => 'badge-warning',
        'partial'     => 'badge-info',
        'paid'        => 'badge-success',
        'overdue'     => 'badge-danger',
    ];
    $class = $map[$status] ?? 'badge-muted';
    return '<span class="badge ' . $class . '">' . h(ucfirst($status)) . '</span>';
}

/**
 * Automatically flag unpaid bills whose due date has passed as
 * "overdue". Called on dashboard/list load so the whole system stays
 * in sync without needing a cron job.
 *
 * NOTE: this used to also tack a one-time Surcharge onto the bill the
 * moment it went overdue. As of the "add-and-add until paid" carry-
 * forward model, Surcharge (like Previous Balance, SCF, and
 * Electricity) instead accrues when the NEXT bill is generated for
 * that consumer — see carry_forward_charges() / billing/generate.php
 * — so a bill that stays overdue across several billing months keeps
 * picking up a fresh Surcharge increment each time, instead of being
 * charged it just once. This function now only ever changes `status`.
 */
function refresh_overdue_bills($pdo)
{
    $stmt = $pdo->prepare("
        UPDATE billing
        SET status = 'overdue'
        WHERE status IN ('unpaid','partial')
          AND due_date < CURDATE()
    ");
    try {
        $stmt->execute();
    } catch (Throwable $e) {
        log_system_error('refresh_overdue_bills failed: ' . $e->getMessage());
        // Don't crash the whole page over this background housekeeping step —
        // the rest of the page (dashboard, list, etc.) can still render fine.
    }
}

/**
 * Render a consistent, clickable "Billing Month" <select> — used
 * everywhere a billing/reading period needs to be picked, so choosing
 * (and understanding) a billing month works the same way on every
 * screen instead of mixing raw month pickers and dropdowns.
 *
 * $name       - the form field name (e.g. "period")
 * $selected   - currently selected value, format "Y-m"
 * $attrs      - extra raw HTML attributes, e.g. 'onchange="this.form.submit()"'
 * $monthsBack / $monthsForward - how far the list of choices spans
 */
function billing_month_select($name, $selected, $attrs = '', $monthsBack = 24, $monthsForward = 30, $includeAll = false)
{
    $options = get_period_options($monthsBack, $monthsForward);
    $html = '<select name="' . h($name) . '" ' . $attrs . '>';
    if ($includeAll) {
        $html .= '<option value=""' . ($selected === '' ? ' selected' : '') . '>— All Billing Months —</option>';
    }
    foreach ($options as $opt) {
        $sel = $opt['value'] === $selected ? ' selected' : '';
        $html .= '<option value="' . h($opt['value']) . '"' . $sel . '>' . h($opt['label']) . '</option>';
    }
    $html .= '</select>';
    return $html;
}

/**
 * Count how many readings, bills, and payments exist for a given
 * billing period — used to show "here's what will be deleted" before
 * letting staff clear a Billing Month.
 */
function count_billing_month_data($pdo, $periodDate)
{
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM readings WHERE reading_period = :p");
    $stmt->execute(['p' => $periodDate]);
    $readings = (int)$stmt->fetchColumn();

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM billing WHERE billing_period = :p");
    $stmt->execute(['p' => $periodDate]);
    $bills = (int)$stmt->fetchColumn();

    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM payments p
        JOIN billing b ON b.id = p.billing_id
        WHERE b.billing_period = :p
    ");
    $stmt->execute(['p' => $periodDate]);
    $payments = (int)$stmt->fetchColumn();

    return ['readings' => $readings, 'bills' => $bills, 'payments' => $payments];
}

/**
 * Permanently delete every reading, bill, and payment recorded for a
 * given Billing Month — used to "reset" a month so it can be reused
 * later (e.g. after testing, or to redo a month that was entered
 * wrong). Bills are deleted first (payments cascade automatically),
 * then readings, all inside one transaction so a mid-way failure
 * can't leave the month half-cleared.
 */
function clear_billing_month_data($pdo, $periodDate)
{
    $counts = count_billing_month_data($pdo, $periodDate);

    $pdo->beginTransaction();
    try {
        $pdo->prepare("DELETE FROM billing WHERE billing_period = :p")->execute(['p' => $periodDate]);
        $pdo->prepare("DELETE FROM readings WHERE reading_period = :p")->execute(['p' => $periodDate]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }

    return $counts;
}

/** Reusable dropdown for connection types */
function get_connection_types($pdo)
{
    return $pdo->query("SELECT * FROM connection_types WHERE is_active = 1 ORDER BY type_name")->fetchAll();
}

/**
 * Suggest the next route sequence number for a given reader (or globally
 * if no reader specified) — existing max + 10, so there's always room to
 * manually slot someone in between later.
 */
function get_next_route_sequence($pdo, $readerId = null)
{
    if ($readerId) {
        $stmt = $pdo->prepare("SELECT MAX(route_sequence) FROM consumers WHERE default_meter_reader_id = :rid");
        $stmt->execute(['rid' => $readerId]);
    } else {
        $stmt = $pdo->query("SELECT MAX(route_sequence) FROM consumers");
    }
    $max = $stmt->fetchColumn();
    return $max !== null ? ((int)$max + 10) : 10;
}

/**
 * Check whether an OR (Official Receipt) number has already been used
 * on another payment. OR numbers must be unique across the whole
 * system — two different payments sharing one OR# almost always means
 * a duplicate/accidental resubmission or a data-entry mistake, and
 * would otherwise go unnoticed since `payments.or_number` has no
 * database-level UNIQUE constraint.
 *
 * @param int|null $excludePaymentId Pass an existing payment's id when
 *   editing that payment, so it doesn't flag itself as a duplicate.
 */
function or_number_exists($pdo, $orNumber, $excludePaymentId = null)
{
    $orNumber = trim($orNumber);
    if ($orNumber === '') return false;

    $sql = "SELECT COUNT(*) FROM payments WHERE or_number = :or_number";
    $params = ['or_number' => $orNumber];
    if ($excludePaymentId) {
        $sql .= " AND id != :exclude_id";
        $params['exclude_id'] = $excludePaymentId;
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn() > 0;
}

/** Reusable dropdown for meter readers */
function get_meter_readers($pdo, $activeOnly = true)
{
    $sql = "SELECT * FROM meter_readers";
    if ($activeOnly) $sql .= " WHERE is_active = 1";
    $sql .= " ORDER BY name";
    return $pdo->query($sql)->fetchAll();
}

/**
 * Work out the correct "previous reading" for a consumer going into a
 * given billing period: the current_reading from the most recent
 * reading before that period, or the consumer's initial meter reading
 * if this would be their very first recorded reading.
 */
function get_previous_reading($pdo, $consumerId, $periodDate)
{
    $stmt = $pdo->prepare("
        SELECT current_reading FROM readings
        WHERE consumer_id = :cid AND reading_period < :period
        ORDER BY reading_period DESC LIMIT 1
    ");
    $stmt->execute(['cid' => $consumerId, 'period' => $periodDate]);
    $prev = $stmt->fetchColumn();
    if ($prev !== false) return (float)$prev;

    $stmt = $pdo->prepare("SELECT meter_initial_reading FROM consumers WHERE id = :id");
    $stmt->execute(['id' => $consumerId]);
    $initial = $stmt->fetchColumn();
    return $initial !== false ? (float)$initial : 0.0;
}

/**
 * Build a friendly "Jan-Feb 2026" style label for a stored period date,
 * showing which two calendar months the reading compares. $monthDate is
 * any date within the reading month (e.g. "2026-02-01").
 */
function period_range_label($monthDate)
{
    $prevDate  = strtotime($monthDate . ' -1 month');
    $thisDate  = strtotime($monthDate);
    $prevMonth = date('M', $prevDate);
    $thisMonth = date('M', $thisDate);
    $prevYear  = date('Y', $prevDate);
    $thisYear  = date('Y', $thisDate);

    if ($prevYear === $thisYear) {
        return "$prevMonth-$thisMonth $thisYear";
    }
    // Year boundary (e.g. December into January) — show both years so it's unambiguous
    return "$prevMonth $prevYear-$thisMonth $thisYear";
}

/**
 * The "Billing Month" — the single month name a bill/reading period is
 * actually known by.
 *
 * Meter readings are physically taken in the LATER calendar month (e.g.
 * a reading taken in February, compared against January's prior
 * reading) and stored that way (reading_period/billing_period =
 * "2026-02-01"). But the water was mostly consumed during the EARLIER
 * month, so that's the month consumers and staff call it by — a
 * Jan-Feb reading is "January's bill". The Billing Month is therefore
 * always ONE MONTH BEFORE the stored period date.
 *
 * e.g. billing_month_label('2026-02-01') => "January 2026"
 */
function billing_month_label($periodDate)
{
    return date('F Y', strtotime($periodDate . ' -1 month'));
}

/**
 * Short "Jan 2026 -> Feb 2026" hint showing exactly which two meter
 * readings a Billing Month compares, so it's never ambiguous which
 * reading is "previous" and which is "present".
 */
function reading_range_hint($periodDate)
{
    $prev = date('M Y', strtotime($periodDate . ' -1 month'));
    $curr = date('M Y', strtotime($periodDate));
    return "$prev \xE2\x86\x92 $curr";
}

/**
 * Short "Jan-Feb" style abbreviation of the two reading months a
 * Billing Month covers — used for compact dropdown labels where the
 * full "readings Jan 2026 -> Feb 2026" hint is too long to read
 * comfortably in a <select>.
 */
function compact_reading_range($periodDate)
{
    $prev = date('M', strtotime($periodDate . ' -1 month'));
    $curr = date('M', strtotime($periodDate));
    return "$prev-$curr";
}

/**
 * Generate a list of selectable billing months for dropdowns, e.g.
 * ['value' => '2026-02', 'label' => 'January 2026 (Jan-Feb)'],
 * spanning from $monthsBack months ago to $monthsForward months ahead
 * of today. This naturally covers "the incoming months" without
 * hardcoding years — the default $monthsForward of 30 keeps roughly
 * two and a half years of future months available at all times, so
 * the list keeps stretching further out as time passes (no need to
 * edit code each year to "add" new months). Pick from this list by
 * Billing Month name — the underlying reading-period value is
 * handled for you.
 *
 * $earliestPeriod clamps the other end: nothing earlier than this is
 * ever generated, regardless of $monthsBack. Defaults to reading period
 * February 2026 — which is Billing Month "January 2026" once
 * billing_month_label() shifts it back a month for display — so no
 * Billing Month dropdown in the app ever shows 2025 or earlier, even
 * in the label text (not just the underlying value).
 */
function get_period_options($monthsBack = 24, $monthsForward = 30, $earliestPeriod = '2026-02-01')
{
    $options = [];
    for ($i = -$monthsBack; $i <= $monthsForward; $i++) {
        $date  = date('Y-m-01', strtotime(date('Y-m-01') . " $i month"));
        if ($earliestPeriod && $date < $earliestPeriod) {
            continue;
        }
        $options[] = [
            'value' => date('Y-m', strtotime($date)),
            'month' => billing_month_label($date),
            'range' => reading_range_hint($date),
            'label' => billing_month_label($date) . ' (' . compact_reading_range($date) . ')',
        ];
    }
    return $options;
}

/**
 * Reverse of billing_month_label() — turns a "January 2026" style
 * Billing Month name back into the stored reading_period/billing_period
 * date ("2026-02-01"). Returns null if the text can't be parsed.
 */
function parse_billing_month_label($label)
{
    $label = trim($label);
    if ($label === '') return null;
    $dt = DateTime::createFromFormat('F Y', $label);
    if (!$dt) {
        // Be a little forgiving of "Jan 2026" style abbreviations too
        $dt = DateTime::createFromFormat('M Y', $label);
    }
    if (!$dt) return null;
    $dt->setDate((int)$dt->format('Y'), (int)$dt->format('n'), 1);
    $dt->modify('+1 month');
    return $dt->format('Y-m-d');
}

/**
 * Read an uploaded CSV into an array of associative rows keyed by the
 * exact header text in row 1 (matching what export_csv() produces),
 * so importing is just re-uploading a file this system already
 * exported. Returns null if the file can't be read at all.
 */
function read_csv_assoc($filePath)
{
    $fh = @fopen($filePath, 'r');
    if (!$fh) return null;

    // Strip a UTF-8 BOM if present (export_csv() writes one for Excel)
    $bom = fread($fh, 3);
    if ($bom !== "\xEF\xBB\xBF") rewind($fh);

    $header = fgetcsv($fh);
    if ($header === false) { fclose($fh); return []; }
    $header = array_map('trim', $header);

    $rows = [];
    while (($line = fgetcsv($fh)) !== false) {
        if (count($line) === 1 && trim($line[0]) === '') continue; // skip blank lines
        $row = [];
        foreach ($header as $i => $col) {
            $row[$col] = $line[$i] ?? '';
        }
        $rows[] = $row;
    }
    fclose($fh);
    return $rows;
}

/** Confirm an uploaded CSV has (at least) the columns we need, regardless of column order. */
function csv_has_columns($rows, $required)
{
    if (empty($rows)) return true; // an empty file isn't a header mismatch
    $present = array_keys($rows[0]);
    foreach ($required as $col) {
        if (!in_array($col, $present, true)) return false;
    }
    return true;
}

/**
 * Import consumers from a CSV in the same format as the "Export
 * Consumers" download — matches existing consumers by Account #
 * (updating them) and creates new rows for account numbers not
 * already in the system.
 */
function import_consumers_csv($pdo, $filePath)
{
    $required = ['Account #', 'First Name', 'Last Name', 'Connection Type'];
    $rows = read_csv_assoc($filePath);
    $result = ['inserted' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => []];
    if ($rows === null) { $result['errors'][] = 'Could not read the uploaded file.'; return $result; }
    if (!csv_has_columns($rows, $required)) {
        $result['errors'][] = 'This file is missing expected columns (Account #, First Name, Last Name, Connection Type). Please upload the CSV from "Export Consumers" without changing its headers.';
        return $result;
    }

    $typeMap = [];
    foreach ($pdo->query("SELECT id, type_name FROM connection_types") as $t) {
        $typeMap[strtolower($t['type_name'])] = $t['id'];
    }
    $readerMap = [];
    foreach ($pdo->query("SELECT id, name FROM meter_readers") as $r) {
        $readerMap[strtolower($r['name'])] = $r['id'];
    }

    $pdo->beginTransaction();
    try {
        foreach ($rows as $i => $row) {
            $lineNo = $i + 2; // +1 for header row, +1 for 1-based
            $acct = trim($row['Account #'] ?? '');
            if ($acct === '') { $result['skipped']++; $result['errors'][] = "Row $lineNo: missing Account #."; continue; }

            $typeName = trim($row['Connection Type'] ?? '');
            $typeId = $typeMap[strtolower($typeName)] ?? null;
            if (!$typeId) { $result['skipped']++; $result['errors'][] = "Row $lineNo ($acct): unknown Connection Type \"$typeName\"."; continue; }

            $readerName = trim($row['Assigned Reader'] ?? '');
            $readerId = $readerName !== '' ? ($readerMap[strtolower($readerName)] ?? null) : null;

            $status = strtolower(trim($row['Status'] ?? 'active'));
            if (!in_array($status, consumer_statuses(), true)) $status = 'active';

            $dateConnected = trim($row['Date Connected'] ?? '');
            $dateConnected = $dateConnected !== '' ? date('Y-m-d', strtotime($dateConnected)) : null;

            $data = [
                'account_number' => $acct,
                'first_name' => trim($row['First Name'] ?? ''),
                'last_name' => trim($row['Last Name'] ?? ''),
                'middle_name' => trim($row['Middle Name'] ?? ''),
                'contact_number' => trim($row['Contact #'] ?? ''),
                'email' => trim($row['Email'] ?? ''),
                'purok' => trim($row['Purok'] ?? ''),
                'barangay' => trim($row['Barangay'] ?? ''),
                'address' => trim($row['Address'] ?? ''),
                'connection_type_id' => $typeId,
                'meter_number' => trim($row['Meter #'] ?? ''),
                'meter_initial_reading' => is_numeric($row['Initial Reading'] ?? null) ? $row['Initial Reading'] : 0,
                'date_connected' => $dateConnected,
                'status' => $status,
                'default_meter_reader_id' => $readerId,
                'route_sequence' => is_numeric($row['Route Order'] ?? null) ? (int)$row['Route Order'] : null,
                'remarks' => trim($row['Remarks'] ?? ''),
            ];

            $chk = $pdo->prepare("SELECT id FROM consumers WHERE account_number = :a");
            $chk->execute(['a' => $acct]);
            $existingId = $chk->fetchColumn();

            if ($existingId) {
                $upd = $pdo->prepare("
                    UPDATE consumers SET
                        first_name = :first_name, last_name = :last_name, middle_name = :middle_name,
                        contact_number = :contact_number, email = :email, purok = :purok,
                        barangay = :barangay, address = :address, connection_type_id = :connection_type_id,
                        meter_number = :meter_number, meter_initial_reading = :meter_initial_reading,
                        date_connected = :date_connected, status = :status,
                        default_meter_reader_id = :default_meter_reader_id, route_sequence = :route_sequence,
                        remarks = :remarks
                    WHERE id = :id
                ");
                $data['id'] = $existingId;
                unset($data['account_number']);
                $upd->execute($data);
                $result['updated']++;
            } else {
                $ins = $pdo->prepare("
                    INSERT INTO consumers
                    (account_number, first_name, last_name, middle_name, contact_number, email,
                     purok, barangay, address, connection_type_id, meter_number,
                     meter_initial_reading, date_connected, status, default_meter_reader_id, route_sequence, remarks)
                    VALUES
                    (:account_number, :first_name, :last_name, :middle_name, :contact_number, :email,
                     :purok, :barangay, :address, :connection_type_id, :meter_number,
                     :meter_initial_reading, :date_connected, :status, :default_meter_reader_id, :route_sequence, :remarks)
                ");
                $ins->execute($data);
                $result['inserted']++;
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        $result['errors'][] = 'Import stopped, nothing was saved: ' . $e->getMessage();
    }
    return $result;
}

/**
 * Import meter readings from a CSV in the same format as the "Export
 * Readings" download. Matches consumers by Account # and Billing
 * Month by name, so a previously exported month can be re-uploaded to
 * restore it. Existing readings for the same consumer + month are
 * left alone unless $overwrite is true.
 *
 * Note: this restores READINGS only — bills still need to be created
 * afterward from Billing → Generate Bills, since bill amounts depend
 * on the rates configured at generation time (those aren't part of
 * the Readings export).
 */
function import_readings_csv($pdo, $filePath, $overwrite = false)
{
    $required = ['Account #', 'Billing Month', 'Previous Reading', 'Present Reading'];
    $rows = read_csv_assoc($filePath);
    $result = ['inserted' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => []];
    if ($rows === null) { $result['errors'][] = 'Could not read the uploaded file.'; return $result; }
    if (!csv_has_columns($rows, $required)) {
        $result['errors'][] = 'This file is missing expected columns (Account #, Billing Month, Previous Reading, Present Reading). Please upload the CSV from "Export Readings" without changing its headers.';
        return $result;
    }

    $consumerMap = [];
    foreach ($pdo->query("SELECT id, account_number FROM consumers") as $c) {
        $consumerMap[$c['account_number']] = $c['id'];
    }
    $readerMap = [];
    foreach ($pdo->query("SELECT id, name FROM meter_readers") as $r) {
        $readerMap[strtolower($r['name'])] = $r['id'];
    }

    $pdo->beginTransaction();
    try {
        foreach ($rows as $i => $row) {
            $lineNo = $i + 2;
            $acct = trim($row['Account #'] ?? '');
            $consumerId = $consumerMap[$acct] ?? null;
            if (!$consumerId) { $result['skipped']++; $result['errors'][] = "Row $lineNo: Account # \"$acct\" not found — import consumers first."; continue; }

            $period = parse_billing_month_label($row['Billing Month'] ?? '');
            if (!$period) { $result['skipped']++; $result['errors'][] = "Row $lineNo ($acct): couldn't understand Billing Month \"{$row['Billing Month']}\"."; continue; }

            $prev = $row['Previous Reading'] ?? '';
            $curr = $row['Present Reading'] ?? '';
            if (!is_numeric($prev) || !is_numeric($curr)) { $result['skipped']++; $result['errors'][] = "Row $lineNo ($acct): reading values must be numbers."; continue; }

            $readingDate = trim($row['Reading Date'] ?? '');
            $readingDate = $readingDate !== '' ? date('Y-m-d', strtotime($readingDate)) : $period;

            $readerName = trim($row['Meter Reader'] ?? '');
            $readerId = $readerName !== '' ? ($readerMap[strtolower($readerName)] ?? null) : null;

            $chk = $pdo->prepare("SELECT id FROM readings WHERE consumer_id = :c AND reading_period = :p");
            $chk->execute(['c' => $consumerId, 'p' => $period]);
            $existingId = $chk->fetchColumn();

            if ($existingId && !$overwrite) {
                $result['skipped']++;
                $result['errors'][] = "Row $lineNo ($acct): a reading for {$row['Billing Month']} already exists — skipped (check \"Overwrite existing readings\" to replace it).";
                continue;
            }

            if ($existingId) {
                $upd = $pdo->prepare("
                    UPDATE readings SET previous_reading = :prev, current_reading = :curr,
                        reading_date = :rdate, meter_reader_id = :reader
                    WHERE id = :id
                ");
                $upd->execute(['prev' => $prev, 'curr' => $curr, 'rdate' => $readingDate, 'reader' => $readerId, 'id' => $existingId]);
                $result['updated']++;
            } else {
                $ins = $pdo->prepare("
                    INSERT INTO readings (consumer_id, reading_period, previous_reading, current_reading, reading_date, meter_reader_id, recorded_by)
                    VALUES (:c, :p, :prev, :curr, :rdate, :reader, 'Imported')
                ");
                $ins->execute(['c' => $consumerId, 'p' => $period, 'prev' => $prev, 'curr' => $curr, 'rdate' => $readingDate, 'reader' => $readerId]);
                $result['inserted']++;
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        $result['errors'][] = 'Import stopped, nothing was saved: ' . $e->getMessage();
    }
    return $result;
}

/**
 * Import payments from a CSV in the same format as the "Export
 * Payments" download. Matches each row to an existing bill by Bill
 * Number (bills must already exist — generate them first), and skips
 * rows whose OR Number has already been recorded against that bill so
 * re-uploading the same file twice doesn't double-count payments.
 * Updates each bill's amount paid / balance / status afterward.
 */
function import_payments_csv($pdo, $filePath)
{
    $required = ['Bill Number', 'Amount Paid'];
    $rows = read_csv_assoc($filePath);
    $result = ['inserted' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => []];
    if ($rows === null) { $result['errors'][] = 'Could not read the uploaded file.'; return $result; }
    if (!csv_has_columns($rows, $required)) {
        $result['errors'][] = 'This file is missing expected columns (Bill Number, Amount Paid). Please upload the CSV from "Export Payments" without changing its headers.';
        return $result;
    }

    $pdo->beginTransaction();
    try {
        foreach ($rows as $i => $row) {
            $lineNo = $i + 2;
            $billNumber = trim($row['Bill Number'] ?? '');
            $amount = $row['Amount Paid'] ?? '';
            if ($billNumber === '' || !is_numeric($amount) || (float)$amount <= 0) {
                $result['skipped']++; $result['errors'][] = "Row $lineNo: missing Bill Number or invalid Amount Paid.";
                continue;
            }

            $bill = $pdo->prepare("SELECT * FROM billing WHERE bill_number = :bn");
            $bill->execute(['bn' => $billNumber]);
            $bill = $bill->fetch();
            if (!$bill) { $result['skipped']++; $result['errors'][] = "Row $lineNo: Bill Number \"$billNumber\" not found — generate that month's bills first."; continue; }

            $orNumber = trim($row['OR Number'] ?? '');
            if ($orNumber !== '') {
                $dupChk = $pdo->prepare("SELECT COUNT(*) FROM payments WHERE billing_id = :bid AND or_number = :orn");
                $dupChk->execute(['bid' => $bill['id'], 'orn' => $orNumber]);
                if ($dupChk->fetchColumn() > 0) {
                    $result['skipped']++; $result['errors'][] = "Row $lineNo ($billNumber): OR # $orNumber already recorded for this bill — skipped.";
                    continue;
                }
            }

            $paymentDate = trim($row['Payment Date'] ?? '');
            $paymentDate = $paymentDate !== '' ? date('Y-m-d', strtotime($paymentDate)) : date('Y-m-d');
            $receivedBy = trim($row['Received By'] ?? '');

            $ins = $pdo->prepare("
                INSERT INTO payments (billing_id, or_number, amount_paid, payment_date, received_by)
                VALUES (:bid, :orn, :amt, :pdate, :rb)
            ");
            $ins->execute(['bid' => $bill['id'], 'orn' => $orNumber, 'amt' => $amount, 'pdate' => $paymentDate, 'rb' => $receivedBy]);

            $newPaid = (float)$bill['amount_paid'] + (float)$amount;
            $newBalance = round((float)$bill['total_amount'] - $newPaid, 2);
            $newStatus = $newBalance <= 0.01 ? 'paid' : 'partial';
            $upd = $pdo->prepare("UPDATE billing SET amount_paid = :paid, balance = :bal, status = :st WHERE id = :id");
            $upd->execute(['paid' => $newPaid, 'bal' => max(0, $newBalance), 'st' => $newStatus, 'id' => $bill['id']]);

            $result['inserted']++;
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        $result['errors'][] = 'Import stopped, nothing was saved: ' . $e->getMessage();
    }
    return $result;
}

// ---------------------------------------------------------------------
// PAGINATION (for large list views — consumers, billing, readings)
// ---------------------------------------------------------------------

/**
 * Work out the current page, LIMIT/OFFSET and page count from
 * $_GET['page'] / $_GET['per_page'] and a known total row count.
 *
 * Usage:
 *   $totalRows = (int)$pdo->prepare($countSql)->... ->fetchColumn();
 *   $p = paginate($totalRows, 25);
 *   $sql .= " LIMIT :limit OFFSET :offset";
 *   $stmt = $pdo->prepare($sql);
 *   ... bind your normal params ...
 *   $stmt->bindValue(':limit', $p['perPage'], PDO::PARAM_INT);
 *   $stmt->bindValue(':offset', $p['offset'], PDO::PARAM_INT);
 *   $stmt->execute();
 *
 * @param int $totalRows      Total matching rows (before LIMIT), from a COUNT(*) query
 * @param int $defaultPerPage Rows per page when ?per_page= isn't set/valid
 * @param int[] $allowedPerPage Allowed values for ?per_page= (guards against ?per_page=999999)
 * @return array{page:int,perPage:int,offset:int,totalRows:int,totalPages:int}
 */
function paginate($totalRows, $defaultPerPage = 25, $allowedPerPage = [10, 25, 50, 100])
{
    $totalRows = max(0, (int)$totalRows);

    $perPage = (int)($_GET['per_page'] ?? $defaultPerPage);
    if (!in_array($perPage, $allowedPerPage, true)) {
        $perPage = $defaultPerPage;
    }

    $totalPages = max(1, (int)ceil($totalRows / $perPage));

    $page = (int)($_GET['page'] ?? 1);
    if ($page < 1) $page = 1;
    if ($page > $totalPages) $page = $totalPages;

    return [
        'page'       => $page,
        'perPage'    => $perPage,
        'offset'     => ($page - 1) * $perPage,
        'totalRows'  => $totalRows,
        'totalPages' => $totalPages,
    ];
}

/**
 * Render Prev/Next + page-jump pagination links, preserving every
 * existing query-string param (search, filters, per_page, ...) except
 * 'page' itself, which each link overrides.
 *
 * @param array $p Result of paginate()
 */
function pagination_links($p)
{
    if ($p['totalRows'] <= 0) return '';

    $page = $p['page'];
    $totalPages = $p['totalPages'];

    $urlFor = function ($targetPage) {
        $params = $_GET;
        $params['page'] = $targetPage;
        return '?' . http_build_query($params);
    };

    $rangeStart = $p['totalRows'] === 0 ? 0 : $p['offset'] + 1;
    $rangeEnd   = min($p['offset'] + $p['perPage'], $p['totalRows']);

    // Show up to 5 page numbers, centered on the current page.
    $window = 2;
    $start = max(1, $page - $window);
    $end   = min($totalPages, $page + $window);

    ob_start();
    ?>
    <div class="pagination-bar">
      <div class="pagination-summary">
        Showing <?= number_format($rangeStart) ?>&ndash;<?= number_format($rangeEnd) ?> of <?= number_format($p['totalRows']) ?>
      </div>
      <?php if ($totalPages > 1): ?>
      <nav class="pagination" aria-label="Pagination">
        <?php if ($page > 1): ?>
          <a class="page-link" href="<?= h($urlFor(1)) ?>" aria-label="First page">&laquo; First</a>
          <a class="page-link" href="<?= h($urlFor($page - 1)) ?>" aria-label="Previous page">&lsaquo; Prev</a>
        <?php else: ?>
          <span class="page-link disabled">&laquo; First</span>
          <span class="page-link disabled">&lsaquo; Prev</span>
        <?php endif; ?>

        <?php if ($start > 1): ?><span class="page-ellipsis">&hellip;</span><?php endif; ?>
        <?php for ($i = $start; $i <= $end; $i++): ?>
          <?php if ($i === $page): ?>
            <span class="page-link current" aria-current="page"><?= $i ?></span>
          <?php else: ?>
            <a class="page-link" href="<?= h($urlFor($i)) ?>"><?= $i ?></a>
          <?php endif; ?>
        <?php endfor; ?>
        <?php if ($end < $totalPages): ?><span class="page-ellipsis">&hellip;</span><?php endif; ?>

        <?php if ($page < $totalPages): ?>
          <a class="page-link" href="<?= h($urlFor($page + 1)) ?>" aria-label="Next page">Next &rsaquo;</a>
          <a class="page-link" href="<?= h($urlFor($totalPages)) ?>" aria-label="Last page">Last &raquo;</a>
        <?php else: ?>
          <span class="page-link disabled">Next &rsaquo;</span>
          <span class="page-link disabled">Last &raquo;</span>
        <?php endif; ?>
      </nav>
      <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * A small "Rows per page" <select> that auto-submits and resets to page 1.
 * Renders as a self-contained <form> so it works even outside the main filter form.
 */
function per_page_select($allowed = [10, 25, 50, 100])
{
    $current = (int)($_GET['per_page'] ?? 25);
    if (!in_array($current, $allowed, true)) $current = 25;

    $hidden = '';
    foreach ($_GET as $k => $v) {
        if ($k === 'per_page' || $k === 'page') continue;
        if (is_array($v)) continue;
        $hidden .= '<input type="hidden" name="' . h($k) . '" value="' . h($v) . '">';
    }

    ob_start();
    ?>
    <form method="get" class="per-page-form">
      <?= $hidden ?>
      <label for="per_page" class="per-page-label">Rows per page</label>
      <select name="per_page" id="per_page" onchange="this.form.submit()">
        <?php foreach ($allowed as $n): ?>
          <option value="<?= $n ?>" <?= $n === $current ? 'selected' : '' ?>><?= $n ?></option>
        <?php endforeach; ?>
      </select>
    </form>
    <?php
    return ob_get_clean();
}
