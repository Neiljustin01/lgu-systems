<?php
/**
 * System resilience: catch anything unexpected (a dropped database
 * connection, a coding mistake, a full disk, etc.) and turn it into a
 * calm, understandable page instead of a blank screen or a scary raw
 * PHP error dump. Details are written to logs/app_errors.log so an
 * administrator can troubleshoot later; end users never see stack traces.
 *
 * This file is loaded once, as early as possible (from config/database.php),
 * so it protects every page in the system, including login.php.
 */

// Never show raw PHP errors/warnings on screen — log them instead.
ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

if (!defined('APP_ERROR_LOG')) {
    define('APP_ERROR_LOG', __DIR__ . '/../logs/app_errors.log');
}

if (!function_exists('log_system_error')) {
    function log_system_error($message)
    {
        $dir = dirname(APP_ERROR_LOG);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        @file_put_contents(
            APP_ERROR_LOG,
            '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL,
            FILE_APPEND | LOCK_EX
        );
    }
}

if (!function_exists('render_friendly_error')) {
    function render_friendly_error($detail = '')
    {
        if (function_exists('ob_get_length') && ob_get_length()) {
            @ob_end_clean();
        }
        if (!headers_sent()) {
            http_response_code(500);
        }
        $detail = $detail !== ''
            ? $detail
            : 'The system ran into an unexpected problem and stopped safely before saving anything incomplete.';
        echo '<!DOCTYPE html><html><head><meta charset="UTF-8">'
           . '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
           . '<title>Something went wrong</title>'
           . '<style>
               body{font-family:Arial,Helvetica,sans-serif;background:#f4f6f8;margin:0;padding:60px 20px;}
               .box{max-width:640px;margin:0 auto;background:#fff;border:1px solid #e2b8b8;
                    border-radius:10px;padding:28px 32px;color:#3a3a3a;box-shadow:0 2px 10px rgba(0,0,0,.06);}
               h2{margin-top:0;color:#7a2020;}
               ul{margin:12px 0;padding-left:20px;} li{margin-bottom:6px;}
               a.btn{display:inline-block;margin-top:16px;padding:10px 18px;background:#0f4c75;
                     color:#fff;text-decoration:none;border-radius:6px;font-weight:600;}
               code{background:#f0f0f0;padding:1px 5px;border-radius:4px;}
             </style></head><body><div class="box">'
           . '<h2>&#9888; Something went wrong</h2>'
           . '<p>' . htmlspecialchars($detail, ENT_QUOTES, 'UTF-8') . '</p>'
           . '<p>Nothing was lost — the system stops before saving anything if a problem like this happens. Please try:</p>'
           . '<ul>'
           . '<li>Click Back and try the action again</li>'
           . '<li>Make sure <strong>MySQL</strong> is still running in the XAMPP Control Panel</li>'
           . '<li>If this keeps happening, check <code>logs/app_errors.log</code> in the system folder, or contact whoever set up this system</li>'
           . '</ul>'
           . '<a class="btn" href="javascript:history.back()">&larr; Go Back</a>'
           . '</div></body></html>';
        exit;
    }
}

set_exception_handler(function ($e) {
    log_system_error(get_class($e) . ': ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    render_friendly_error();
});

set_error_handler(function ($severity, $message, $file, $line) {
    // Respect @-suppressed errors and error_reporting settings
    if (!(error_reporting() & $severity)) {
        return false;
    }
    $fatalLevels = [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR];
    if (in_array($severity, $fatalLevels, true)) {
        log_system_error("PHP fatal-level error: $message in $file:$line");
        render_friendly_error();
    }
    // Non-fatal (notices/warnings/deprecations): log quietly, keep the page running.
    log_system_error("PHP notice: $message in $file:$line");
    return true;
});

register_shutdown_function(function () {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        log_system_error("PHP shutdown-level fatal: {$error['message']} in {$error['file']}:{$error['line']}");
        render_friendly_error();
    }
});
