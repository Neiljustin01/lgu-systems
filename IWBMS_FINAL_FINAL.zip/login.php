<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

if (!empty($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Please enter both username and password.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = :u LIMIT 1");
        $stmt->execute(['u' => $username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['admin_name'] = $admin['full_name'] ?: $admin['username'];

            $upd = $pdo->prepare("UPDATE admin_users SET last_login = NOW() WHERE id = :id");
            $upd->execute(['id' => $admin['id']]);

            header('Location: index.php');
            exit;
        } else {
            $error = 'Invalid username or password.';
        }
    }
}

$systemName = get_setting($pdo, 'system_name', 'Water Billing & Collection System');
$muniName   = get_setting($pdo, 'municipality_name', 'Municipality');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign in · <?= h($systemName) ?></title>
<link rel="icon" type="image/png" href="assets/logo/watersystem.png">
<link rel="stylesheet" href="assets/css/fonts.css?v=<?= asset_v('assets/css/fonts.css') ?>">
<link rel="stylesheet" href="assets/css/style.css?v=<?= asset_v('assets/css/style.css') ?>">
</head>
<body>
<div class="login-wrap">
  <div class="login-card">
    <div class="login-logos">
      <img src="assets/logo/seal.png" alt="<?= h($muniName) ?> Seal" class="login-logo" width="56" height="56">
      <img src="assets/logo/watersystem.png" alt="<?= h($systemName) ?> Logo" class="login-logo" width="56" height="56">
    </div>
    <h1><?= h($systemName) ?></h1>
    <p class="sub"><?= h($muniName) ?> — Admin sign in</p>

    <?php if ($error): ?>
      <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endif; ?>

    <form method="post" novalidate>
      <?= csrf_field() ?>
      <div class="form-group">
        <label class="required">Username</label>
        <input type="text" name="username" value="<?= h($_POST['username'] ?? '') ?>" required autofocus>
      </div>
      <div class="form-group">
        <label class="required">Password</label>
        <input type="password" name="password" required>
      </div>
      <button type="submit" class="btn btn-primary">Sign in</button>
    </form>

    <p class="demo-hint">Default login: <strong>admin</strong> / <strong>admin123</strong><br>Change this right away from General Settings.</p>
  </div>
  <div class="login-footer">Developed by <strong>Neil Justine Peras</strong></div>
</div>
</body>
</html>
