-- =====================================================================
-- UPGRADE SCRIPT v4 — adds the additional per-bill charges requested:
-- Water Amount (broken out on its own), SCF (Senior Citizen Fund),
-- Electricity, Service Loan, Surcharge, and Others — plus the settings
-- that drive the SCF and Electricity formulas.
-- =====================================================================
-- Run this if you already have the system installed. Safe to run more
-- than once (every step checks whether it already applied first).
--
-- HOW TO RUN: phpMyAdmin -> select water_billing_system database ->
-- Import tab -> choose this file -> Go.
-- =====================================================================

USE `water_billing_system`;

-- ---------------------------------------------------------------------
-- 1. New columns on `billing`
-- ---------------------------------------------------------------------

SET @col_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'water_billing_system' AND TABLE_NAME = 'billing' AND COLUMN_NAME = 'water_amount'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE billing ADD COLUMN water_amount DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER excess_amount',
  'SELECT "water_amount already exists, skipping" AS message'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'water_billing_system' AND TABLE_NAME = 'billing' AND COLUMN_NAME = 'scf_amount'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE billing ADD COLUMN scf_amount DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT "Senior Citizen Fund" AFTER water_amount',
  'SELECT "scf_amount already exists, skipping" AS message'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'water_billing_system' AND TABLE_NAME = 'billing' AND COLUMN_NAME = 'electricity_amount'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE billing ADD COLUMN electricity_amount DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER scf_amount',
  'SELECT "electricity_amount already exists, skipping" AS message'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'water_billing_system' AND TABLE_NAME = 'billing' AND COLUMN_NAME = 'service_loan'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE billing ADD COLUMN service_loan DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER electricity_amount',
  'SELECT "service_loan already exists, skipping" AS message'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'water_billing_system' AND TABLE_NAME = 'billing' AND COLUMN_NAME = 'surcharge_amount'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE billing ADD COLUMN surcharge_amount DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER service_loan',
  'SELECT "surcharge_amount already exists, skipping" AS message'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'water_billing_system' AND TABLE_NAME = 'billing' AND COLUMN_NAME = 'others_amount'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE billing ADD COLUMN others_amount DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER surcharge_amount',
  'SELECT "others_amount already exists, skipping" AS message'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ---------------------------------------------------------------------
-- 2. Backfill existing bills so nothing looks broken after the upgrade:
--    - water_amount becomes whatever the old total_amount was, minus
--      any penalty that had already been tacked onto it.
--    - the old generic penalty_amount rolls into the new surcharge_amount
--      column so overdue bills keep the extra charge they already had.
--    total_amount itself is left untouched (it's still correct).
-- ---------------------------------------------------------------------
UPDATE billing
SET water_amount = total_amount - penalty_amount,
    surcharge_amount = penalty_amount
WHERE water_amount = 0 AND scf_amount = 0 AND electricity_amount = 0;

-- ---------------------------------------------------------------------
-- 3. Settings that drive the SCF and Electricity formulas, and the
--    (renamed-in-purpose) surcharge percent.
-- ---------------------------------------------------------------------
INSERT INTO settings (setting_key, setting_value, description) VALUES
('electricity_rate', '6.5', 'Rate per m³ consumed, used to compute the Electricity charge on the bill'),
('scf_threshold', '50', 'Consumption (m³) threshold used in the Senior Citizen Fund (SCF) formula'),
('scf_base_amount', '10', 'Flat SCF amount when consumption is below the threshold; also the amount added on top of the excess above the threshold')
ON DUPLICATE KEY UPDATE setting_value = setting_value;

UPDATE settings
SET description = 'Surcharge % applied to the Water Charge (Consumption × Rate) once a bill becomes overdue and remains unpaid'
WHERE setting_key = 'penalty_percent';
