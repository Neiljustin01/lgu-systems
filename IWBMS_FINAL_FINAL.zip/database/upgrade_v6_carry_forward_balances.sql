-- =====================================================================
-- UPGRADE SCRIPT v6 — "add-and-add until paid" carry-forward balances
-- + receipt printing support (bulk 6-per-A4 and individual reprint).
-- =====================================================================
-- Run this if you already have the system installed. Safe to run more
-- than once (every step checks whether it already applied first).
--
-- HOW TO RUN: phpMyAdmin -> select water_billing_system database ->
-- Import tab -> choose this file -> Go.
--
-- WHAT THIS CHANGES (see README / chat notes for the full explanation):
--   1. Adds `billing.previous_balance` — a running total of unpaid
--      Water Charge (Cu.M x Rate) carried over from prior unpaid bills.
--      This is shown as its own "Previous Balance" line on the bill,
--      separate from the current period's own Water Charge.
--   2. From now on, SCF, Electricity, and Surcharge are themselves
--      running totals too: if a bill isn't fully paid by the time the
--      next reading/bill is generated, whatever was still owed on
--      each of those gets added on top of the new period's own amount
--      for that same line — they keep growing every unpaid month,
--      same as Previous Balance.
--   3. Adds the `disconnection_grace_days` setting, used to compute
--      the informational "Disconnection Date" printed on the bill
--      (Due Date + this many days) once a bill is overdue.
-- =====================================================================

USE `water_billing_system`;

-- ---------------------------------------------------------------------
-- 1. New column on `billing`
-- ---------------------------------------------------------------------
SET @col_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'water_billing_system' AND TABLE_NAME = 'billing' AND COLUMN_NAME = 'previous_balance'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE billing ADD COLUMN previous_balance DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT "Running unpaid Water Charge carried forward from prior bill(s) — grows every month this stays unpaid" AFTER water_amount',
  'SELECT "previous_balance already exists, skipping" AS message'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ---------------------------------------------------------------------
-- 2. New setting for the informational Disconnection Date shown on the
--    printed bill (Due Date + grace days, only once a bill is overdue).
-- ---------------------------------------------------------------------
INSERT INTO settings (setting_key, setting_value, description) VALUES
('disconnection_grace_days', '15', 'Days after Due Date before the Disconnection Date shown on the printed bill — informational only, does not affect any charge')
ON DUPLICATE KEY UPDATE setting_value = setting_value;

-- ---------------------------------------------------------------------
-- 3. Clarify what the existing surcharge setting now means (still the
--    same setting key/value — just documenting the new behavior).
-- ---------------------------------------------------------------------
UPDATE settings
SET description = 'Surcharge % applied to the unpaid Water Charge / Previous Balance each time a bill is still unpaid when the next bill is generated — the resulting surcharge then also carries forward and keeps growing until paid, same as Previous Balance'
WHERE setting_key = 'penalty_percent';
