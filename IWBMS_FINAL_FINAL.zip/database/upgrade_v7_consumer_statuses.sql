-- =====================================================================
-- UPGRADE SCRIPT v7 — additional consumer statuses
-- =====================================================================
-- Run this if you already have the system installed. Safe to run more
-- than once.
--
-- HOW TO RUN: phpMyAdmin -> select water_billing_system database ->
-- Import tab -> choose this file -> Go.
--
-- WHAT THIS CHANGES:
--   Adds three new values to `consumers.status`: 'new', 'temporary',
--   and '50/50'. All three are treated the same as 'active' throughout
--   the system (they show up in the meter reading grid and get billed
--   normally) — they're just extra labels for record-keeping.
-- =====================================================================

USE `water_billing_system`;

ALTER TABLE `consumers`
  MODIFY `status` ENUM('active','inactive','disconnected','new','temporary','50/50')
  NOT NULL DEFAULT 'active';
