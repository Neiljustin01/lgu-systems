-- =====================================================================
-- UPGRADE SCRIPT — adds the Meter Readers feature
-- =====================================================================
-- Run this ONLY if you already imported database/water_billing.sql
-- before and have existing data you want to keep.
--
-- If you are installing fresh, you don't need this file — the
-- meter_readers table and column are already included in
-- database/water_billing.sql.
--
-- HOW TO RUN: phpMyAdmin -> select water_billing_system database ->
-- Import tab -> choose this file -> Go.
-- =====================================================================

USE `water_billing_system`;

CREATE TABLE IF NOT EXISTS `meter_readers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `contact_number` VARCHAR(20) DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO `meter_readers` (`name`, `contact_number`)
SELECT * FROM (SELECT 'Juan Reyes' AS name, '09171112222' AS contact_number) AS tmp
WHERE NOT EXISTS (SELECT 1 FROM `meter_readers`);

-- Add the column only if it doesn't already exist (safe to re-run)
SET @col_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'water_billing_system'
    AND TABLE_NAME = 'readings'
    AND COLUMN_NAME = 'meter_reader_id'
);

SET @sql = IF(@col_exists = 0,
  'ALTER TABLE readings ADD COLUMN meter_reader_id INT DEFAULT NULL AFTER recorded_by, ADD FOREIGN KEY (meter_reader_id) REFERENCES meter_readers(id) ON DELETE SET NULL',
  'SELECT "Column already exists, skipping" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
