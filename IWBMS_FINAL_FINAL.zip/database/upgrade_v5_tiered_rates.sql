-- =====================================================================
-- UPGRADE SCRIPT v5 — TIERED (PROGRESSIVE) RATES
-- =====================================================================
-- Adds support for progressive/tiered pricing per m³, where the price
-- per cubic meter increases the more a consumer uses beyond the minimum
-- — e.g. Residential: ₱9.55/m³ for the 11th–20th m³, ₱10.55/m³ for the
-- 21st–30th m³, ₱11.55/m³ for every m³ after that.
--
-- Existing connection types (Institutional, Industrial, or any custom
-- type you added) keep working exactly as before with a single flat
-- rate — tiers are optional per rate. This script also adds a new
-- "Others" connection type and seeds it, along with updated Residential
-- and Commercial rates, matching the tariff schedule you provided.
--
-- Safe to run more than once — every step checks whether it already
-- applied before doing anything.
--
-- HOW TO RUN: phpMyAdmin -> select water_billing_system database ->
-- Import tab -> choose this file -> Go.
-- =====================================================================

USE `water_billing_system`;

-- ---------------------------------------------------------------------
-- 0. New column: billing.rate_id
--    Links each bill back to the exact rate row used to compute it, so
--    the bill's tier breakdown can still be shown later even if rates
--    change afterward. Nullable so past bills (generated before this
--    upgrade) keep working — they just fall back to the flat-rate line.
-- ---------------------------------------------------------------------
SET @col_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'water_billing_system' AND TABLE_NAME = 'billing' AND COLUMN_NAME = 'rate_id'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE billing ADD COLUMN rate_id INT DEFAULT NULL AFTER rate_per_cubic, ADD FOREIGN KEY (rate_id) REFERENCES rates(id) ON DELETE SET NULL',
  'SELECT "rate_id already exists, skipping" AS message'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ---------------------------------------------------------------------
-- 1. New table: rate_tiers
--    Each row is one bracket of a rate. `upto_consumption` is the
--    cumulative consumption *beyond the minimum* (m³) that this bracket
--    covers; NULL means "and beyond" (used on the last/highest bracket).
--    A rate with no rows here is just a flat rate (legacy behavior).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `rate_tiers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `rate_id` INT NOT NULL,
  `tier_order` INT NOT NULL DEFAULT 1,
  `upto_consumption` DECIMAL(10,2) DEFAULT NULL COMMENT 'Cumulative m3 beyond the minimum this bracket covers up to. NULL = unlimited (highest bracket).',
  `rate_per_cubic` DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (`rate_id`) REFERENCES `rates`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. "Others" connection type (your rate sheet's third category,
--    alongside Residential and Commercial)
-- ---------------------------------------------------------------------
INSERT INTO `connection_types` (`type_name`, `description`)
SELECT 'Others', 'Miscellaneous connections billed per your Others rate schedule'
WHERE NOT EXISTS (SELECT 1 FROM `connection_types` WHERE `type_name` = 'Others');

-- ---------------------------------------------------------------------
-- 3. RESIDENTIAL — ₱70 flat for 0–10 m³, then progressive:
--    11–20 m³ @ ₱9.55/m³, 21–30 m³ @ ₱10.55/m³, 31+ m³ @ ₱11.55/m³
-- ---------------------------------------------------------------------
INSERT INTO `rates` (`connection_type_id`, `minimum_consumption`, `minimum_charge`, `rate_per_cubic`, `effective_date`, `is_active`)
SELECT ct.id, 10.00, 70.00, 11.55, CURDATE(), 1
FROM `connection_types` ct
WHERE ct.type_name = 'Residential'
  AND NOT EXISTS (
    SELECT 1 FROM `rates` r
    WHERE r.connection_type_id = ct.id AND r.effective_date = CURDATE()
      AND r.minimum_charge = 70.00 AND r.rate_per_cubic = 11.55
  );

SET @res_rate_id = (
  SELECT r.id FROM `rates` r JOIN `connection_types` ct ON ct.id = r.connection_type_id
  WHERE ct.type_name = 'Residential' AND r.effective_date = CURDATE()
    AND r.minimum_charge = 70.00 AND r.rate_per_cubic = 11.55
  ORDER BY r.id DESC LIMIT 1
);

INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT @res_rate_id, 1, 10.00, 9.55
WHERE @res_rate_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM `rate_tiers` WHERE rate_id = @res_rate_id AND tier_order = 1);
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT @res_rate_id, 2, 20.00, 10.55
WHERE @res_rate_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM `rate_tiers` WHERE rate_id = @res_rate_id AND tier_order = 2);
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT @res_rate_id, 3, NULL, 11.55
WHERE @res_rate_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM `rate_tiers` WHERE rate_id = @res_rate_id AND tier_order = 3);

-- ---------------------------------------------------------------------
-- 4. COMMERCIAL — ₱100 flat for 0–10 m³, then progressive:
--    11–20 m³ @ ₱10.70/m³, 21–30 m³ @ ₱11.82/m³, 31+ m³ @ ₱12.94/m³
-- ---------------------------------------------------------------------
INSERT INTO `rates` (`connection_type_id`, `minimum_consumption`, `minimum_charge`, `rate_per_cubic`, `effective_date`, `is_active`)
SELECT ct.id, 10.00, 100.00, 12.94, CURDATE(), 1
FROM `connection_types` ct
WHERE ct.type_name = 'Commercial'
  AND NOT EXISTS (
    SELECT 1 FROM `rates` r
    WHERE r.connection_type_id = ct.id AND r.effective_date = CURDATE()
      AND r.minimum_charge = 100.00 AND r.rate_per_cubic = 12.94
  );

SET @com_rate_id = (
  SELECT r.id FROM `rates` r JOIN `connection_types` ct ON ct.id = r.connection_type_id
  WHERE ct.type_name = 'Commercial' AND r.effective_date = CURDATE()
    AND r.minimum_charge = 100.00 AND r.rate_per_cubic = 12.94
  ORDER BY r.id DESC LIMIT 1
);

INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT @com_rate_id, 1, 10.00, 10.70
WHERE @com_rate_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM `rate_tiers` WHERE rate_id = @com_rate_id AND tier_order = 1);
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT @com_rate_id, 2, 20.00, 11.82
WHERE @com_rate_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM `rate_tiers` WHERE rate_id = @com_rate_id AND tier_order = 2);
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT @com_rate_id, 3, NULL, 12.94
WHERE @com_rate_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM `rate_tiers` WHERE rate_id = @com_rate_id AND tier_order = 3);

-- ---------------------------------------------------------------------
-- 5. OTHERS — no flat minimum charge, billed per m³ from the start:
--    0–10 m³ @ ₱6.50/m³, 11–20 m³ @ ₱16.00/m³, 21–30 m³ @ ₱17.00/m³,
--    31+ m³ @ ₱18.00/m³
-- ---------------------------------------------------------------------
INSERT INTO `rates` (`connection_type_id`, `minimum_consumption`, `minimum_charge`, `rate_per_cubic`, `effective_date`, `is_active`)
SELECT ct.id, 0.00, 0.00, 18.00, CURDATE(), 1
FROM `connection_types` ct
WHERE ct.type_name = 'Others'
  AND NOT EXISTS (
    SELECT 1 FROM `rates` r
    WHERE r.connection_type_id = ct.id AND r.effective_date = CURDATE()
      AND r.minimum_charge = 0.00 AND r.rate_per_cubic = 18.00
  );

SET @oth_rate_id = (
  SELECT r.id FROM `rates` r JOIN `connection_types` ct ON ct.id = r.connection_type_id
  WHERE ct.type_name = 'Others' AND r.effective_date = CURDATE()
    AND r.minimum_charge = 0.00 AND r.rate_per_cubic = 18.00
  ORDER BY r.id DESC LIMIT 1
);

INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT @oth_rate_id, 1, 10.00, 6.50
WHERE @oth_rate_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM `rate_tiers` WHERE rate_id = @oth_rate_id AND tier_order = 1);
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT @oth_rate_id, 2, 20.00, 16.00
WHERE @oth_rate_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM `rate_tiers` WHERE rate_id = @oth_rate_id AND tier_order = 2);
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT @oth_rate_id, 3, 30.00, 17.00
WHERE @oth_rate_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM `rate_tiers` WHERE rate_id = @oth_rate_id AND tier_order = 3);
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT @oth_rate_id, 4, NULL, 18.00
WHERE @oth_rate_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM `rate_tiers` WHERE rate_id = @oth_rate_id AND tier_order = 4);
