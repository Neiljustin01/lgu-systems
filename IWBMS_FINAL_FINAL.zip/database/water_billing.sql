-- =====================================================================
-- MUNICIPAL WATER BILLING SYSTEM - DATABASE SCHEMA (ALL-IN-ONE)
-- =====================================================================
-- Import this ONE file in phpMyAdmin (or run via mysql CLI) for a
-- brand-new install. It already includes everything that used to be
-- spread across water_billing.sql + upgrade_v2..v5 (meter readers,
-- reader/route assignment, additional charges, tiered rates) — you do
-- NOT need to run any of the upgrade_v*.sql files after this one.
--
-- (Those upgrade_v*.sql files are still in this folder only for people
-- who already have an OLDER install and are updating it in place —
-- see README.md, section 1, for that case.)
--
-- HOW TO IMPORT (XAMPP):
-- 1. Start Apache and MySQL in the XAMPP Control Panel.
-- 2. Open http://localhost/phpmyadmin
-- 3. Click "Import" tab -> Choose this file -> Go
--    (This file already creates the database, so you don't need to
--    create it manually first.)
-- 4. Visit http://localhost/water_billing_system/login.php and sign
--    in with admin / admin123 — then change that password right away
--    from General Settings.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS `water_billing_system`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE `water_billing_system`;

-- ---------------------------------------------------------------------
-- 1. ADMIN USERS  (single-user admin login, but table supports more)
-- ---------------------------------------------------------------------
CREATE TABLE `admin_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) DEFAULT NULL,
  `last_login` DATETIME DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default login -> username: admin | password: admin123
-- (Password hash below is generated with PHP password_hash(), bcrypt)
INSERT INTO `admin_users` (`username`, `password`, `full_name`) VALUES
('admin', '$2y$10$2u2uVlt56Yevk9kUu9Kkv.qRjEsxUNQ5KUjn73Doc5Un0LlK1ywNG', 'System Administrator');

-- ---------------------------------------------------------------------
-- 2. SYSTEM SETTINGS (key/value -> fully customizable, add rows anytime)
-- ---------------------------------------------------------------------
CREATE TABLE `settings` (
  `setting_key` VARCHAR(50) PRIMARY KEY,
  `setting_value` VARCHAR(255) DEFAULT NULL,
  `description` VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB;

INSERT INTO `settings` (`setting_key`, `setting_value`, `description`) VALUES
('municipality_name', 'Municipality of Sample Town', 'Displayed on header, bills and reports'),
('province_name', 'Sample Province', 'Displayed on header, bills and reports'),
('office_name', 'Municipal Water Works Office', 'Office/department name'),
('office_address', 'Poblacion, Sample Town', 'Office address printed on bills'),
('office_contact', '(049) 000-0000', 'Contact number printed on bills'),
('currency_symbol', 'PHP', 'Currency label used across the system'),
('penalty_percent', '10', 'Surcharge % applied to the unpaid Water Charge / Previous Balance each time a bill is still unpaid when the next bill is generated — the resulting surcharge then also carries forward and keeps growing until paid, same as Previous Balance'),
('due_days', '15', 'Number of days after billing date before a bill is due'),
('logo_path', '', 'Path to uploaded municipal logo (assets/img/logo.png)'),
('system_name', 'Water Billing & Collection System', 'Title shown across the system'),
('electricity_rate', '6.5', 'Rate per m³ consumed, used to compute the Electricity charge on the bill'),
('scf_threshold', '50', 'Consumption (m³) threshold used in the Senior Citizen Fund (SCF) formula'),
('scf_base_amount', '10', 'Flat SCF amount when consumption is below the threshold; also the amount added on top of the excess above the threshold'),
('disconnection_grace_days', '15', 'Days after Due Date before the Disconnection Date shown on the printed bill — informational only, does not affect any charge');

-- ---------------------------------------------------------------------
-- 3. CONNECTION TYPES (add as many categories as needed)
-- ---------------------------------------------------------------------
CREATE TABLE `connection_types` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `type_name` VARCHAR(50) NOT NULL UNIQUE,
  `description` VARCHAR(255) DEFAULT NULL,
  `is_active` TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

INSERT INTO `connection_types` (`type_name`, `description`) VALUES
('Residential', 'Household / family connections'),
('Commercial', 'Stores, small businesses'),
('Institutional', 'Schools, government offices, churches'),
('Industrial', 'Factories and large-scale users'),
('Others', 'Miscellaneous connections billed per your Others rate schedule');

-- ---------------------------------------------------------------------
-- 4. RATES (tiered / effective-dated -> lets you change rates without
--    losing history; the newest active row per connection type is used)
-- ---------------------------------------------------------------------
CREATE TABLE `rates` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `connection_type_id` INT NOT NULL,
  `minimum_consumption` DECIMAL(10,2) NOT NULL DEFAULT 10.00,
  `minimum_charge` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `rate_per_cubic` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `effective_date` DATE NOT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`connection_type_id`) REFERENCES `connection_types`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Residential: ₱70 flat for 0–10 m³, then progressive (see rate_tiers below)
INSERT INTO `rates` (`connection_type_id`, `minimum_consumption`, `minimum_charge`, `rate_per_cubic`, `effective_date`) VALUES
((SELECT id FROM connection_types WHERE type_name = 'Residential'), 10.00, 70.00, 11.55, CURDATE());
-- Commercial: ₱100 flat for 0–10 m³, then progressive
INSERT INTO `rates` (`connection_type_id`, `minimum_consumption`, `minimum_charge`, `rate_per_cubic`, `effective_date`) VALUES
((SELECT id FROM connection_types WHERE type_name = 'Commercial'), 10.00, 100.00, 12.94, CURDATE());
-- Institutional / Industrial: flat rate, no tiers
INSERT INTO `rates` (`connection_type_id`, `minimum_consumption`, `minimum_charge`, `rate_per_cubic`, `effective_date`) VALUES
((SELECT id FROM connection_types WHERE type_name = 'Institutional'), 10.00, 130.00, 18.00, CURDATE());
INSERT INTO `rates` (`connection_type_id`, `minimum_consumption`, `minimum_charge`, `rate_per_cubic`, `effective_date`) VALUES
((SELECT id FROM connection_types WHERE type_name = 'Industrial'), 10.00, 300.00, 25.00, CURDATE());
-- Others: no flat minimum charge, billed per m³ from the start (progressive)
INSERT INTO `rates` (`connection_type_id`, `minimum_consumption`, `minimum_charge`, `rate_per_cubic`, `effective_date`) VALUES
((SELECT id FROM connection_types WHERE type_name = 'Others'), 0.00, 0.00, 18.00, CURDATE());

-- ---------------------------------------------------------------------
-- 4b. RATE TIERS — optional progressive/bracket pricing per rate.
--    `upto_consumption` is cumulative m³ *beyond the minimum* this
--    bracket covers; NULL means "and beyond" (the highest bracket).
--    A rate with no rows here is just a flat rate (see Institutional /
--    Industrial above — they intentionally have none).
-- ---------------------------------------------------------------------
CREATE TABLE `rate_tiers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `rate_id` INT NOT NULL,
  `tier_order` INT NOT NULL DEFAULT 1,
  `upto_consumption` DECIMAL(10,2) DEFAULT NULL COMMENT 'Cumulative m3 beyond the minimum this bracket covers up to. NULL = unlimited (highest bracket).',
  `rate_per_cubic` DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (`rate_id`) REFERENCES `rates`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Residential: 11–20 m³ @ ₱9.55/m³, 21–30 m³ @ ₱10.55/m³, 31+ m³ @ ₱11.55/m³
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT r.id, 1, 10.00, 9.55 FROM `rates` r JOIN `connection_types` ct ON ct.id = r.connection_type_id WHERE ct.type_name = 'Residential';
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT r.id, 2, 20.00, 10.55 FROM `rates` r JOIN `connection_types` ct ON ct.id = r.connection_type_id WHERE ct.type_name = 'Residential';
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT r.id, 3, NULL, 11.55 FROM `rates` r JOIN `connection_types` ct ON ct.id = r.connection_type_id WHERE ct.type_name = 'Residential';

-- Commercial: 11–20 m³ @ ₱10.70/m³, 21–30 m³ @ ₱11.82/m³, 31+ m³ @ ₱12.94/m³
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT r.id, 1, 10.00, 10.70 FROM `rates` r JOIN `connection_types` ct ON ct.id = r.connection_type_id WHERE ct.type_name = 'Commercial';
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT r.id, 2, 20.00, 11.82 FROM `rates` r JOIN `connection_types` ct ON ct.id = r.connection_type_id WHERE ct.type_name = 'Commercial';
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT r.id, 3, NULL, 12.94 FROM `rates` r JOIN `connection_types` ct ON ct.id = r.connection_type_id WHERE ct.type_name = 'Commercial';

-- Others: 0–10 m³ @ ₱6.50/m³, 11–20 m³ @ ₱16.00/m³, 21–30 m³ @ ₱17.00/m³, 31+ m³ @ ₱18.00/m³
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT r.id, 1, 10.00, 6.50 FROM `rates` r JOIN `connection_types` ct ON ct.id = r.connection_type_id WHERE ct.type_name = 'Others';
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT r.id, 2, 20.00, 16.00 FROM `rates` r JOIN `connection_types` ct ON ct.id = r.connection_type_id WHERE ct.type_name = 'Others';
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT r.id, 3, 30.00, 17.00 FROM `rates` r JOIN `connection_types` ct ON ct.id = r.connection_type_id WHERE ct.type_name = 'Others';
INSERT INTO `rate_tiers` (`rate_id`, `tier_order`, `upto_consumption`, `rate_per_cubic`)
SELECT r.id, 4, NULL, 18.00 FROM `rates` r JOIN `connection_types` ct ON ct.id = r.connection_type_id WHERE ct.type_name = 'Others';

-- ---------------------------------------------------------------------
-- 5. METER READERS (the field staff who take the readings)
-- ---------------------------------------------------------------------
CREATE TABLE `meter_readers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `contact_number` VARCHAR(20) DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO `meter_readers` (`name`, `contact_number`) VALUES
('Juan Reyes', '09171112222');

-- ---------------------------------------------------------------------
-- 6. CONSUMERS
-- ---------------------------------------------------------------------
CREATE TABLE `consumers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `account_number` VARCHAR(20) NOT NULL UNIQUE,
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `middle_name` VARCHAR(100) DEFAULT NULL,
  `contact_number` VARCHAR(20) DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `purok` VARCHAR(100) DEFAULT NULL,
  `barangay` VARCHAR(100) DEFAULT NULL,
  `address` VARCHAR(255) DEFAULT NULL,
  `connection_type_id` INT NOT NULL,
  `meter_number` VARCHAR(50) DEFAULT NULL,
  `meter_initial_reading` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `date_connected` DATE DEFAULT NULL,
  `status` ENUM('active','inactive','disconnected','new','temporary','50/50') NOT NULL DEFAULT 'active',
  `default_meter_reader_id` INT DEFAULT NULL COMMENT 'The reader normally assigned to this consumer''s route',
  `route_sequence` INT DEFAULT NULL COMMENT 'Manual order matching the physical meter-reading route (like the SN column in the old Excel sheet)',
  `remarks` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`connection_type_id`) REFERENCES `connection_types`(`id`),
  FOREIGN KEY (`default_meter_reader_id`) REFERENCES `meter_readers`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 7. METER READINGS (one row per consumer per Billing Month)
--    `reading_period` is stored as the calendar month the reading was
--    physically TAKEN (e.g. a reading taken in February, compared to
--    January's previous reading, is stored as "2026-02-01"). The
--    system displays and lets you pick this by its "Billing Month"
--    name instead — one month EARLIER (e.g. "January 2026") — since
--    that's the month the water was actually used. See
--    includes/functions.php -> billing_month_label().
-- ---------------------------------------------------------------------
CREATE TABLE `readings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `consumer_id` INT NOT NULL,
  `reading_period` DATE NOT NULL COMMENT 'YYYY-MM-01, the month the reading was taken. Billing Month (shown to users) = one month earlier.',
  `previous_reading` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `current_reading` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `consumption` DECIMAL(10,2) GENERATED ALWAYS AS (`current_reading` - `previous_reading`) STORED,
  `reading_date` DATE NOT NULL,
  `recorded_by` VARCHAR(100) DEFAULT NULL,
  `meter_reader_id` INT DEFAULT NULL,
  `remarks` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_reading_per_month` (`consumer_id`, `reading_period`),
  FOREIGN KEY (`consumer_id`) REFERENCES `consumers`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`meter_reader_id`) REFERENCES `meter_readers`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 8. BILLING (generated from readings, one row per consumer per
--    Billing Month — see the note on `readings.reading_period` above;
--    `billing_period` follows the exact same convention.)
-- ---------------------------------------------------------------------
CREATE TABLE `billing` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `bill_number` VARCHAR(30) NOT NULL UNIQUE,
  `consumer_id` INT NOT NULL,
  `reading_id` INT NOT NULL,
  `billing_period` DATE NOT NULL COMMENT 'YYYY-MM-01, the month the reading was taken. Billing Month (shown to users) = one month earlier.',
  `previous_reading` DECIMAL(10,2) NOT NULL,
  `current_reading` DECIMAL(10,2) NOT NULL,
  `consumption` DECIMAL(10,2) NOT NULL,
  `minimum_consumption` DECIMAL(10,2) NOT NULL,
  `minimum_charge` DECIMAL(10,2) NOT NULL,
  `rate_per_cubic` DECIMAL(10,2) NOT NULL,
  `rate_id` INT DEFAULT NULL COMMENT 'The exact rate row used, so tier breakdown can still be shown later even if rates change afterward',
  `excess_consumption` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `excess_amount` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `water_amount` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `previous_balance` DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT 'Running unpaid Water Charge carried forward from prior bill(s) — grows every month this stays unpaid',
  `scf_amount` DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT 'Senior Citizen Fund',
  `electricity_amount` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `service_loan` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `surcharge_amount` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `others_amount` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `penalty_amount` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `total_amount` DECIMAL(10,2) NOT NULL,
  `amount_paid` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `balance` DECIMAL(10,2) NOT NULL,
  `billing_date` DATE NOT NULL,
  `due_date` DATE NOT NULL,
  `status` ENUM('unpaid','partial','paid','overdue') NOT NULL DEFAULT 'unpaid',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_bill_per_month` (`consumer_id`, `billing_period`),
  FOREIGN KEY (`consumer_id`) REFERENCES `consumers`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`reading_id`) REFERENCES `readings`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`rate_id`) REFERENCES `rates`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 9. PAYMENTS (supports partial payments; multiple rows per bill)
-- ---------------------------------------------------------------------
CREATE TABLE `payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `billing_id` INT NOT NULL,
  `or_number` VARCHAR(50) DEFAULT NULL COMMENT 'Official Receipt number',
  `amount_paid` DECIMAL(10,2) NOT NULL,
  `payment_date` DATE NOT NULL,
  `received_by` VARCHAR(100) DEFAULT NULL,
  `remarks` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`billing_id`) REFERENCES `billing`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Sample consumers so you can try the system immediately (optional -
-- feel free to delete these rows once you add your real consumers)
-- ---------------------------------------------------------------------
INSERT INTO `consumers`
(`account_number`, `first_name`, `last_name`, `middle_name`, `contact_number`, `purok`, `barangay`, `address`, `connection_type_id`, `meter_number`, `meter_initial_reading`, `date_connected`, `status`, `default_meter_reader_id`, `route_sequence`)
VALUES
('2026-0001', 'Juan', 'Dela Cruz', 'Santos', '09171234567', 'Purok 1', 'Poblacion', 'Poblacion, Sample Town', (SELECT id FROM connection_types WHERE type_name = 'Residential'), 'MTR-0001', 0, '2024-01-15', 'active', 1, 10),
('2026-0002', 'Maria', 'Reyes', 'Lopez', '09181234567', 'Purok 3', 'San Isidro', 'San Isidro, Sample Town', (SELECT id FROM connection_types WHERE type_name = 'Residential'), 'MTR-0002', 0, '2024-02-10', 'active', 1, 20),
('2026-0003', 'Sample Sari-Sari Store', 'Garcia', '', '09991234567', 'Purok 2', 'Poblacion', 'Poblacion, Sample Town', (SELECT id FROM connection_types WHERE type_name = 'Commercial'), 'MTR-0003', 0, '2024-03-05', 'active', NULL, NULL);
