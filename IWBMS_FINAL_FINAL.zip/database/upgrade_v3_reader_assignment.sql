-- =====================================================================
-- UPGRADE SCRIPT v3 — adds per-consumer reader assignment + route order
-- =====================================================================
-- Run this if you already have the system installed (with or without
-- the v2 meter_readers upgrade already applied). Safe to run more than
-- once.
--
-- HOW TO RUN: phpMyAdmin -> select water_billing_system database ->
-- Import tab -> choose this file -> Go.
--
-- If you haven't installed the system at all yet, or haven't run
-- upgrade_v2_meter_readers.sql, run that one FIRST, then this one.
-- =====================================================================

USE `water_billing_system`;

-- Add default_meter_reader_id if missing
SET @col_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'water_billing_system'
    AND TABLE_NAME = 'consumers'
    AND COLUMN_NAME = 'default_meter_reader_id'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE consumers ADD COLUMN default_meter_reader_id INT DEFAULT NULL AFTER status, ADD FOREIGN KEY (default_meter_reader_id) REFERENCES meter_readers(id) ON DELETE SET NULL',
  'SELECT "default_meter_reader_id already exists, skipping" AS message'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add route_sequence if missing
SET @col_exists2 = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'water_billing_system'
    AND TABLE_NAME = 'consumers'
    AND COLUMN_NAME = 'route_sequence'
);
SET @sql2 = IF(@col_exists2 = 0,
  'ALTER TABLE consumers ADD COLUMN route_sequence INT DEFAULT NULL AFTER default_meter_reader_id',
  'SELECT "route_sequence already exists, skipping" AS message'
);
PREPARE stmt2 FROM @sql2;
EXECUTE stmt2;
DEALLOCATE PREPARE stmt2;
