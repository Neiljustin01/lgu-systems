# Municipal Water Billing & Collection System

A complete, single-admin PHP + MySQL water billing system built for XAMPP:
consumers, monthly meter readings, billing, payments, and collection reports —
all customizable from the app itself (no code changes needed for day-to-day use).

## 0. What changed in this update

- **Fix: the single "Print" button on a bill was broken.** It pointed to
  the wrong file internally and threw the friendly "Something went wrong"
  error page instead of opening the receipt. It's fixed now — and while
  fixing it, that page was rebuilt into a full plain-language receipt (see
  "NEW: Full-page consumer receipt" further down).
- **NEW: Billing list now shows Reading Date and Due Date.** Billing →
  Bills previously only showed the Billing Month; now each row also shows
  the exact date that month's meter reading was taken and the bill's Due
  Date (highlighted red once overdue), so you can see both without opening
  every bill.
- **NEW: Surcharge is now Consumption x Rate, not a percentage.** Per
  Neil's municipal ordinance, the Surcharge on a bill is now automatically
  equal to the *prior* unpaid bill's own Consumption (cu.m) multiplied by
  the Rate per Cubic Meter it was billed at — effectively a second Water
  Charge, added fresh every time a new bill is generated while that prior
  bill is still not fully paid (unpaid, partial, *or* overdue — it no
  longer waits for the due date to pass). The old "Surcharge Percent"
  setting is gone; Settings → General now just explains the formula. Like
  Previous Balance, it keeps compounding — see the next bullet. The
  full-page receipt (see below) shows the exact math: how much is new
  this cycle (prior bill's m³ x rate) vs. carried over from earlier.
- **NEW: Bills now carry forward "add-and-add until paid."** If a consumer's
  bill isn't fully paid by the time their next reading comes in, the unpaid
  **Water Charge becomes a "Previous Balance" line** on the new bill, and
  **SCF, Electricity, and Surcharge each keep growing too** — every month
  it stays unpaid, whatever was still owed on each of those gets added on
  top of that month's own fresh amount for the same line, right alongside
  that month's own new charges. See
  `database/upgrade_v6_carry_forward_balances.sql` for the full
  explanation of the carry-forward mechanics (the Surcharge *formula*
  itself is documented in the bullet above, since it changed after that
  file was written).
  - **One simplification to know about:** payments are recorded as a single
    lump sum against a bill (same as before), so there's no way to know
    which specific charge a *partial* payment actually covered. A bill
    that's fully unpaid carries its Water Charge/SCF/Electricity/Surcharge
    forward separately as described above; a bill that was *partially*
    paid instead rolls its entire remaining balance forward as one lump
    "Previous Balance" line, and starts fresh on SCF/Electricity/Surcharge
    for the new month. Every peso is still accounted for either way.
- **NEW: Print receipts, 6-per-A4-sheet.** Billing → **🖨️ Print Receipts**
  lets you pick a Billing Month, select consumers (or Select All), and
  print a compact "Statement of Account" stub for each — six per sheet, in
  meter-reader route order, ready to cut and hand out. The stub shows:
  Billing Month, Meter Number, Connection Type, Due Date (next to Period
  Covered), Account No., Disconnection Date, consumer Name & Address,
  Period Covered, Present/Previous reading, Cu.M Used, Water Charge,
  Previous Balance, Surcharge, SCF, Electricity, Service Loan, and Total
  Amount Due. "Disconnection Date" is informational only (Due Date + a
  configurable grace period, Settings → Disconnection Grace) — it never
  changes any charge, it's just the notice printed on the bill once it's
  overdue.
- **NEW: Full-page consumer receipt.** Missed someone on the 6-per-sheet
  run, or just want something clearer to hand a consumer or email? Use the
  **🖨️ Print** button next to any bill in the Billing list (or on the
  bill's own page). Unlike the compact stub above, this is a full sheet of
  paper laid out for a consumer who isn't familiar with billing jargon:
  a plain-language note under every charge (e.g. Surcharge shows exactly
  which prior bill it's penalizing and the m³ x rate math behind it), a
  big Total Amount Due box, a clear paid/unpaid/overdue status banner, and
  — once a payment is on file — the OR number and amount paid shown right
  on the receipt. It pulls from the exact same bill record as the compact
  stub, so the numbers always match; only the layout differs.
- **New: Export & Backup Data** (sidebar → Reports → Export & Backup):
  - Export any single **Billing Month** — or your **entire billing history** —
    as a CSV spreadsheet that opens directly in Excel, with every important
    column: consumer info, readings, full charge breakdown, payment status,
    and balances.
  - Separate exports for **Payments** and **Meter Readings**, per month or all-time.
  - **Consumers Master List** export (full roster, one click).
  - **Full Database Backup** — downloads one `.sql` file containing everything
    (consumers, readings, bills, payments, rates, settings) without needing
    phpMyAdmin or any command-line tool. Since this system is fully offline,
    nothing is backed up anywhere else automatically — download this after
    big batches of work (e.g. right after generating a month's bills, or a
    big collection day) and keep the file somewhere safe (USB drive, another
    computer, cloud storage). Restoring it later is the same as any
    phpMyAdmin import: Import tab → choose the file → Go.
- **More resilient against crashes and interruptions:**
  - Saving readings in bulk, generating bills in bulk, and recording bulk
    payments are now wrapped in database transactions — if something
    interrupts a save partway through (power blip, MySQL stopping, etc.),
    nothing is left half-saved; either the whole batch goes through or none
    of it does, and you get a clear message to just try again.
  - Any unexpected error anywhere in the system now shows a calm, plain-English
    "something went wrong, nothing was lost" page instead of a blank screen
    or a scary technical error — details are written to `logs/app_errors.log`
    for troubleshooting, never shown to whoever is using the system.
  - The `config/`, `database/`, `includes/`, and `logs/` folders are now
    blocked from direct web access (via `.htaccess`), so database credentials,
    error logs, and internal helper files can never be opened directly in a
    browser.
- **"Billing Month" is now unambiguous everywhere.** A reading taken in
  February (compared against January's previous reading) is now labeled
  **"January 2026"** throughout the system — bills, reports, printouts, the
  dashboard — because that's the month the water was actually used. Every
  screen also shows the exact readings it's comparing, e.g. *"January 2026
  (readings Jan 2026 → Feb 2026)"*, so it's always clear which two meter
  readings a bill is based on.
- **Picking a billing month is now a click, not typing.** Every screen that
  used a raw month box now uses the same dropdown, listing each choice by its
  Billing Month name (see above) so you can see and click exactly the month
  you mean, instead of guessing what a bare "02/2026" refers to.
- **Payments now start with "🧾 Input OR#".** The old "Pay" button is now
  labeled **Input OR#** everywhere (bill list, bill detail), and the payment
  screen puts the **OR Number** field first with the cursor already in it —
  the amount is pre-filled with the full balance, so recording a payment is
  usually just: click Input OR#, type the receipt number, Save.
- Printing a report (Monthly Summary, Statement of Account) no longer prints
  the sidebar/navigation menu along with it.
- Fresh installs are now a single SQL file — see Setup below.

## 1. Setup on XAMPP

1. Copy the whole `water_billing_system` folder into your XAMPP `htdocs` folder, e.g.
   `C:\xampp\htdocs\water_billing_system`.
2. Open the **XAMPP Control Panel** and start **Apache** and **MySQL**.
3. Go to `http://localhost/phpmyadmin`.
4. Click **Import**, choose `database/water_billing.sql`, then click **Go**.
   This ONE file creates the `water_billing_system` database with every table,
   column, default setting, rate/tier, and 3 sample consumers — it already
   includes everything that used to require importing 5 separate files, so a
   fresh install is now just this single step.
5. Visit `http://localhost/water_billing_system/login.php`.
6. Log in with:
   - **Username:** `admin`
   - **Password:** `admin123`
7. Immediately go to **General Settings** and change the password, and update
   your municipality name/address/logo info.

If MySQL in your XAMPP install uses a different user/password than the default
(`root` / no password), edit `config/database.php` and update the 4 constants
at the top.

**If your consumer list grows past a few hundred:** bulk actions that select
many rows at once — Generate Bills and Bulk Print Receipts — are limited by a
PHP setting called `max_input_vars` (default 1000, meaning roughly 1000 rows
in one submission). The system now detects this and warns you clearly if a
batch gets cut short instead of silently skipping consumers, and it's always
safe to just click the button again to finish the rest. But if you'd rather
avoid batching altogether, raise the limit once: open
`C:\xampp\php\php.ini`, find the line starting with `max_input_vars`, change
it to `max_input_vars = 5000` (or higher), save, then restart Apache from the
XAMPP Control Panel.

**Already had this system installed before (before this update)?** You don't
need to start over — in phpMyAdmin, select your existing
`water_billing_system` database, go to **Import**, and run these files (in
order, if you haven't already):
`database/upgrade_v2_meter_readers.sql`, then `database/upgrade_v3_reader_assignment.sql`,
then `database/upgrade_v4_additional_charges.sql`, then `database/upgrade_v5_tiered_rates.sql`,
then `database/upgrade_v6_carry_forward_balances.sql`.
All of them only add new tables/columns and are safe to run more than once.
(Brand-new installs should skip these and just import `database/water_billing.sql` —
step 4 above already includes all five.)

**v5 (tiered rates)** adds progressive/bracket pricing — where the price per m³
increases the more a consumer uses — and seeds it with Residential, Commercial,
and a new "Others" connection type using the rates: 0–10 m³ at a flat minimum
charge (₱70 / ₱100 / none), then a higher ₱/m³ rate for 11–20 m³, higher still
for 21–30 m³, and higher still for 31+ m³. Existing connection types (like
Institutional, Industrial, or any you added yourself) are untouched and keep
billing at their existing flat rate. See **Settings → Rates & Connection Types**
to view or add tiered pricing for any connection type going forward.

## 2. How the system is organized

| Folder        | What it does |
|----------------|--------------|
| `consumers/`   | Add / edit / view / delete consumers (households, businesses, etc.) |
| `readings/`    | Record each consumer's monthly meter reading — grid.php is the main bulk-entry screen |
| `billing/`     | Generate bills from readings, record payments, print bills |
| `reports/`     | Monthly collection summary, per-consumer statement of account, export & backup |
| `settings/`    | Manage connection types & rates, meter readers, and general system settings |
| `config/`      | Database connection settings (blocked from direct web access) |
| `includes/`    | Shared header/footer/sidebar and helper functions (blocked from direct web access) |
| `database/`    | The SQL file you import into phpMyAdmin (blocked from direct web access) |
| `logs/`        | `app_errors.log` — technical details of anything that went wrong, for troubleshooting (blocked from direct web access) |

## 3. Recording meter readings (bulk grid)

**Meter Readings** in the sidebar opens `readings/grid.php` — a spreadsheet-style
screen for encoding a whole billing period at once:

1. Pick the **Billing Month** from the dropdown, e.g. **"January 2026"** —
   shown with the exact readings it covers, e.g. *"(readings Jan 2026 → Feb
   2026)"*. This means: previous reading = January's reading, present
   reading = the one you're entering now, taken in February.
2. Every consumer shows up as one row: Name, Meter #, Address, **Previous**
   (auto-filled from last month — you never type this), and **Present**
   (type it in). Cu.M. Used calculates itself live as you type.
3. Pick a **Meter Reader** and a reading date at the top (applies to
   everything you save in that batch), then click **Save All Readings**.
4. You can leave rows blank and come back later — only the rows you fill in
   get saved. Re-opening the same period shows already-saved values so you
   can review or correct them (saving again just updates that row, it never
   duplicates).
5. For a period nobody has read yet (including future months), both
   Previous and Present show 0 / blank, exactly as expected — nothing to
   configure.
6. Use the **Search** box to jump to a specific consumer, click column
   headers to **sort**, and use **🖨️ Print** to get a paper worksheet
   (useful for field readers, or as a paper backup of the encoded data).
7. **View as List** switches to a simpler one-row-per-reading table for
   quick single edits (useful for correcting a typo without opening the
   whole grid).

Manage the roster of field staff in **Settings → Meter Readers**. Deleting a
reader never deletes their past readings — it just clears the reader name
from that history.

### Matching your old per-reader Excel sheets

If (like most offices moving off Excel) each reader normally covers the same
set of consumers every period, tell the system that once and it remembers:

1. Open a consumer's **Edit** page (or **Consumers** list) and set their
   **Assigned Meter Reader** and **Route Order #** (the same idea as the old
   "SN" column — it controls the walking/printing order, not alphabetical).
2. To do this for many consumers at once: go to **Consumers**, check the
   boxes for the people on one reader's route, choose that reader in the
   "Assign selected consumers to" box at the top, and click **Apply to
   Selected** — this also auto-numbers their route order in the sequence
   they appear on screen (you can fine-tune numbers later by editing a
   consumer directly).
3. Back in **Meter Readings**, pick that reader from the **Meter Reader**
   filter. The grid narrows to just their consumers, sorted by route order,
   and the "Meter Reader" field for saving is pre-selected to match — one
   less click.
4. **🖨️ Print** while a reader is selected to get that reader's own sheet,
   the same way you used to hand out a printed tab from Excel.

### Encoding fast, Excel-style

Once the readers hand their filled sheets back, open the same period +
reader filter and just type down the **Present** column:
- Press **Enter** (or **↓**) after each value to jump straight to the next
  row — no mouse, no "Edit" button, just type and Enter like a spreadsheet.
- Cu.M. Used fills in instantly as you type.
- The page focuses the first still-empty row automatically when it loads.
- Click **💾 Save All Readings** once you're done with the batch (or a page
  of it — you can always come back and finish the rest later).

## 4. Then: billing and collections

1. **Billing → Generate Bills** → pick the period, review the estimated
   amounts, and generate bills in bulk for every reading that doesn't have
   one yet.
2. **Billing** → click **🧾 Input OR#** as residents pay — the OR Number
   field is first and ready to type in, with the amount already filled in
   for you (partial payments are supported — just change the amount; the
   balance carries over and the status updates automatically).
3. **Reports → Monthly Summary** → see total billed, total collected,
   breakdown per connection type, daily collections, and outstanding accounts
   for any period.

Bills that pass their due date are automatically marked **overdue** and a
penalty (percentage, configurable in General Settings) is applied the next
time any page loads — no manual step needed.

## 5. Exporting data & backing up

Open **Reports → Export & Backup** in the sidebar for all of this:

1. **Billing Month Export** — pick any Billing Month and download it as a
   CSV spreadsheet with every important column: consumer info, meter
   readings, the full charge breakdown (Water, SCF, Electricity, Service
   Loan, Surcharge, Others), total amount, amount paid, balance, and status.
   Separate one-click exports are also available for just that month's
   **Payments** or just that month's **Meter Readings**.
2. **Full History Export** — the same three exports, but for every Billing
   Month the system has ever recorded, in one file. Good for year-end
   reports, audits, or moving everything into Excel at once.
3. **Consumers Master List** — the full consumer roster (contact info,
   address, meter number, connection type, assigned reader) as one CSV.
4. **Full Database Backup** — downloads one `.sql` file with absolutely
   everything (consumers, readings, bills, payments, rates, settings). Since
   this system runs offline on your own computer, nothing is backed up
   anywhere else automatically — get in the habit of downloading this after
   big batches of work (e.g. right after generating a month's bills, or a
   big collection day) and keeping the file somewhere safe: a USB drive,
   another computer, or cloud storage. To restore it later: phpMyAdmin →
   select the `water_billing_system` database → **Import** tab → choose the
   file → **Go**.

## 6. Making it flexible / customizing later

- **Add a new connection type** (e.g. "Government", "Bulk Water"): Settings →
  Rates & Types → Add New Connection Type.
- **Change prices**: Settings → Rates & Types → Add New Rate. Pick an
  effective date — bills already generated keep the old rate, and any bill
  generated from that date forward uses the new one. Nothing is overwritten,
  so your rate history stays intact.
- **Add more fields to a consumer** (e.g. GPS coordinates, senior citizen
  discount flag): add the column in phpMyAdmin (`ALTER TABLE consumers ADD
  COLUMN ...`), then add a matching `<input>` in `consumers/add.php` and
  `consumers/edit.php`, and display it in `consumers/view.php`. The rest of
  the system does not need to change.
- **Change the billing formula**: everything funnels through the single
  `calculate_bill_amount()` function in `includes/functions.php` — edit it
  once and every bill going forward uses the new formula.
- **Change the branding/colors**: edit `assets/css/style.css` — the CSS
  variables at the top of the file (`--navy-900`, `--teal-600`, etc.)
  control the whole color scheme.

## 7. Security notes

This is built as a single-admin, local/LAN tool (matching how most small
municipal offices run this kind of system on XAMPP). Before exposing it
beyond your local network:
- Change the default admin password right away.
- Consider adding HTTPS if this will run beyond `localhost`.
- Take regular backups — the easiest way is **Reports → Export & Backup →
  Download Full Backup (.sql)**, right in the app. (phpMyAdmin's Export tab
  works too, if you prefer that.)
- Sensitive folders (`config/`, `database/`, `includes/`, `logs/`) already
  have `.htaccess` files blocking direct web access. This works automatically
  on most XAMPP installs; if your Apache config has `AllowOverride None` for
  `htdocs`, ask whoever manages the server to enable `AllowOverride All` (or
  add the equivalent `Require all denied` block directly in the Apache
  config) so these `.htaccess` rules take effect.
- If anything ever goes wrong, the system shows a plain "something went
  wrong, nothing was lost" message instead of a technical error page —
  check `logs/app_errors.log` for the technical details if you need to
  troubleshoot or ask for help.
