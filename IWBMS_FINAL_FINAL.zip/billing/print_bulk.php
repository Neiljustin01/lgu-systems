<?php
$pageTitle = 'Bulk Print Receipts';
$pageSub   = 'Select which consumer receipts to print — 6 per A4 sheet, in meter-reading route order';
$activeNav = 'billing';
$backUrl   = 'list.php';
$backLabel = 'Back to Billing';
require_once __DIR__ . '/../includes/header.php';

refresh_overdue_bills($pdo);

$period = $_GET['period'] ?? date('Y-m');
$periodDate = date('Y-m-01', strtotime($period . '-01'));
$status = $_GET['status'] ?? '';
$search = trim($_GET['q'] ?? '');
$readerFilter = $_GET['reader'] ?? '';

$where = ["b.billing_period = :period"];
$params = ['period' => $periodDate];

if ($status !== '') {
    $where[] = "b.status = :status";
    $params['status'] = $status;
}
if ($search !== '') {
    $where[] = "(c.first_name LIKE :s1 OR c.last_name LIKE :s2 OR c.account_number LIKE :s3 OR b.bill_number LIKE :s4)";
    $params['s1'] = "%$search%";
    $params['s2'] = "%$search%";
    $params['s3'] = "%$search%";
    $params['s4'] = "%$search%";
}
if ($readerFilter !== '') {
    if ($readerFilter === 'none') {
        $where[] = "c.default_meter_reader_id IS NULL";
    } else {
        $where[] = "c.default_meter_reader_id = :reader";
        $params['reader'] = $readerFilter;
    }
}

$sql = "
    SELECT b.id, b.bill_number, b.total_amount, b.status, c.first_name, c.last_name, c.account_number, c.route_sequence, mr.name AS reader_name
    FROM billing b
    JOIN consumers c ON c.id = b.consumer_id
    LEFT JOIN meter_readers mr ON mr.id = c.default_meter_reader_id
    WHERE " . implode(' AND ', $where) . "
    ORDER BY (c.route_sequence IS NULL), c.route_sequence ASC, c.last_name, c.first_name
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$bills = $stmt->fetchAll();

$meterReaders = $pdo->query("
    SELECT mr.*, (SELECT COUNT(*) FROM consumers c2 WHERE c2.default_meter_reader_id = mr.id) AS consumer_count
    FROM meter_readers mr
    WHERE mr.is_active = 1
    ORDER BY mr.name
")->fetchAll();

// Diagnostic: if a specific reader filter returned nothing, figure out why —
// either duplicate reader entries sharing a name, or an assigned/billed mismatch.
$readerDiagnostic = null;
if (empty($bills) && $readerFilter !== '' && $readerFilter !== 'none') {
    $stmt = $pdo->prepare("SELECT name FROM meter_readers WHERE id = :id");
    $stmt->execute(['id' => $readerFilter]);
    $selectedReaderName = $stmt->fetchColumn();

    if ($selectedReaderName !== false) {
        $stmt = $pdo->prepare("SELECT id FROM meter_readers WHERE name = :name");
        $stmt->execute(['name' => $selectedReaderName]);
        $duplicateIds = $stmt->fetchAll(PDO::FETCH_COLUMN);

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM consumers WHERE default_meter_reader_id = :id");
        $stmt->execute(['id' => $readerFilter]);
        $assignedCount = (int)$stmt->fetchColumn();

        if (count($duplicateIds) > 1) {
            $readerDiagnostic = "Heads up: there's more than one meter reader named \"$selectedReaderName\" in your system (IDs: "
                . implode(', ', $duplicateIds) . "). You may have selected a different one than the one actually "
                . "assigned to these consumers. Go to Settings &rarr; Meter Readers to check for and clean up the duplicate.";
        } elseif ($assignedCount > 0) {
            $readerDiagnostic = "$assignedCount consumer(s) are assigned to \"$selectedReaderName\", but none of them "
                . "have a bill for this Billing Month yet. Double-check the Billing Month, or generate bills for this "
                . "period first.";
        } else {
            $readerDiagnostic = "\"$selectedReaderName\" currently has no consumers assigned to it. Assign consumers "
                . "to this reader from the Consumers page first.";
        }
    }
}
?>

<div class="card">
  <div class="card-header">
    <h2>Receipts to Print <span class="text-muted">(<?= count($bills) ?>)</span></h2>
  </div>

  <form method="get" class="form-row" style="margin-bottom:18px;">
    <div class="form-group mb-0">
      <label>Billing Month</label>
      <?= billing_month_select('period', $period, '') ?>
    </div>
    <div class="form-group mb-0">
      <label>Status</label>
      <select name="status">
        <option value="">All statuses</option>
        <?php foreach (['unpaid','partial','paid','overdue'] as $s): ?>
          <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group mb-0">
      <label>Meter Reader</label>
      <select name="reader">
        <option value="">All readers</option>
        <option value="none" <?= $readerFilter === 'none' ? 'selected' : '' ?>>— Not yet assigned —</option>
        <?php foreach ($meterReaders as $mr): ?>
          <option value="<?= $mr['id'] ?>" <?= (string)$readerFilter === (string)$mr['id'] ? 'selected' : '' ?>><?= h($mr['name']) ?> (<?= (int)$mr['consumer_count'] ?>)</option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group mb-0">
      <label>Search</label>
      <input type="text" name="q" value="<?= h($search) ?>" placeholder="Name, account #, or bill #">
    </div>
    <div class="form-group mb-0" style="align-self:end;">
      <button class="btn btn-outline" type="submit">Filter</button>
      <a href="print_bulk.php" class="btn btn-outline">Reset</a>
    </div>
  </form>

  <?php if (empty($bills)): ?>
    <div class="empty-state">
      <div class="ico">🧾</div>No bills match your filters for this Billing Month.
      <?php if ($readerDiagnostic): ?>
        <p class="hint" style="margin-top:10px; color:#7a2020;"><?= $readerDiagnostic ?></p>
      <?php endif; ?>
    </div>
  <?php else: ?>
  <p class="hint">Receipts print 6 per A4 sheet, in meter-reading route order (Consumers → route sequence). Uncheck anyone you don't want to (re)print — e.g. bills already handed out — then print just the rest.</p>
  <form method="post" action="print_bulk_output.php" target="print_preview">
    <?= csrf_field() ?>
    <input type="hidden" name="period" value="<?= h($period) ?>">
    <input type="hidden" name="expected_count" value="<?= (int)count($bills) ?>">
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th style="width:34px;"><input type="checkbox" id="checkAll" checked></th>
            <th>Route #</th><th>Account #</th><th>Consumer</th><th>Bill #</th><th>Reader</th>
            <th class="num">Total Amount Due</th><th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($bills as $b): ?>
          <tr>
            <td><input type="checkbox" name="ids[]" value="<?= $b['id'] ?>" class="rowcheck" checked></td>
            <td><?= h($b['route_sequence'] ?? '—') ?></td>
            <td><?= h($b['account_number']) ?></td>
            <td><?= h($b['last_name'] . ', ' . $b['first_name']) ?></td>
            <td><?= h($b['bill_number']) ?></td>
            <td><?= h($b['reader_name'] ?? '—') ?></td>
            <td class="num"><?= money($pdo, $b['total_amount']) ?></td>
            <td><?= status_badge($b['status']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="row-actions" style="margin-top:16px;">
      <button type="submit" class="btn btn-primary">🖨️ Print Selected Receipts</button>
      <a href="list.php?period=<?= h($period) ?>" class="btn btn-outline">Back to Billing</a>
    </div>
  </form>
  <?php endif; ?>
</div>

<script>
document.getElementById('checkAll')?.addEventListener('change', function () {
  document.querySelectorAll('.rowcheck').forEach(cb => cb.checked = this.checked);
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
