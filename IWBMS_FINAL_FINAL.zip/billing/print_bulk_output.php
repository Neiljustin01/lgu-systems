<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/bill_stub.php';

refresh_overdue_bills($pdo);

// Two ways to arrive here:
//  1. POST with ids[] — a specific selection from print_bulk.php's checkboxes.
//  2. GET with period (+ optional status/q) — "print the whole month" with
//     no selection page at all, same filter shape as the Ledger print.
$truncationWarning = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['ids'])) {
    require_csrf();
    $ids = array_values(array_unique(array_map('intval', $_POST['ids'])));
    $ids = array_filter($ids);
    if (empty($ids)) {
        die('No bills selected.');
    }

    // Same max_input_vars safety net as bulk bill generation: warn instead
    // of silently printing fewer receipts than were checked.
    $expectedSelectedCount = (int)($_POST['expected_count'] ?? 0);
    if ($expectedSelectedCount > 0 && count($ids) < $expectedSelectedCount) {
        $missed = $expectedSelectedCount - count($ids);
        $truncationWarning = "Only " . count($ids) . " of $expectedSelectedCount selected receipt(s) are shown below — "
            . "$missed were not submitted because your browser sent more items than this server's PHP configuration "
            . "(max_input_vars) allows at once. Go back and print the rest in a second batch.";
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare(bill_stub_select_sql(
        "WHERE b.id IN ($placeholders)
         ORDER BY (c.route_sequence IS NULL), c.route_sequence ASC, c.last_name, c.first_name"
    ));
    $stmt->execute($ids);
    $bills = $stmt->fetchAll();
    $period = $_POST['period'] ?? ($bills[0]['billing_period'] ?? date('Y-m'));
} else {
    $period = $_GET['period'] ?? date('Y-m');
    $periodDate = date('Y-m-01', strtotime($period . '-01'));
    $status = $_GET['status'] ?? '';
    $search = trim($_GET['q'] ?? '');
    $readerFilter = $_GET['reader'] ?? '';

    $where = ["b.billing_period = :period"];
    $params = ['period' => $periodDate];
    if ($status !== '') {
        $where[] = "b.status = :status";
        $params['status'] = $status;
    }
    if ($search !== '') {
        $where[] = "(c.first_name LIKE :s1 OR c.last_name LIKE :s2 OR c.account_number LIKE :s3 OR b.bill_number LIKE :s4)";
        $params['s1'] = "%$search%";
        $params['s2'] = "%$search%";
        $params['s3'] = "%$search%";
        $params['s4'] = "%$search%";
    }
    if ($readerFilter !== '') {
        if ($readerFilter === 'none') {
            $where[] = "c.default_meter_reader_id IS NULL";
        } else {
            $where[] = "c.default_meter_reader_id = :reader";
            $params['reader'] = $readerFilter;
        }
    }
    $stmt = $pdo->prepare(bill_stub_select_sql(
        "WHERE " . implode(' AND ', $where) . "
         ORDER BY (c.route_sequence IS NULL), c.route_sequence ASC, c.last_name, c.first_name"
    ));
    $stmt->execute($params);
    $bills = $stmt->fetchAll();
}

$chunks = array_chunk($bills, 6);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Print Receipts — <?= h($period) ?></title>
<style>
  body { background: #fff; margin: 0; font-family: Arial, Helvetica, sans-serif; }
  .toolbar { text-align: right; padding: 14px 16px; }
  .btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; border-radius: 8px; border: 1px solid #ccc; background: #fff; cursor: pointer; font-size: 13px; text-decoration: none; color: #111; }
  .btn-primary { background: #123a63; color: #fff; border-color: #123a63; }
  .stub-sheet {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: repeat(3, 1fr);
    gap: 3mm;
    width: 190mm;
    height: 273mm;
    margin: 0 auto 6mm;
    padding: 0;
  }
  <?= bill_stub_css() ?>
  @media print {
    .toolbar, .no-print { display: none !important; }
    @page { size: A4 portrait; margin: 10mm; }
    .stub-sheet { width: auto; height: auto; margin: 0; page-break-after: always; }
    .stub-sheet:last-of-type { page-break-after: auto; }
  }
  @media screen {
    .stub-sheet { border: 1px dashed #ccc; padding: 4mm; box-sizing: border-box; }
  }
</style>
</head>
<body>
  <div class="toolbar no-print">
    <button onclick="window.print()" class="btn btn-primary">🖨️ Print</button>
    <a href="print_bulk.php?period=<?= h($period) ?>" class="btn">Back to Selection</a>
  </div>

  <?php if ($truncationWarning): ?>
    <div class="no-print" style="max-width:640px;margin:0 auto 16px;padding:14px 18px;
                background:#fdf3f3;border:1px solid #e2b8b8;border-radius:8px;color:#7a2020;">
      ⚠️ <?= h($truncationWarning) ?>
    </div>
  <?php endif; ?>

  <?php if (empty($bills)): ?>
    <p style="text-align:center; padding:40px;">No bills to print.</p>
  <?php else: ?>
    <?php foreach ($chunks as $chunk): ?>
      <div class="stub-sheet">
        <?php foreach ($chunk as $bill): ?>
          <div class="stub"><?= render_bill_stub($pdo, $bill) ?></div>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
  <script>
    // This page is opened in its own tab just to print — close it
    // automatically once the print dialog closes so tabs don't pile up.
    window.addEventListener('afterprint', function () {
      if (window.opener) { window.close(); }
    });
  </script>
</body>
</html>
