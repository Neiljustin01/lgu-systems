<?php
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    set_flash('error', 'Invalid request method.');
    redirect('list.php');
}
require_csrf();

// Preserve whatever filters the admin had applied, so after deleting
// they land back on the same filtered view instead of "All Billing Months".
$period = $_POST['period'] ?? '';
$status = $_POST['status'] ?? '';
$search = $_POST['q'] ?? '';
$backQuery = http_build_query(['period' => $period, 'status' => $status, 'q' => $search]);

$ids = $_POST['ids'] ?? [];
$ids = array_values(array_unique(array_filter(array_map('intval', (array)$ids))));

if (empty($ids)) {
    set_flash('error', 'No bills were selected.');
    redirect('list.php?' . $backQuery);
}

$deleted = [];
$skippedPaid = [];
$skippedMissing = 0;

$pdo->beginTransaction();
try {
    foreach ($ids as $id) {
        $stmt = $pdo->prepare("SELECT * FROM billing WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $bill = $stmt->fetch();

        if (!$bill) {
            $skippedMissing++;
            continue;
        }

        // Same rule as the single-bill delete: refuse to remove a bill
        // that already has payment(s)/OR number(s) recorded against it.
        $payCount = $pdo->prepare("SELECT COUNT(*) FROM payments WHERE billing_id = :id");
        $payCount->execute(['id' => $id]);
        if ((int)$payCount->fetchColumn() > 0) {
            $skippedPaid[] = $bill['bill_number'];
            continue;
        }

        $del = $pdo->prepare("DELETE FROM billing WHERE id = :id");
        $del->execute(['id' => $id]);
        $deleted[] = $bill['bill_number'];
    }
    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    log_system_error('Bulk bill delete failed: ' . $e->getMessage());
    set_flash('error', 'Something went wrong while deleting these bills, so nothing was removed. Please try again.');
    redirect('list.php?' . $backQuery);
}

$deletedCount = count($deleted);
$skippedCount = count($skippedPaid);

if ($deletedCount > 0 && $skippedCount === 0) {
    set_flash('success', $deletedCount . ' bill(s) deleted.');
} elseif ($deletedCount > 0 && $skippedCount > 0) {
    set_flash('info', $deletedCount . ' bill(s) deleted. ' . $skippedCount
        . ' bill(s) were skipped because they already have payment(s)/OR number(s) recorded ('
        . implode(', ', array_map('h', $skippedPaid)) . ') — remove those payments first.');
} elseif ($skippedCount > 0) {
    set_flash('error', 'None of the selected bills were deleted. ' . $skippedCount
        . ' already have payment(s)/OR number(s) recorded (' . implode(', ', array_map('h', $skippedPaid))
        . ') — remove those payments first.');
} else {
    set_flash('error', 'No matching bills were found to delete.');
}

redirect('list.php?' . $backQuery);
