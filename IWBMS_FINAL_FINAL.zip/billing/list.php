<?php
$pageTitle = 'Billing';
$pageSub   = 'Generated bills and their payment status';
$activeNav = 'billing';
require_once __DIR__ . '/../includes/header.php';

refresh_overdue_bills($pdo);

$period = $_GET['period'] ?? '';
$status = $_GET['status'] ?? '';
$search = trim($_GET['q'] ?? '');

$where = [];
$params = [];

if ($period !== '') {
    $where[] = "b.billing_period = :period";
    $params['period'] = $period . '-01';
}
if ($status !== '') {
    $where[] = "b.status = :status";
    $params['status'] = $status;
}
if ($search !== '') {
    $where[] = "(c.first_name LIKE :s1 OR c.last_name LIKE :s2 OR c.account_number LIKE :s3 OR b.bill_number LIKE :s4)";
    $params['s1'] = "%$search%";
    $params['s2'] = "%$search%";
    $params['s3'] = "%$search%";
    $params['s4'] = "%$search%";
}

$whereSql = $where ? (" WHERE " . implode(' AND ', $where)) : '';

// Totals (paid/balance/total) must reflect ALL matching bills, not just
// the current page, so compute them with a separate aggregate query.
$totalsSql = "
    SELECT COUNT(*) cnt,
           COALESCE(SUM(b.total_amount),0) total,
           COALESCE(SUM(b.amount_paid),0) paid,
           COALESCE(SUM(b.balance),0) balance
    FROM billing b
    JOIN consumers c ON c.id = b.consumer_id
" . $whereSql;
$totalsStmt = $pdo->prepare($totalsSql);
$totalsStmt->execute($params);
$totalsRow = $totalsStmt->fetch();
$totals = [
    'total'   => (float)$totalsRow['total'],
    'paid'    => (float)$totalsRow['paid'],
    'balance' => (float)$totalsRow['balance'],
];
$pager = paginate((int)$totalsRow['cnt'], 25);

$sql = "
    SELECT b.*, c.first_name, c.last_name, c.account_number, rd.reading_date
    FROM billing b
    JOIN consumers c ON c.id = b.consumer_id
    LEFT JOIN readings rd ON rd.id = b.reading_id
" . $whereSql . "
    ORDER BY b.billing_period DESC, c.last_name, c.first_name
    LIMIT :limit OFFSET :offset
";

$stmt = $pdo->prepare($sql);
foreach ($params as $k => $v) $stmt->bindValue($k, $v);
$stmt->bindValue('limit', $pager['perPage'], PDO::PARAM_INT);
$stmt->bindValue('offset', $pager['offset'], PDO::PARAM_INT);
$stmt->execute();
$bills = $stmt->fetchAll();
?>

<div class="card">
  <div class="card-header">
    <h2>Bills <span class="text-muted">(<?= number_format($pager['totalRows']) ?>)</span></h2>
    <div class="actions">
      <a href="generate.php" class="btn btn-primary">⚡ Generate Bills</a>
      <a href="bulk_pay.php" class="btn btn-primary">🧾 Bulk Input OR#</a>
      <a href="print_bulk.php?period=<?= h($period) ?>" class="btn btn-navy">🖨️ Print Receipts</a>
      <a href="statement_print.php?<?= http_build_query(['period' => $period, 'status' => $status, 'q' => $search]) ?>" class="btn btn-navy" target="print_preview">🖨️ Print Ledger (Treasurer Copy)</a>
    </div>
  </div>

  <form method="get" class="form-row" style="margin-bottom:18px;">
    <div class="form-group mb-0">
      <label>Billing Month</label>
      <?= billing_month_select('period', $period, '', 24, 30, true) ?>
      <div class="hint">Pick the month, then click Filter.</div>
    </div>
    <div class="form-group mb-0">
      <label>Status</label>
      <select name="status">
        <option value="">All statuses</option>
        <?php foreach (['unpaid','partial','paid','overdue'] as $s): ?>
          <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group mb-0">
      <label>Search</label>
      <input type="text" name="q" value="<?= h($search) ?>" placeholder="Name, account #, or bill #">
    </div>
    <div class="form-group mb-0" style="align-self:end;">
      <button class="btn btn-outline" type="submit">Filter</button>
      <a href="list.php" class="btn btn-outline">Reset</a>
    </div>
  </form>

  <?php if ($pager['totalRows'] > 10): ?>
  <div style="display:flex; justify-content:flex-end; margin-bottom:12px;">
    <?= per_page_select() ?>
  </div>
  <?php endif; ?>

  <?php if (empty($bills)): ?>
    <div class="empty-state"><div class="ico">🧾</div>No bills match your filters. <a href="generate.php">Generate bills</a> from recorded readings.</div>
  <?php else: ?>
  <form method="post" action="bulk_delete.php" id="bulkDeleteForm">
    <?= csrf_field() ?>
    <input type="hidden" name="period" value="<?= h($period) ?>">
    <input type="hidden" name="status" value="<?= h($status) ?>">
    <input type="hidden" name="q" value="<?= h($search) ?>">

    <div class="row-actions" id="bulkDeleteBar" style="margin-bottom:12px; display:none;">
      <span class="hint" id="bulkDeleteCount" style="margin-right:auto;"></span>
      <button type="submit" class="btn btn-danger btn-sm" id="bulkDeleteBtn">🗑️ Delete Selected</button>
    </div>

    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th style="width:32px;"><input type="checkbox" id="selectAllBills"></th>
            <th>Bill #</th><th>Consumer</th><th>Period</th><th>Reading Date</th><th>Due Date</th>
            <th class="num">Consumption</th><th class="num">Total</th><th class="num">Paid</th><th class="num">Balance</th>
            <th>Status</th><th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($bills as $b): ?>
          <tr>
            <td><input type="checkbox" class="bill-checkbox" name="ids[]" value="<?= $b['id'] ?>"></td>
            <td><?= h($b['bill_number']) ?></td>
            <td><?= h($b['last_name'] . ', ' . $b['first_name']) ?> <span class="text-muted">(<?= h($b['account_number']) ?>)</span></td>
            <td><?= billing_month_label($b['billing_period']) ?></td>
            <td><?= $b['reading_date'] ? format_date($b['reading_date']) : '—' ?></td>
            <td<?= $b['status'] === 'overdue' ? ' class="text-danger"' : '' ?>><?= format_date($b['due_date']) ?></td>
            <td class="num"><?= number_format($b['consumption'], 2) ?> m³</td>
            <td class="num"><?= money($pdo, $b['total_amount']) ?></td>
            <td class="num"><?= money($pdo, $b['amount_paid']) ?></td>
            <td class="num"><?= money($pdo, $b['balance']) ?></td>
            <td><?= status_badge($b['status']) ?></td>
            <td class="row-actions">
              <a href="view.php?id=<?= $b['id'] ?>" class="btn btn-outline btn-sm">View</a>
              <a href="print.php?id=<?= $b['id'] ?>" class="btn btn-outline btn-sm" target="print_preview">🖨️ Print</a>
              <?php if ($b['status'] !== 'paid'): ?>
                <a href="pay.php?id=<?= $b['id'] ?>" class="btn btn-primary btn-sm">🧾 Input OR#</a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr>
            <td colspan="7" class="text-right"><strong>Totals</strong> <span class="hint">(all <?= number_format($pager['totalRows']) ?> matching bills, not just this page)</span></td>
            <td class="num"><strong><?= money($pdo, $totals['total']) ?></strong></td>
            <td class="num"><strong><?= money($pdo, $totals['paid']) ?></strong></td>
            <td class="num"><strong><?= money($pdo, $totals['balance']) ?></strong></td>
            <td colspan="2"></td>
          </tr>
        </tfoot>
      </table>
    </div>
  </form>
  <p class="hint" style="margin-top:8px;">Tip: bills that already have an OR#/payment recorded can't be deleted this way — remove the payment first if you really need to undo one of those.</p>
  <?= pagination_links($pager) ?>
  <?php endif; ?>
</div>

<script>
(function () {
  var selectAll = document.getElementById('selectAllBills');
  var form = document.getElementById('bulkDeleteForm');
  if (!selectAll || !form) return;

  var checkboxes = Array.prototype.slice.call(form.querySelectorAll('.bill-checkbox'));
  var bar = document.getElementById('bulkDeleteBar');
  var countLabel = document.getElementById('bulkDeleteCount');

  function refreshBar() {
    var checkedCount = checkboxes.filter(function (c) { return c.checked; }).length;
    bar.style.display = checkedCount > 0 ? 'flex' : 'none';
    countLabel.textContent = checkedCount + ' bill' + (checkedCount === 1 ? '' : 's') + ' selected';
    selectAll.checked = checkedCount > 0 && checkedCount === checkboxes.length;
    selectAll.indeterminate = checkedCount > 0 && checkedCount < checkboxes.length;
  }

  selectAll.addEventListener('change', function () {
    checkboxes.forEach(function (c) { c.checked = selectAll.checked; });
    refreshBar();
  });

  checkboxes.forEach(function (c) { c.addEventListener('change', refreshBar); });

  form.addEventListener('submit', function (e) {
    var checkedCount = checkboxes.filter(function (c) { return c.checked; }).length;
    if (checkedCount === 0) {
      e.preventDefault();
      return;
    }
    var msg = 'Delete ' + checkedCount + ' selected bill' + (checkedCount === 1 ? '' : 's') + '? '
      + 'Bills that already have an OR#/payment recorded will be skipped automatically. This cannot be undone.';
    if (!confirm(msg)) {
      e.preventDefault();
    }
  });

  refreshBar();
})();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
