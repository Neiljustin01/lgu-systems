<?php
require_once __DIR__ . '/../includes/auth.php';

$period = $_GET['period'] ?? date('Y-m');
$periodDate = date('Y-m-01', strtotime($period . '-01'));
$status = $_GET['status'] ?? '';
$search = trim($_GET['q'] ?? '');

$where = ["b.billing_period = :period"];
$params = ['period' => $periodDate];

if ($status !== '') {
    $where[] = "b.status = :status";
    $params['status'] = $status;
}
if ($search !== '') {
    $where[] = "(c.first_name LIKE :s1 OR c.last_name LIKE :s2 OR c.account_number LIKE :s3 OR b.bill_number LIKE :s4)";
    $params['s1'] = "%$search%";
    $params['s2'] = "%$search%";
    $params['s3'] = "%$search%";
    $params['s4'] = "%$search%";
}

$sql = "
    SELECT b.*, c.first_name, c.last_name, c.account_number, c.purok, c.barangay, c.address, c.meter_number,
           (SELECT p.or_number FROM payments p WHERE p.billing_id = b.id ORDER BY p.payment_date DESC, p.id DESC LIMIT 1) AS or_number
    FROM billing b
    JOIN consumers c ON c.id = b.consumer_id
    WHERE " . implode(' AND ', $where) . "
    ORDER BY c.last_name, c.first_name
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$bills = $stmt->fetchAll();

$totals = ['water' => 0, 'previous_balance' => 0, 'scf' => 0, 'electricity' => 0, 'service_loan' => 0, 'surcharge' => 0, 'others' => 0, 'total' => 0];
foreach ($bills as $b) {
    $totals['water']        += $b['water_amount'];
    $totals['previous_balance'] += $b['previous_balance'];
    $totals['scf']           += $b['scf_amount'];
    $totals['electricity']   += $b['electricity_amount'];
    $totals['service_loan']  += $b['service_loan'];
    $totals['surcharge']     += $b['surcharge_amount'];
    $totals['others']        += $b['others_amount'];
    $totals['total']         += $b['total_amount'];
}

$muniName   = get_setting($pdo, 'municipality_name', 'Municipality');
$provName   = get_setting($pdo, 'province_name', '');
$officeName = get_setting($pdo, 'office_name', 'Water Works Office');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Billing Ledger — <?= h(billing_month_label($periodDate)) ?></title>
<link rel="stylesheet" href="../assets/css/fonts.css?v=<?= asset_v('assets/css/fonts.css') ?>">
<link rel="stylesheet" href="../assets/css/style.css?v=<?= asset_v('assets/css/style.css') ?>">
<style>
  body { background: #fff; }
  .sheet { max-width: 1400px; margin: 0 auto; padding: 20px 10px; }
  table.sheet-table { width: 100%; border-collapse: collapse; font-size: 11.5px; }
  table.sheet-table th, table.sheet-table td { border: 1px solid #ccc; padding: 5px 6px; white-space: nowrap; }
  table.sheet-table th { background: #f3f5f7; text-align: left; }
  table.sheet-table td.num, table.sheet-table th.num { text-align: right; font-variant-numeric: tabular-nums; }
  table.sheet-table tfoot td { font-weight: 700; background: #f8f9fa; }
  @media print {
    @page { size: landscape; margin: 10mm; }
  }
</style>
</head>
<body>
<div class="sheet">
  <div class="no-print" style="text-align:right; margin-bottom:14px;">
    <button onclick="window.print()" class="btn btn-primary">🖨️ Print</button>
    <a href="list.php?<?= http_build_query(['period' => $period, 'status' => $status, 'q' => $search]) ?>" class="btn btn-outline">Back</a>
  </div>

  <div class="print-header">
    <img src="../assets/logo/seal.png" alt="<?= h($muniName) ?> Seal" class="print-header-logo print-header-logo-left" width="76" height="76">
    <img src="../assets/logo/watersystem.png" alt="Water System Logo" class="print-header-logo print-header-logo-right" width="76" height="76">
    <div class="print-header-text">
      <h2><?= h($muniName) ?><?= $provName ? ', ' . h($provName) : '' ?></h2>
      <div><?= h($officeName) ?></div>
      <h3 style="margin-top:10px;">Water Billing Ledger — <?= h(billing_month_label($periodDate)) ?></h3>
      <div class="text-muted">Treasurer's Copy — please write the OR Number for each payment received in the blank OR Number column, then return to the Water Works Office for encoding.</div>
    </div>
  </div>

  <?php if (empty($bills)): ?>
    <div class="empty-state"><div class="ico">🧾</div>No bills found for this period/filter.</div>
  <?php else: ?>
  <table class="sheet-table">
    <thead>
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Address</th>
        <th>Meter #</th>
        <th class="num">Present</th>
        <th class="num">Previous</th>
        <th class="num">Consumed</th>
        <th class="num">Consumed &times; Rate</th>
        <th class="num">Previous Balance</th>
        <th class="num">SCF</th>
        <th class="num">Electricity</th>
        <th class="num">Service Loan</th>
        <th class="num">Surcharge</th>
        <th class="num">Others</th>
        <th class="num">Total Amount Due</th>
        <th style="min-width:110px;">OR Number</th>
      </tr>
    </thead>
    <tbody>
      <?php $i = 1; foreach ($bills as $b): ?>
      <tr>
        <td><?= $i++ ?></td>
        <td><?= h($b['last_name'] . ', ' . $b['first_name']) ?> <span class="text-muted">(<?= h($b['account_number']) ?>)</span></td>
        <td><?= h(format_consumer_address($b)) ?></td>
        <td><?= h($b['meter_number'] ?: '—') ?></td>
        <td class="num"><?= number_format($b['current_reading'], 2) ?></td>
        <td class="num"><?= number_format($b['previous_reading'], 2) ?></td>
        <td class="num"><?= number_format($b['consumption'], 2) ?></td>
        <td class="num"><?= number_format($b['water_amount'], 2) ?></td>
        <td class="num"><?= number_format($b['previous_balance'], 2) ?></td>
        <td class="num"><?= number_format($b['scf_amount'], 2) ?></td>
        <td class="num"><?= number_format($b['electricity_amount'], 2) ?></td>
        <td class="num"><?= number_format($b['service_loan'], 2) ?></td>
        <td class="num"><?= number_format($b['surcharge_amount'], 2) ?></td>
        <td class="num"><?= number_format($b['others_amount'], 2) ?></td>
        <td class="num"><strong><?= number_format($b['total_amount'], 2) ?></strong></td>
        <td><?= $b['or_number'] ? h($b['or_number']) : '<span class="fill-line">&nbsp;</span>' ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr>
        <td colspan="7" class="text-right">Totals</td>
        <td class="num"><?= number_format($totals['water'], 2) ?></td>
        <td class="num"><?= number_format($totals['previous_balance'], 2) ?></td>
        <td class="num"><?= number_format($totals['scf'], 2) ?></td>
        <td class="num"><?= number_format($totals['electricity'], 2) ?></td>
        <td class="num"><?= number_format($totals['service_loan'], 2) ?></td>
        <td class="num"><?= number_format($totals['surcharge'], 2) ?></td>
        <td class="num"><?= number_format($totals['others'], 2) ?></td>
        <td class="num"><?= number_format($totals['total'], 2) ?></td>
        <td></td>
      </tr>
    </tfoot>
  </table>

  <p class="text-muted" style="font-size:11px; margin-top:16px;">
    "No OR, No Paid" — a blank OR Number column means this bill has not yet been recorded as paid in the system. Once the Treasurer writes the OR Number here, please submit this sheet back to the Water Works Office so it can be encoded (Billing → Record Payment).
  </p>
  <?php endif; ?>
</div>
  <script>
    // This page is opened in its own tab just to print — close it
    // automatically once the print dialog closes so tabs don't pile up.
    window.addEventListener('afterprint', function () {
      if (window.opener) { window.close(); }
    });
  </script>
</body>
</html>
