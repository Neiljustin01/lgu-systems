<?php
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

$pageTitle = 'Input OR# / Payment';
$activeNav = 'billing';
$backUrl   = 'view.php?id=' . $id;
$backLabel = 'Back to Bill';
require_once __DIR__ . '/../includes/header.php';

$stmt = $pdo->prepare("
    SELECT b.*, c.first_name, c.last_name, c.account_number
    FROM billing b JOIN consumers c ON c.id = b.consumer_id
    WHERE b.id = :id
");
$stmt->execute(['id' => $id]);
$bill = $stmt->fetch();

if (!$bill) {
    set_flash('error', 'Bill not found.');
    redirect('list.php');
}
if ($bill['status'] === 'paid') {
    set_flash('info', 'This bill is already fully paid.');
    redirect('view.php?id=' . $id);
}
$pageSub = $bill['bill_number'] . ' — ' . $bill['last_name'] . ', ' . $bill['first_name'];

$errors = [];
$amount = $bill['balance'];
$orNumber = '';
$paymentDate = date('Y-m-d');
$receivedBy = $_SESSION['admin_name'] ?? '';
$remarks = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $amount = trim($_POST['amount_paid'] ?? '');
    $orNumber = trim($_POST['or_number'] ?? '');
    $paymentDate = $_POST['payment_date'] ?? date('Y-m-d');
    $receivedBy = trim($_POST['received_by'] ?? '');
    $remarks = trim($_POST['remarks'] ?? '');

    if ($orNumber === '') {
        $errors[] = 'Official Receipt (OR) Number is required.';
    } elseif (or_number_exists($pdo, $orNumber)) {
        $errors[] = "OR Number \"$orNumber\" has already been used on another payment. Please check the number and try again.";
    }

    if ($amount === '' || !is_numeric($amount) || (float)$amount <= 0) {
        $errors[] = 'Please enter a valid payment amount greater than zero.';
    } elseif ((float)$amount > (float)$bill['balance'] + 0.01) {
        $errors[] = 'Payment amount cannot exceed the remaining balance of ' . money($pdo, $bill['balance']) . '.';
    }

    if (!$errors) {
        $pdo->beginTransaction();
        try {
            $ins = $pdo->prepare("
                INSERT INTO payments (billing_id, or_number, amount_paid, payment_date, received_by, remarks)
                VALUES (:billing_id, :or_number, :amount_paid, :payment_date, :received_by, :remarks)
            ");
            $ins->execute([
                'billing_id' => $id,
                'or_number' => $orNumber,
                'amount_paid' => $amount,
                'payment_date' => $paymentDate,
                'received_by' => $receivedBy,
                'remarks' => $remarks,
            ]);

            $newPaid   = (float)$bill['amount_paid'] + (float)$amount;
            $newBalance = round((float)$bill['total_amount'] - $newPaid, 2);
            $newStatus = $newBalance <= 0.01 ? 'paid' : 'partial';

            $upd = $pdo->prepare("
                UPDATE billing SET amount_paid = :paid, balance = :balance, status = :status WHERE id = :id
            ");
            $upd->execute([
                'paid' => $newPaid,
                'balance' => max(0, $newBalance),
                'status' => $newStatus,
                'id' => $id,
            ]);

            $pdo->commit();
            set_flash('success', 'Payment of ' . money($pdo, $amount) . ' recorded successfully.');
            redirect('view.php?id=' . $id);
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = 'Something went wrong while recording the payment. Please try again.';
        }
    }
}
?>

<div class="card" style="max-width:600px;">
  <div class="card-header"><h2>🧾 Input OR# — <?= h($bill['bill_number']) ?></h2></div>

  <?php if ($errors): ?>
    <div class="alert alert-danger"><?= implode('<br>', array_map('h', $errors)) ?></div>
  <?php endif; ?>

  <div class="bill-meta-grid" style="margin-bottom:18px;">
    <div><span>Total Amount:</span> <strong><?= money($pdo, $bill['total_amount']) ?></strong></div>
    <div><span>Already Paid:</span> <strong><?= money($pdo, $bill['amount_paid']) ?></strong></div>
    <div><span>Remaining Balance:</span> <strong><?= money($pdo, $bill['balance']) ?></strong></div>
    <div><span>Status:</span> <?= status_badge($bill['status']) ?></div>
  </div>

  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= $id ?>">
    <div class="form-row">
      <div class="form-group">
        <label class="required">Official Receipt (OR) Number</label>
        <input type="text" name="or_number" value="<?= h($orNumber) ?>" required autofocus>
        <div class="hint">Amount is pre-filled with the full remaining balance below — just type the OR number and save.</div>
      </div>
      <div class="form-group">
        <label class="required">Amount Paid</label>
        <input type="number" step="0.01" name="amount_paid" value="<?= h($amount) ?>" required>
        <div class="hint">Partial payments are allowed — the balance will carry over.</div>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="required">Payment Date</label>
        <input type="date" name="payment_date" value="<?= h($paymentDate) ?>" required>
      </div>
      <div class="form-group">
        <label>Received By</label>
        <input type="text" name="received_by" value="<?= h($receivedBy) ?>">
      </div>
    </div>
    <div class="form-group">
      <label>Remarks</label>
      <textarea name="remarks" rows="2"><?= h($remarks) ?></textarea>
    </div>
    <div class="row-actions">
      <button type="submit" class="btn btn-primary">💾 Save Payment</button>
      <a href="view.php?id=<?= $id ?>" class="btn btn-outline">Cancel</a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
