<?php
$pageTitle = 'Bulk Input OR#';
$pageSub   = 'Encode OR numbers and payments for many bills in one sheet';
$activeNav = 'billing';
$backUrl   = 'list.php';
$backLabel = 'Back to Billing';
require_once __DIR__ . '/../includes/header.php';

$period = $_GET['period'] ?? '';
$search = trim($_GET['q'] ?? '');
$saveErrors = [];
$processedCount = 0;

// ---------------------------------------------------------------------
// Handle bulk save
// ---------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $postPeriod = $_POST['period'] ?? $period;
    $paymentDate = $_POST['payment_date'] ?? date('Y-m-d');
    $receivedBy = trim($_POST['received_by'] ?? '');
    $orNumbers = $_POST['or_number'] ?? [];
    $amounts = $_POST['amount_paid'] ?? [];

    // Wrap the whole batch in one transaction: either every payment row
    // in this save is recorded, or (if something fails partway through)
    // none of them are — never a half-saved batch of OR numbers.
    $pdo->beginTransaction();
    try {
    foreach ($orNumbers as $billingId => $orNumber) {
        $billingId = (int)$billingId;
        $orNumber = trim($orNumber);
        if ($orNumber === '') continue; // no OR entered for this row — leave it for later

        $stmt = $pdo->prepare("SELECT * FROM billing WHERE id = :id");
        $stmt->execute(['id' => $billingId]);
        $bill = $stmt->fetch();
        if (!$bill) continue;

        if ($bill['status'] === 'paid') {
            $saveErrors[] = "{$bill['bill_number']}: already fully paid — skipped.";
            continue;
        }

        if (or_number_exists($pdo, $orNumber)) {
            $saveErrors[] = "{$bill['bill_number']}: OR Number \"$orNumber\" has already been used on another payment — skipped.";
            continue;
        }

        $amount = trim($amounts[$billingId] ?? '');
        if ($amount === '' || !is_numeric($amount) || (float)$amount <= 0) {
            $saveErrors[] = "{$bill['bill_number']}: enter a valid payment amount greater than zero — skipped.";
            continue;
        }
        if ((float)$amount > (float)$bill['balance'] + 0.01) {
            $saveErrors[] = "{$bill['bill_number']}: amount exceeds remaining balance of " . money($pdo, $bill['balance']) . " — skipped.";
            continue;
        }

        $ins = $pdo->prepare("
            INSERT INTO payments (billing_id, or_number, amount_paid, payment_date, received_by)
            VALUES (:billing_id, :or_number, :amount_paid, :payment_date, :received_by)
        ");
        $ins->execute([
            'billing_id' => $billingId,
            'or_number' => $orNumber,
            'amount_paid' => $amount,
            'payment_date' => $paymentDate,
            'received_by' => $receivedBy,
        ]);

        $newPaid = (float)$bill['amount_paid'] + (float)$amount;
        $newBalance = round((float)$bill['total_amount'] - $newPaid, 2);
        $newStatus = $newBalance <= 0.01 ? 'paid' : 'partial';

        $upd = $pdo->prepare("UPDATE billing SET amount_paid = :paid, balance = :balance, status = :status WHERE id = :id");
        $upd->execute([
            'paid' => $newPaid,
            'balance' => max(0, $newBalance),
            'status' => $newStatus,
            'id' => $billingId,
        ]);

        $processedCount++;
    }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        log_system_error('Bulk payment save failed: ' . $e->getMessage());
        set_flash('error', 'Something went wrong while saving these payments, so nothing was recorded. Please try again.');
        redirect('bulk_pay.php?period=' . urlencode($period) . '&q=' . urlencode($search));
    }

    if ($processedCount > 0) {
        set_flash($saveErrors ? 'info' : 'success',
            "$processedCount payment(s) recorded."
            . ($saveErrors ? ' Some rows were skipped — see details below.' : ''));
    } elseif (!$saveErrors) {
        set_flash('info', 'No OR numbers were entered.');
    }

    if (!$saveErrors) {
        redirect('list.php');
    }
    // If there were errors, fall through and re-render this page with the errors shown.
    $period = $postPeriod;
}

// ---------------------------------------------------------------------
// Build the list of bills still needing an OR# (unpaid/partial/overdue)
// ---------------------------------------------------------------------
$where = ["b.status != 'paid'"];
$params = [];

if ($period !== '') {
    $where[] = "b.billing_period = :period";
    $params['period'] = $period . '-01';
}
if ($search !== '') {
    $where[] = "(c.first_name LIKE :s1 OR c.last_name LIKE :s2 OR c.account_number LIKE :s3 OR b.bill_number LIKE :s4)";
    $params['s1'] = "%$search%";
    $params['s2'] = "%$search%";
    $params['s3'] = "%$search%";
    $params['s4'] = "%$search%";
}

$sql = "
    SELECT b.*, c.first_name, c.last_name, c.account_number
    FROM billing b
    JOIN consumers c ON c.id = b.consumer_id
    WHERE " . implode(' AND ', $where) . "
    ORDER BY b.billing_period DESC, c.last_name, c.first_name
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$bills = $stmt->fetchAll();
?>

<div class="card">
  <form method="get" class="form-row">
    <div class="form-group mb-0">
      <label>Billing Month</label>
      <?= billing_month_select('period', $period, '', 24, 30, true) ?>
      <div class="hint">Narrow the list to one billing month, or leave on "All" to see every unpaid/partial bill.</div>
    </div>
    <div class="form-group mb-0">
      <label>Search</label>
      <input type="text" name="q" value="<?= h($search) ?>" placeholder="Name, account #, or bill #">
    </div>
    <div class="form-group mb-0" style="align-self:end;">
      <button class="btn btn-outline" type="submit">Apply</button>
      <a href="list.php" class="btn btn-outline">← Back to Billing</a>
    </div>
  </form>
</div>

<?php if ($saveErrors): ?>
  <div class="alert alert-danger">
    <strong>Some rows were not saved:</strong><br>
    <?= implode('<br>', array_map('h', $saveErrors)) ?>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-header">
    <h2>Bills Needing an OR# <span class="text-muted">(<?= count($bills) ?>)</span></h2>
  </div>
  <p class="hint" style="margin-top:-8px; margin-bottom:16px;">
    Only unpaid, partial, and overdue bills are listed here — fully paid bills don't need an OR#.
    Amount Paid is pre-filled with each bill's full remaining balance; edit it for a partial payment.
  </p>

  <?php if (empty($bills)): ?>
    <div class="empty-state"><div class="ico">🧾</div>No unpaid bills match your filters.</div>
  <?php else: ?>
  <form method="post" id="bulkPayForm">
    <?= csrf_field() ?>
    <input type="hidden" name="period" value="<?= h($period) ?>">

    <div class="form-row" style="margin-bottom:16px;">
      <div class="form-group mb-0">
        <label>Payment Date (applies to all rows saved now)</label>
        <input type="date" name="payment_date" value="<?= date('Y-m-d') ?>">
      </div>
      <div class="form-group mb-0">
        <label>Received By (applies to all rows saved now)</label>
        <input type="text" name="received_by" value="<?= h($_SESSION['admin_name'] ?? '') ?>" placeholder="Cashier / Treasurer name">
      </div>
    </div>

    <div class="table-wrap">
      <table class="data-table" id="payGrid">
        <thead>
          <tr>
            <th>Bill #</th><th>Consumer</th><th>Period</th>
            <th class="num">Total</th><th class="num">Balance</th>
            <th style="min-width:140px;">OR Number</th>
            <th class="num" style="min-width:130px;">Amount Paid</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($bills as $b): ?>
          <tr>
            <td><?= h($b['bill_number']) ?></td>
            <td><?= h($b['last_name'] . ', ' . $b['first_name']) ?> <span class="text-muted">(<?= h($b['account_number']) ?>)</span></td>
            <td><?= billing_month_label($b['billing_period']) ?></td>
            <td class="num"><?= money($pdo, $b['total_amount']) ?></td>
            <td class="num"><?= money($pdo, $b['balance']) ?></td>
            <td>
              <input type="text" class="or-input" name="or_number[<?= $b['id'] ?>]" placeholder="OR#">
            </td>
            <td class="num">
              <input type="number" step="0.01" class="amount-input" name="amount_paid[<?= $b['id'] ?>]" value="<?= h(number_format((float)$b['balance'], 2, '.', '')) ?>">
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="row-actions" style="margin-top:16px;">
      <button type="submit" class="btn btn-primary">💾 Save All Payments</button>
      <span class="hint">Type an OR# and press <strong>Enter</strong> to jump to the next row — no clicking needed. Rows left blank are simply skipped. Saving returns you to the Billing list.</span>
    </div>
  </form>
  <?php endif; ?>
</div>

<script>
(function () {
  var orInputs = Array.prototype.slice.call(document.querySelectorAll('.or-input'));

  orInputs.forEach(function (input, idx) {
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === 'ArrowDown') {
        e.preventDefault();
        var next = orInputs[idx + 1];
        if (next) { next.focus(); next.select(); }
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        var prevInput = orInputs[idx - 1];
        if (prevInput) { prevInput.focus(); prevInput.select(); }
      }
    });
  });

  // Jump straight into the first empty OR# field when the page loads.
  var firstEmpty = orInputs.find(function (i) { return i.value === ''; });
  if (firstEmpty) firstEmpty.focus();
})();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
