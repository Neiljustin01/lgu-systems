<?php
$pageTitle = 'Bill Details';
$activeNav = 'billing';
$backUrl   = 'list.php';
$backLabel = 'Back to Billing';
require_once __DIR__ . '/../includes/header.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("
    SELECT b.*, c.first_name, c.last_name, c.account_number, c.purok, c.barangay, c.address, c.meter_number, ct.type_name
    FROM billing b
    JOIN consumers c ON c.id = b.consumer_id
    JOIN connection_types ct ON ct.id = c.connection_type_id
    WHERE b.id = :id
");
$stmt->execute(['id' => $id]);
$bill = $stmt->fetch();

if (!$bill) {
    set_flash('error', 'Bill not found.');
    redirect('list.php');
}
$pageSub = $bill['bill_number'] . ' — ' . $bill['last_name'] . ', ' . $bill['first_name'];

$payments = $pdo->prepare("SELECT * FROM payments WHERE billing_id = :id ORDER BY payment_date DESC, id DESC");
$payments->execute(['id' => $id]);
$payments = $payments->fetchAll();
$latestOr = $payments[0]['or_number'] ?? null;
?>

<div class="row-actions no-print" style="margin-bottom:16px;">
  <?php if ($bill['status'] !== 'paid'): ?>
    <a href="pay.php?id=<?= $id ?>" class="btn btn-primary">🧾 Input OR# / Payment</a>
  <?php endif; ?>
  <a href="edit_charges.php?id=<?= $id ?>" class="btn btn-outline">✏️ Edit Electricity / Service Loan / Others</a>
  <a href="print.php?id=<?= $id ?>" class="btn btn-outline" target="print_preview">🖨️ Print Bill</a>
  <a href="list.php" class="btn btn-outline">← Back to Billing</a>
  <a href="delete.php?id=<?= $id ?>" class="btn btn-danger" data-post
     data-confirm="Delete this bill? Any recorded payments for it will also be removed.">Delete Bill</a>
</div>

<div class="card">
  <div class="card-header">
    <h2>Bill Summary</h2>
    <?= status_badge($bill['status']) ?>
  </div>
  <div class="bill-meta-grid">
    <div><span>Bill Number:</span> <strong><?= h($bill['bill_number']) ?></strong></div>
    <div><span>Billing Month:</span> <strong><?= billing_month_label($bill['billing_period']) ?></strong> <span class="text-muted">(readings <?= reading_range_hint($bill['billing_period']) ?>)</span></div>
    <div><span>Consumer:</span> <strong><?= h($bill['last_name'] . ', ' . $bill['first_name']) ?> (<?= h($bill['account_number']) ?>)</strong></div>
    <div><span>Address:</span> <strong><?= h(format_consumer_address($bill)) ?></strong></div>
    <div><span>Meter Number:</span> <strong><?= h($bill['meter_number'] ?: '—') ?></strong></div>
    <div><span>Connection Type:</span> <strong><?= h($bill['type_name']) ?></strong></div>
    <div><span>Billing Date:</span> <strong><?= format_date($bill['billing_date']) ?></strong></div>
    <div><span>Due Date:</span> <strong><?= format_date($bill['due_date']) ?></strong></div>
    <div><span>Disconnection Date:</span> <strong><?= ($dcDate = bill_disconnection_date($pdo, $bill)) ? format_date($dcDate) : 'NONE' ?></strong></div>
    <div><span>OR Number:</span> <strong><?= $latestOr ? h($latestOr) : 'No OR — Not Paid' ?></strong></div>
  </div>

  <div class="table-wrap" style="margin-top:10px;">
    <table class="data-table">
      <tbody>
        <tr><td>Previous Reading</td><td class="num"><?= number_format($bill['previous_reading'], 2) ?> m³</td></tr>
        <tr><td>Present Reading</td><td class="num"><?= number_format($bill['current_reading'], 2) ?> m³</td></tr>
        <tr><td>Total Consumption</td><td class="num"><strong><?= number_format($bill['consumption'], 2) ?> m³</strong></td></tr>
        <tr><td><strong>Water Charge (Consumed &times; Rate)</strong></td><td class="num"><strong><?= money($pdo, $bill['water_amount']) ?></strong></td></tr>
        <?php if ($bill['previous_balance'] > 0): ?>
        <tr><td>Previous Balance (unpaid, carried forward)</td><td class="num"><?= money($pdo, $bill['previous_balance']) ?></td></tr>
        <?php endif; ?>
        <tr><td>SCF (Senior Citizen Fund)</td><td class="num"><?= money($pdo, $bill['scf_amount']) ?></td></tr>
        <tr><td>Electricity (<?= number_format($bill['consumption'], 2) ?> m³ &times; <?= money($pdo, get_setting($pdo, 'electricity_rate', 6.5)) ?>)</td><td class="num"><?= money($pdo, $bill['electricity_amount']) ?></td></tr>
        <tr><td>Service Loan</td><td class="num"><?= money($pdo, $bill['service_loan']) ?></td></tr>
        <?php if ($bill['surcharge_amount'] > 0): ?>
        <tr><td>Surcharge (unpaid, carried forward + new)</td><td class="num"><?= money($pdo, $bill['surcharge_amount']) ?></td></tr>
        <?php endif; ?>
        <tr><td>Others</td><td class="num"><?= money($pdo, $bill['others_amount']) ?></td></tr>
        <tr><td><strong>Total Amount Due</strong></td><td class="num"><strong><?= money($pdo, $bill['total_amount']) ?></strong></td></tr>
        <tr><td>Amount Paid</td><td class="num"><?= money($pdo, $bill['amount_paid']) ?></td></tr>
        <tr><td><strong>Remaining Balance</strong></td><td class="num"><strong><?= money($pdo, $bill['balance']) ?></strong></td></tr>
      </tbody>
    </table>
  </div>
</div>

<div class="card">
  <div class="card-header"><h2>Payment History</h2></div>
  <?php if (empty($payments)): ?>
    <div class="empty-state"><div class="ico">💰</div>No payments recorded yet for this bill.</div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>OR Number</th><th>Payment Date</th><th class="num">Amount</th><th>Received By</th><th>Remarks</th></tr></thead>
      <tbody>
        <?php foreach ($payments as $p): ?>
        <tr>
          <td><?= h($p['or_number'] ?: '—') ?></td>
          <td><?= format_date($p['payment_date']) ?></td>
          <td class="num"><?= money($pdo, $p['amount_paid']) ?></td>
          <td><?= h($p['received_by'] ?: '—') ?></td>
          <td><?= h($p['remarks'] ?: '—') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
