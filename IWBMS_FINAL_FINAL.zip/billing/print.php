<?php
/**
 * Consumer-facing bill reprint — a full, plain-language "Statement of
 * Account" for one bill. This is deliberately a different (larger,
 * friendlier) layout than the compact 6-per-sheet stub used for the
 * normal monthly print run (see includes/bill_stub.php +
 * billing/print_bulk.php): this page has a whole sheet of paper to
 * itself, so every charge gets its own line AND a plain-language
 * explanation of why it's on the bill, instead of a cryptic
 * abbreviation. Reachable from Billing → Bills → Print, or from a
 * bill's own View page.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/bill_stub.php'; // for bill_stub_select_sql()

refresh_overdue_bills($pdo);

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare(bill_stub_select_sql("WHERE b.id = :id"));
$stmt->execute(['id' => $id]);
$bill = $stmt->fetch();

if (!$bill) {
    die('Bill not found.');
}

// Period Covered range + disconnection notice, same helpers the compact
// stub and billing/view.php already use.
$fromDate = get_previous_reading_date($pdo, $bill['consumer_id'], $bill['billing_period']);
$toDate   = $bill['reading_date'] ?? null;
$dcDate   = bill_disconnection_date($pdo, $bill);

// Payment history, so a paid/partially-paid bill shows proof of payment
// right on the reprint instead of just a status word.
$pay = $pdo->prepare("SELECT * FROM payments WHERE billing_id = :id ORDER BY payment_date DESC, id DESC");
$pay->execute(['id' => $id]);
$payments = $pay->fetchAll();
$latestOr = $payments[0]['or_number'] ?? null;

// The prior bill this one carried forward from (if any) — used only to
// show a plain "X m³ x rate" breakdown of the Surcharge line below, using
// the exact same formula as calculate_surcharge_increment() in
// includes/functions.php, so the receipt's explanation always matches
// what was actually charged.
$priorBillStmt = $pdo->prepare("
    SELECT billing_period, consumption, rate_per_cubic FROM billing
    WHERE consumer_id = :cid AND billing_period < :period
    ORDER BY billing_period DESC, id DESC LIMIT 1
");
$priorBillStmt->execute(['cid' => $bill['consumer_id'], 'period' => $bill['billing_period']]);
$priorBill = $priorBillStmt->fetch();
$surchargeFresh = $priorBill ? calculate_surcharge_increment($priorBill['consumption'], $priorBill['rate_per_cubic']) : 0.0;
$surchargeCarried = round((float)$bill['surcharge_amount'] - $surchargeFresh, 2);

$muniName   = get_setting($pdo, 'municipality_name', 'Municipality');
$provName   = get_setting($pdo, 'province_name', '');
$officeName = get_setting($pdo, 'office_name', 'Water Works Office');
$officeAddr = get_setting($pdo, 'office_address', '');
$officeContact = get_setting($pdo, 'office_contact', '');

$isPaid    = $bill['status'] === 'paid';
$isPartial = $bill['status'] === 'partial';
$isOverdue = $bill['status'] === 'overdue';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bill <?= h($bill['bill_number']) ?> — <?= h($bill['last_name'] . ', ' . $bill['first_name']) ?></title>
<style>
  :root {
    --navy: #0f2a43; --navy-700: #1b4a70; --teal: #0f9b8e;
    --text-900: #17222e; --text-600: #52616f; --border: #dbe1e6;
    --bg: #eef1f3; --surface: #fff;
    --danger: #c23b3b; --danger-bg: #fbe9e9;
    --warning: #b3790a; --warning-bg: #fdf1dc;
    --success: #1f9d55; --success-bg: #e6f6ec;
  }
  * { box-sizing: border-box; }
  body { background: var(--bg); margin: 0; font-family: Arial, Helvetica, sans-serif; color: var(--text-900); }
  .toolbar { text-align: right; padding: 14px 16px; }
  .btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; border-radius: 8px; border: 1px solid #ccc; background: #fff; cursor: pointer; font-size: 13px; text-decoration: none; color: #111; }
  .btn-primary { background: var(--navy); color: #fff; border-color: var(--navy); }

  .sheet { width: 720px; margin: 0 auto 40px; background: var(--surface); border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,.08); overflow: hidden; }

  .r-header { display: flex; align-items: center; gap: 14px; padding: 20px 28px; background: var(--navy); color: #fff; }
  .r-header img { width: 60px; height: 60px; border-radius: 50%; background: #fff; object-fit: cover; }
  .r-header .names { flex: 1; }
  .r-header .muni { font-size: 18px; font-weight: 700; }
  .r-header .office { font-size: 12.5px; opacity: .9; margin-top: 2px; }
  .r-header .doctitle { text-align: right; }
  .r-header .doctitle .t1 { font-size: 13px; opacity: .85; letter-spacing: .04em; }
  .r-header .doctitle .t2 { font-size: 17px; font-weight: 700; }

  .r-body { padding: 24px 28px; }

  .r-status-strip { display: flex; justify-content: space-between; align-items: center; padding: 10px 14px; border-radius: 8px; margin-bottom: 20px; font-size: 13.5px; font-weight: 600; }
  .r-status-strip.unpaid  { background: var(--warning-bg); color: var(--warning); }
  .r-status-strip.overdue { background: var(--danger-bg);  color: var(--danger); }
  .r-status-strip.partial { background: var(--warning-bg); color: var(--warning); }
  .r-status-strip.paid    { background: var(--success-bg); color: var(--success); }

  .r-meta { display: grid; grid-template-columns: 1fr 1fr; gap: 4px 24px; margin-bottom: 22px; font-size: 13.5px; }
  .r-meta div span.lbl { display: block; color: var(--text-600); font-size: 11px; text-transform: uppercase; letter-spacing: .03em; }
  .r-meta div span.val { font-weight: 700; }
  .r-meta .full { grid-column: 1 / -1; }

  .r-section-title { font-size: 13px; font-weight: 700; color: var(--navy-700); text-transform: uppercase; letter-spacing: .03em; margin: 22px 0 8px; padding-bottom: 6px; border-bottom: 2px solid var(--border); }

  .r-readings { display: flex; gap: 12px; margin-bottom: 4px; }
  .r-readings .box { flex: 1; text-align: center; padding: 12px 8px; background: #f6f8f9; border-radius: 8px; }
  .r-readings .box .n { font-size: 20px; font-weight: 700; color: var(--navy); }
  .r-readings .box .l { font-size: 11.5px; color: var(--text-600); margin-top: 2px; }

  table.r-charges { width: 100%; border-collapse: collapse; font-size: 13.5px; margin-top: 10px; }
  table.r-charges td { padding: 8px 4px; vertical-align: top; border-bottom: 1px solid var(--border); }
  table.r-charges tr:last-child td { border-bottom: none; }
  table.r-charges td.amt { text-align: right; font-weight: 700; white-space: nowrap; padding-left: 12px; }
  table.r-charges td .item-label { font-weight: 600; }
  table.r-charges td .item-note { display: block; font-size: 12px; color: var(--text-600); font-weight: 400; margin-top: 1px; }
  table.r-charges tr.subtotal td { border-top: 1.5px solid var(--text-900); border-bottom: none; padding-top: 10px; font-weight: 700; }
  table.r-charges tr.bracket td { padding: 3px 4px 3px 16px; font-size: 12.5px; color: var(--text-600); border-bottom: none; }
  table.r-charges tr.bracket td.amt { font-weight: 400; }

  .r-total-box { display: flex; justify-content: space-between; align-items: center; background: var(--navy); color: #fff; border-radius: 10px; padding: 16px 20px; margin-top: 18px; }
  .r-total-box .lbl { font-size: 14px; font-weight: 600; }
  .r-total-box .amt { font-size: 26px; font-weight: 700; }

  .r-paid-box { display: flex; justify-content: space-between; align-items: center; background: var(--success-bg); color: var(--success); border-radius: 10px; padding: 14px 20px; margin-top: 12px; font-size: 13.5px; }
  .r-paid-box .amt { font-size: 18px; font-weight: 700; }
  .r-balance-box { display: flex; justify-content: space-between; align-items: center; background: var(--danger-bg); color: var(--danger); border-radius: 10px; padding: 14px 20px; margin-top: 12px; font-size: 13.5px; font-weight: 700; }

  .r-due-notice { display: flex; gap: 12px; align-items: flex-start; margin-top: 20px; padding: 14px 16px; border-radius: 8px; border: 1.5px solid var(--warning); background: var(--warning-bg); color: #6b4d05; font-size: 13px; line-height: 1.5; }
  .r-due-notice.overdue { border-color: var(--danger); background: var(--danger-bg); color: #7a2020; }
  .r-due-notice .ico { font-size: 20px; }
  .r-due-notice b { display: block; font-size: 14px; margin-bottom: 2px; }

  .r-footer { display: flex; justify-content: space-between; margin-top: 34px; padding-top: 16px; border-top: 1px dashed var(--border); font-size: 12px; color: var(--text-600); }
  .r-sig { text-align: center; width: 200px; }
  .r-sig .line { border-top: 1px solid #888; margin-top: 30px; padding-top: 4px; }

  .r-thanks { text-align: center; font-weight: 700; color: var(--navy); font-style: italic; margin-top: 22px; font-size: 13.5px; }
  .r-fineprint { text-align: center; font-size: 10.5px; color: var(--text-600); margin-top: 6px; }

  @media print {
    body { background: #fff; }
    .toolbar, .no-print { display: none !important; }
    .sheet { box-shadow: none; margin: 0; width: 100%; }
    @page { size: A4 portrait; margin: 12mm; }
  }
</style>
</head>
<body>
  <div class="toolbar no-print">
    <button onclick="window.print()" class="btn btn-primary">🖨️ Print</button>
    <a href="view.php?id=<?= $id ?>" class="btn">Back</a>
    <a href="print_bulk.php?period=<?= h(date('Y-m', strtotime($bill['billing_period']))) ?>" class="btn">Bulk Print (6 per sheet) →</a>
  </div>

  <div class="sheet">
    <div class="r-header">
      <img src="../assets/logo/seal.png" alt="">
      <div class="names">
        <div class="muni"><?= h($muniName . ($provName ? ', ' . $provName : '')) ?></div>
        <div class="office"><?= h($officeName) ?><?= $officeAddr ? ' — ' . h($officeAddr) : '' ?><?= $officeContact ? ' · ' . h($officeContact) : '' ?></div>
      </div>
      <div class="doctitle">
        <div class="t1">STATEMENT OF ACCOUNT</div>
        <div class="t2"><?= h($bill['bill_number']) ?></div>
      </div>
      <img src="../assets/logo/watersystem.png" alt="">
    </div>

    <div class="r-body">

      <?php if ($isPaid): ?>
        <div class="r-status-strip paid">✅ PAID IN FULL <?= $latestOr ? '— OR# ' . h($latestOr) : '' ?></div>
      <?php elseif ($isOverdue): ?>
        <div class="r-status-strip overdue">⚠️ OVERDUE — please settle as soon as possible to avoid disconnection</div>
      <?php elseif ($isPartial): ?>
        <div class="r-status-strip partial">◐ PARTIALLY PAID — a balance remains</div>
      <?php else: ?>
        <div class="r-status-strip unpaid">🧾 UNPAID — please pay on or before the due date below</div>
      <?php endif; ?>

      <div class="r-meta">
        <div><span class="lbl">Consumer Name</span><span class="val"><?= h($bill['last_name'] . ', ' . $bill['first_name']) ?></span></div>
        <div><span class="lbl">Account Number</span><span class="val"><?= h($bill['account_number']) ?></span></div>
        <div class="full"><span class="lbl">Service Address</span><span class="val"><?= h(format_consumer_address($bill)) ?></span></div>
        <div><span class="lbl">Meter Number</span><span class="val"><?= h($bill['meter_number'] ?: '—') ?></span></div>
        <div><span class="lbl">Connection Type</span><span class="val"><?= h($bill['type_name']) ?></span></div>
        <div><span class="lbl">Billing Month</span><span class="val"><?= h(billing_month_label($bill['billing_period'])) ?></span></div>
        <div><span class="lbl">Meter Reading Date</span><span class="val"><?= $toDate ? h(format_date($toDate)) : '—' ?></span></div>
      </div>

      <div class="r-section-title">Your Water Meter Reading</div>
      <div class="r-readings">
        <div class="box"><div class="n"><?= number_format($bill['previous_reading'], 0) ?></div><div class="l">Previous Reading (m³)</div></div>
        <div class="box"><div class="n"><?= number_format($bill['current_reading'], 0) ?></div><div class="l">Present Reading (m³)</div></div>
        <div class="box"><div class="n"><?= number_format($bill['consumption'], 0) ?></div><div class="l">Water Used This Month (m³)</div></div>
      </div>

      <div class="r-section-title">Charges on This Bill</div>
      <table class="r-charges">
        <tr>
          <td>
            <span class="item-label">Water Charge</span>
            <span class="item-note">Covers the <?= number_format($bill['minimum_consumption'], 0) ?> m³ minimum<?= $bill['excess_consumption'] > 0 ? ' plus ' . number_format($bill['excess_consumption'], 2) . ' m³ used above it' : '' ?></span>
          </td>
          <td class="amt"><?= money($pdo, $bill['water_amount']) ?></td>
        </tr>

        <?php if ((float)$bill['previous_balance'] > 0): ?>
        <tr>
          <td>
            <span class="item-label">Previous Balance</span>
            <span class="item-note">Unpaid amount carried over from an earlier bill</span>
          </td>
          <td class="amt"><?= money($pdo, $bill['previous_balance']) ?></td>
        </tr>
        <?php endif; ?>

        <?php if ((float)$bill['surcharge_amount'] > 0): ?>
        <tr>
          <td>
            <span class="item-label">Surcharge</span>
            <span class="item-note">Penalty for not fully paying your <?= $priorBill ? h(billing_month_label($priorBill['billing_period'])) : 'previous' ?> bill</span>
          </td>
          <td class="amt"><?= money($pdo, $bill['surcharge_amount']) ?></td>
        </tr>
        <?php if ($priorBill && $surchargeFresh > 0): ?>
        <tr class="bracket">
          <td>New this month: <?= number_format($priorBill['consumption'], 2) ?> m³ (last bill's usage) &times; <?= money($pdo, $priorBill['rate_per_cubic']) ?>/m³</td>
          <td class="amt"><?= money($pdo, $surchargeFresh) ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($surchargeCarried > 0.01): ?>
        <tr class="bracket">
          <td>Carried over from earlier unpaid bill(s)</td>
          <td class="amt"><?= money($pdo, $surchargeCarried) ?></td>
        </tr>
        <?php endif; ?>
        <?php endif; ?>

        <?php if ((float)$bill['scf_amount'] > 0): ?>
        <tr>
          <td>
            <span class="item-label">SCF (Senior Citizen Fund)</span>
            <span class="item-note">Standard municipal fund charge</span>
          </td>
          <td class="amt"><?= money($pdo, $bill['scf_amount']) ?></td>
        </tr>
        <?php endif; ?>

        <?php if ((float)$bill['electricity_amount'] > 0): ?>
        <tr>
          <td>
            <span class="item-label">Electricity</span>
            <span class="item-note">Power cost of running the water pump for your area</span>
          </td>
          <td class="amt"><?= money($pdo, $bill['electricity_amount']) ?></td>
        </tr>
        <?php endif; ?>

        <?php if ((float)$bill['service_loan'] > 0): ?>
        <tr>
          <td><span class="item-label">Service Loan</span></td>
          <td class="amt"><?= money($pdo, $bill['service_loan']) ?></td>
        </tr>
        <?php endif; ?>

        <?php if ((float)$bill['others_amount'] > 0): ?>
        <tr>
          <td><span class="item-label">Other Charges</span></td>
          <td class="amt"><?= money($pdo, $bill['others_amount']) ?></td>
        </tr>
        <?php endif; ?>
      </table>

      <div class="r-total-box">
        <div class="lbl">TOTAL AMOUNT DUE</div>
        <div class="amt"><?= money($pdo, $bill['total_amount']) ?></div>
      </div>

      <?php if ((float)$bill['amount_paid'] > 0): ?>
      <div class="r-paid-box">
        <div>Amount Already Paid<?= $latestOr ? ' (OR# ' . h($latestOr) . ')' : '' ?></div>
        <div class="amt"><?= money($pdo, $bill['amount_paid']) ?></div>
      </div>
      <?php endif; ?>

      <?php if (!$isPaid): ?>
      <div class="r-balance-box">
        <div>Remaining Balance to Pay</div>
        <div class="amt"><?= money($pdo, $bill['balance']) ?></div>
      </div>

      <div class="r-due-notice<?= $isOverdue ? ' overdue' : '' ?>">
        <div class="ico"><?= $isOverdue ? '⛔' : '⏰' ?></div>
        <div>
          <b>Please pay on or before <?= format_date($bill['due_date']) ?></b>
          This bill also serves as a disconnection notice. If this bill is still unpaid when your next reading is
          taken, a surcharge will be added to your next bill<?= $dcDate ? ', and your water service may be disconnected on or after ' . format_date($dcDate) . ' if it remains unpaid' : '' ?>.
        </div>
      </div>
      <?php endif; ?>

      <?php if ($isPaid): ?>
      <div class="r-thanks">Thank you for paying your water bill on time!</div>
      <?php endif; ?>
      <div class="r-fineprint">Please keep this statement for your records. For questions about this bill, please visit or call <?= h($officeName) ?><?= $officeContact ? ' at ' . h($officeContact) : '' ?>.</div>

      <div class="r-footer no-print">
        <div class="r-sig"><div class="line">Prepared By</div></div>
        <div class="r-sig"><div class="line">Received By (Consumer)</div></div>
      </div>
    </div>
  </div>
  <script>
    // This page is opened in its own tab just to print — close it
    // automatically once the print dialog closes so tabs don't pile up.
    window.addEventListener('afterprint', function () {
      if (window.opener) { window.close(); }
    });
  </script>
</body>
</html>
