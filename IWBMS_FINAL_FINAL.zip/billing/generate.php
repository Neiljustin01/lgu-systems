<?php
$pageTitle = 'Generate Bills';
$pageSub   = 'Create bills from meter readings that have not been billed yet';
$activeNav = 'billing';
$backUrl   = 'list.php';
$backLabel = 'Back to Billing';
require_once __DIR__ . '/../includes/header.php';

$period = $_GET['period'] ?? $_POST['period'] ?? date('Y-m');
$periodDate = $period . '-01';
$dueDays = (int)get_setting($pdo, 'due_days', 15);

// Make sure every bill's overdue status is current before we look at
// any of them for carry-forward purposes below.
refresh_overdue_bills($pdo);

$message = '';
$generatedCount = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $selectedReadingIds = array_map('intval', $_POST['reading_ids'] ?? []);

    // Safety net for PHP's max_input_vars limit: on a large batch, the
    // browser can submit more form fields than this server's php.ini allows
    // in one request, and PHP silently drops everything past that limit —
    // no warning, no error, just fewer reading_ids[] than were checked.
    // expected_count is a hidden field set to the true number of checked
    // boxes when the form was rendered, positioned before the checkbox
    // list so it always survives even when the list itself gets truncated.
    $expectedSelectedCount = (int)($_POST['expected_count'] ?? 0);
    $receivedSelectedCount = count($selectedReadingIds);
    $selectionWasTruncated = $expectedSelectedCount > 0 && $receivedSelectedCount < $expectedSelectedCount;

    // Billing Date is user-chosen at generation time (defaults to today on
    // the form, but staff can back-date/forward-date it). Falls back to the
    // reading date if left blank or invalid.
    $postedBillingDate = trim($_POST['billing_date'] ?? '');
    $chosenBillingDate = null;
    if ($postedBillingDate !== '') {
        $d = DateTime::createFromFormat('Y-m-d', $postedBillingDate);
        if ($d && $d->format('Y-m-d') === $postedBillingDate) {
            $chosenBillingDate = $postedBillingDate;
        }
    }

    if (empty($selectedReadingIds)) {
        set_flash('error', 'Please select at least one reading to bill.');
    } else {
        // Wrap the whole batch in one transaction: if anything goes wrong
        // partway through (e.g. MySQL drops, disk full), nothing in this
        // batch is left half-saved — either all selected bills are
        // generated, or none are.
        $pdo->beginTransaction();
        try {
        foreach ($selectedReadingIds as $readingId) {
            $stmt = $pdo->prepare("
                SELECT r.*, c.connection_type_id, c.address
                FROM readings r JOIN consumers c ON c.id = r.consumer_id
                WHERE r.id = :id
            ");
            $stmt->execute(['id' => $readingId]);
            $reading = $stmt->fetch();
            if (!$reading) continue;

            // Skip if already billed (safety net in case of double submission)
            $chk = $pdo->prepare("SELECT COUNT(*) FROM billing WHERE reading_id = :rid");
            $chk->execute(['rid' => $readingId]);
            if ($chk->fetchColumn() > 0) continue;

            // Billing Date defaults to the date the meter was actually read,
            // but staff can override it on the form (e.g. bills generated
            // late/in bulk/back-dated) — Due Date follows from whichever
            // date is used.
            $billingDate = $chosenBillingDate ?: ($reading['reading_date'] ?: date('Y-m-d'));
            $dueDate     = date('Y-m-d', strtotime("$billingDate +$dueDays days"));

            $rate = get_active_rate($pdo, $reading['connection_type_id'], $billingDate);
            if (!$rate) continue; // No rate configured for this connection type yet

            $calc = calculate_bill_amount($pdo, (float)$reading['consumption'], $rate);
            $waterAmount = $calc['total_amount'];
            $freshScf         = calculate_scf($pdo, $reading['consumption']);
            $freshElectricity = calculate_electricity($pdo, $reading['consumption'], $reading['address']);

            // "Add-and-add until paid": pull forward whatever Previous
            // Balance / SCF / Electricity / Surcharge the consumer's last
            // bill was still carrying, if it isn't fully paid yet.
            $carry = carry_forward_charges($pdo, $reading['consumer_id'], $reading['reading_period']);
            $previousBalance = $carry['previous_balance'] ?? 0;
            $scf             = round($freshScf + ($carry['scf_carry'] ?? 0), 2);
            $electricity     = round($freshElectricity + ($carry['electricity_carry'] ?? 0), 2);
            $surcharge       = round(
                ($carry['surcharge_carry'] ?? 0)
                + calculate_surcharge_increment($carry['prior_consumption'] ?? 0, $carry['prior_rate_per_cubic'] ?? 0),
                2
            );

            // Service Loan and Others start at 0 — filled in per-bill later
            // (Billing → Edit Charges); they're one-time charges and don't
            // carry forward the way the components above do.
            $serviceLoan = 0;
            $others      = 0;
            $grandTotal  = calculate_grand_total($waterAmount, $previousBalance, $scf, $electricity, $serviceLoan, $surcharge, $others);
            $billNumber  = generate_bill_number($pdo, $reading['reading_period']);

            $ins = $pdo->prepare("
                INSERT INTO billing
                (bill_number, consumer_id, reading_id, billing_period, previous_reading, current_reading,
                 consumption, minimum_consumption, minimum_charge, rate_per_cubic, rate_id,
                 excess_consumption, excess_amount, water_amount, previous_balance, scf_amount, electricity_amount,
                 service_loan, surcharge_amount, others_amount, penalty_amount, total_amount, amount_paid, balance,
                 billing_date, due_date, status)
                VALUES
                (:bill_number, :consumer_id, :reading_id, :billing_period, :previous_reading, :current_reading,
                 :consumption, :minimum_consumption, :minimum_charge, :rate_per_cubic, :rate_id,
                 :excess_consumption, :excess_amount, :water_amount, :previous_balance, :scf_amount, :electricity_amount,
                 :service_loan, :surcharge_amount, :others_amount, 0, :total_amount, 0, :balance,
                 :billing_date, :due_date, 'unpaid')
            ");
            $ins->execute([
                'bill_number' => $billNumber,
                'consumer_id' => $reading['consumer_id'],
                'reading_id'  => $readingId,
                'billing_period' => $reading['reading_period'],
                'previous_reading' => $reading['previous_reading'],
                'current_reading' => $reading['current_reading'],
                'consumption' => $reading['consumption'],
                'minimum_consumption' => $rate['minimum_consumption'],
                'minimum_charge' => $rate['minimum_charge'],
                'rate_per_cubic' => $rate['rate_per_cubic'],
                'rate_id' => $rate['id'],
                'excess_consumption' => $calc['excess_consumption'],
                'excess_amount' => $calc['excess_amount'],
                'water_amount' => $waterAmount,
                'previous_balance' => $previousBalance,
                'scf_amount' => $scf,
                'electricity_amount' => $electricity,
                'service_loan' => $serviceLoan,
                'surcharge_amount' => $surcharge,
                'others_amount' => $others,
                'total_amount' => $grandTotal,
                'balance' => $grandTotal,
                'billing_date' => $billingDate,
                'due_date' => $dueDate,
            ]);
            $generatedCount++;
        }
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            log_system_error('Bill generation failed: ' . $e->getMessage());
            set_flash('error', 'Something went wrong while generating bills, so nothing was saved. Please try again — if it keeps happening, check that MySQL is running.');
            redirect('generate.php?period=' . $period);
        }

        if ($selectionWasTruncated) {
            $missed = $expectedSelectedCount - $receivedSelectedCount;
            set_flash('error',
                "Only $generatedCount of the $expectedSelectedCount bill(s) you selected were generated. " .
                "The other $missed were not submitted — your browser sent more items than this server's PHP " .
                "configuration (max_input_vars) allows in a single request. Nothing was lost: those consumers " .
                "are still listed below as unbilled. Click \"Generate Selected Bills\" again to finish the rest " .
                "(already-billed consumers won't be duplicated), or ask whoever set up this system to raise " .
                "max_input_vars in php.ini so the whole batch fits at once."
            );
        } else {
            set_flash('success', "$generatedCount bill(s) generated successfully for Billing Month " . billing_month_label($periodDate) . '.');
        }
        redirect('list.php?period=' . $period);
    }
}

// Readings for this period that don't have a bill yet
$stmt = $pdo->prepare("
    SELECT r.*, c.first_name, c.last_name, c.account_number, c.connection_type_id, c.address, ct.type_name
    FROM readings r
    JOIN consumers c ON c.id = r.consumer_id
    JOIN connection_types ct ON ct.id = c.connection_type_id
    WHERE r.reading_period = :period
      AND r.id NOT IN (SELECT reading_id FROM billing)
    ORDER BY c.last_name, c.first_name
");
$stmt->execute(['period' => $periodDate]);
$unbilledReadings = $stmt->fetchAll();

// Pre-compute a preview of what each one would cost — Water Charge + SCF +
// Electricity, PLUS anything carrying forward from an unpaid prior bill
// (Previous Balance / SCF / Electricity / Surcharge). Service Loan and
// Others are still 0 at this point, same as at generation time.
$preview = [];
$previewCarry = [];
foreach ($unbilledReadings as $r) {
    $rate = get_active_rate($pdo, $r['connection_type_id']);
    if ($rate) {
        $calc = calculate_bill_amount($pdo, (float)$r['consumption'], $rate);
        $freshScf = calculate_scf($pdo, $r['consumption']);
        $freshElectricity = calculate_electricity($pdo, $r['consumption'], $r['address']);

        $carry = carry_forward_charges($pdo, $r['consumer_id'], $r['reading_period']);
        $previousBalance = $carry['previous_balance'] ?? 0;
        $scf = round($freshScf + ($carry['scf_carry'] ?? 0), 2);
        $electricity = round($freshElectricity + ($carry['electricity_carry'] ?? 0), 2);
        $surcharge = round(
            ($carry['surcharge_carry'] ?? 0)
            + calculate_surcharge_increment($carry['prior_consumption'] ?? 0, $carry['prior_rate_per_cubic'] ?? 0),
            2
        );

        $previewCarry[$r['id']] = $previousBalance > 0 ? $previousBalance : 0;
        $preview[$r['id']] = calculate_grand_total($calc['total_amount'], $previousBalance, $scf, $electricity, 0, $surcharge, 0);
    } else {
        $preview[$r['id']] = null; // No rate configured
    }
}

// True count of boxes that will actually be checked on render (rows with
// no rate configured are shown disabled/unchecked) — used to detect
// max_input_vars truncation on submit, see the POST handler above.
$expectedCount = count(array_filter($preview, fn($v) => $v !== null));
?>

<div class="card">
  <div class="card-header">
    <h2>Select Billing Month</h2>
  </div>
  <form method="get" class="form-row">
    <div class="form-group mb-0">
      <label>Billing Month</label>
      <?= billing_month_select('period', $period, '') ?>
      <div class="hint">Readings for this Billing Month compare last month's reading to the new one taken this month.</div>
    </div>
    <div class="form-group mb-0" style="align-self:end;">
      <button class="btn btn-outline" type="submit">Load Readings</button>
    </div>
  </form>
</div>

<div class="card">
  <div class="card-header">
    <h2>Unbilled Readings — Billing Month: <?= h(billing_month_label($periodDate)) ?> <span class="text-muted">(readings <?= h(reading_range_hint($periodDate)) ?>) — <?= count($unbilledReadings) ?></span></h2>
  </div>
  <p class="hint" style="padding:0 20px;">Est. Amount already includes the Water Charge, SCF, Electricity, and — if the consumer has an unpaid prior bill — the Previous Balance, carried SCF/Electricity, and Surcharge that come with it. Service Loan and Others can be filled in per bill afterward from Billing → Edit Charges.</p>

  <?php if (empty($unbilledReadings)): ?>
    <div class="empty-state">
      <div class="ico">✅</div>
      All readings for this month already have bills — or no readings have been recorded yet.
      <br><a href="../readings/list.php?period=<?= h($period) ?>">Go record readings for this month →</a>
    </div>
  <?php else: ?>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="period" value="<?= h($period) ?>">
    <input type="hidden" name="expected_count" value="<?= (int)$expectedCount ?>">
    <div class="form-group" style="padding:0 20px 16px;max-width:260px;">
      <label>Billing Date</label>
      <input type="date" name="billing_date" value="<?= h(date('Y-m-d')) ?>" required>
      <div class="hint">Applied to all bills generated in this batch. Due Date is calculated from this date.</div>
    </div>
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th style="width:34px;"><input type="checkbox" id="checkAll" checked></th>
            <th>Account #</th><th>Consumer</th><th>Type</th>
            <th class="num">Consumption</th><th class="num">Est. Amount</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($unbilledReadings as $r): ?>
          <tr>
            <td>
              <input type="checkbox" name="reading_ids[]" value="<?= $r['id'] ?>"
                     class="rowcheck" <?= $preview[$r['id']] === null ? 'disabled' : 'checked' ?>>
            </td>
            <td><?= h($r['account_number']) ?></td>
            <td><?= h($r['last_name'] . ', ' . $r['first_name']) ?></td>
            <td><?= h($r['type_name']) ?></td>
            <td class="num"><?= number_format($r['consumption'], 2) ?> m³</td>
            <td class="num">
              <?php if ($preview[$r['id']] === null): ?>
                <span class="badge badge-danger">No rate set</span>
              <?php else: ?>
                <?= money($pdo, $preview[$r['id']]) ?>
                <?php if (!empty($previewCarry[$r['id']])): ?>
                  <br><span class="badge badge-warning" title="Previous unpaid balance carried into this bill">+<?= money($pdo, $previewCarry[$r['id']]) ?> carried</span>
                <?php endif; ?>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="row-actions" style="margin-top:16px;">
      <button type="submit" class="btn btn-primary">Generate Selected Bills</button>
      <a href="list.php" class="btn btn-outline">Cancel</a>
    </div>
  </form>
  <?php endif; ?>
</div>

<script>
document.getElementById('checkAll')?.addEventListener('change', function () {
  document.querySelectorAll('.rowcheck:not([disabled])').forEach(cb => cb.checked = this.checked);
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
