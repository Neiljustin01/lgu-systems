<?php
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    set_flash('error', 'Invalid request method.');
    redirect('list.php');
}
require_csrf();

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM billing WHERE id = :id");
$stmt->execute(['id' => $id]);
$bill = $stmt->fetch();

if ($bill) {
    // Refuse to delete a bill that already has payments recorded against
    // it — deleting it would cascade-delete those payment/OR rows too,
    // silently wiping the receipt trail. Staff must void/remove the
    // payments first (a deliberate, auditable action) before the bill
    // itself can be removed.
    $payCount = $pdo->prepare("SELECT COUNT(*) FROM payments WHERE billing_id = :id");
    $payCount->execute(['id' => $id]);
    if ((int)$payCount->fetchColumn() > 0) {
        set_flash('error', 'This bill cannot be deleted because it already has payment(s)/OR number(s) recorded against it. Remove those payments first.');
    } else {
        $del = $pdo->prepare("DELETE FROM billing WHERE id = :id");
        $del->execute(['id' => $id]);
        set_flash('success', 'Bill "' . $bill['bill_number'] . '" was deleted.');
    }
} else {
    set_flash('error', 'Bill not found.');
}

redirect('list.php');
