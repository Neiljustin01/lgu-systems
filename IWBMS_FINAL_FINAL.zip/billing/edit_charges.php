<?php
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

$pageTitle = 'Edit Additional Charges';
$activeNav = 'billing';
$backUrl   = 'view.php?id=' . $id;
$backLabel = 'Back to Bill';
require_once __DIR__ . '/../includes/header.php';

$stmt = $pdo->prepare("
    SELECT b.*, c.first_name, c.last_name, c.account_number
    FROM billing b JOIN consumers c ON c.id = b.consumer_id
    WHERE b.id = :id
");
$stmt->execute(['id' => $id]);
$bill = $stmt->fetch();

if (!$bill) {
    set_flash('error', 'Bill not found.');
    redirect('list.php');
}
$pageSub = $bill['bill_number'] . ' — ' . $bill['last_name'] . ', ' . $bill['first_name'];

$errors = [];
$serviceLoan = $bill['service_loan'];
$others = $bill['others_amount'];
$electricity = $bill['electricity_amount'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $serviceLoan = trim($_POST['service_loan'] ?? '0');
    $others = trim($_POST['others_amount'] ?? '0');
    $electricity = trim($_POST['electricity_amount'] ?? '0');

    if ($serviceLoan === '' || !is_numeric($serviceLoan) || (float)$serviceLoan < 0) {
        $errors[] = 'Service Loan must be a valid number (0 or more).';
    }
    if ($others === '' || !is_numeric($others) || (float)$others < 0) {
        $errors[] = 'Others must be a valid number (0 or more).';
    }
    if ($electricity === '' || !is_numeric($electricity) || (float)$electricity < 0) {
        $errors[] = 'Electricity must be a valid number (0 or more).';
    }

    if (!$errors) {
        $newTotal = calculate_grand_total(
            $bill['water_amount'], $bill['previous_balance'], $bill['scf_amount'], $electricity,
            $serviceLoan, $bill['surcharge_amount'], $others
        );
        $newBalance = round($newTotal - (float)$bill['amount_paid'], 2);

        // Keep an already-overdue bill flagged as overdue; otherwise
        // recompute paid/partial/unpaid from the new balance.
        if ($bill['status'] === 'overdue' && $newBalance > 0.01) {
            $newStatus = 'overdue';
        } elseif ($newBalance <= 0.01) {
            $newStatus = 'paid';
        } elseif ((float)$bill['amount_paid'] > 0) {
            $newStatus = 'partial';
        } else {
            $newStatus = 'unpaid';
        }

        $upd = $pdo->prepare("
            UPDATE billing
            SET service_loan = :sl, others_amount = :ot, electricity_amount = :elec, total_amount = :tot,
                balance = :bal, status = :st
            WHERE id = :id
        ");
        $upd->execute([
            'sl' => $serviceLoan,
            'ot' => $others,
            'elec' => $electricity,
            'tot' => $newTotal,
            'bal' => max(0, $newBalance),
            'st' => $newStatus,
            'id' => $id,
        ]);

        set_flash('success', 'Additional charges updated.');
        redirect('view.php?id=' . $id);
    }
}
?>

<div class="card" style="max-width:600px;">
  <div class="card-header"><h2>Additional Charges — <?= h($bill['bill_number']) ?></h2></div>

  <?php if ($errors): ?>
    <div class="alert alert-danger"><?= implode('<br>', array_map('h', $errors)) ?></div>
  <?php endif; ?>

  <div class="bill-meta-grid" style="margin-bottom:18px;">
    <div><span>Water Charge:</span> <strong><?= money($pdo, $bill['water_amount']) ?></strong></div>
    <div><span>Previous Balance:</span> <strong><?= money($pdo, $bill['previous_balance']) ?></strong></div>
    <div><span>SCF:</span> <strong><?= money($pdo, $bill['scf_amount']) ?></strong></div>
    <div><span>Surcharge:</span> <strong><?= money($pdo, $bill['surcharge_amount']) ?></strong></div>
  </div>

  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= $id ?>">
    <div class="form-row">
      <div class="form-group">
        <label>Electricity</label>
        <input type="number" step="0.01" min="0" name="electricity_amount" value="<?= h($electricity) ?>">
        <div class="hint">Auto-calculated from consumption by default — override here if this consumer's actual electric bill differs.</div>
      </div>
      <div class="form-group">
        <label>Service Loan</label>
        <input type="number" step="0.01" min="0" name="service_loan" value="<?= h($serviceLoan) ?>">
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label>Others</label>
        <input type="number" step="0.01" min="0" name="others_amount" value="<?= h($others) ?>">
      </div>
    </div>
    <div class="hint" style="margin-bottom:14px;">SCF is still calculated automatically from consumption. Surcharge is applied automatically once a bill goes overdue unpaid. A manual Electricity amount here also becomes the new baseline for next period's carry-forward.</div>
    <div class="row-actions">
      <button type="submit" class="btn btn-primary">Save Charges</button>
      <a href="view.php?id=<?= $id ?>" class="btn btn-outline">Cancel</a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
