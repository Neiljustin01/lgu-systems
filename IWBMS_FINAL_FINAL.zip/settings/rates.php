<?php
$pageTitle = 'Rates & Connection Types';
$pageSub   = 'Customize pricing per connection type — add a new rate any time prices change';
$activeNav = 'rates';
require_once __DIR__ . '/../includes/header.php';

$errors = [];

// --- Handle: add connection type ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_type') {
    require_csrf();
    $typeName = trim($_POST['type_name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    if ($typeName === '') {
        set_flash('error', 'Connection type name is required.');
    } else {
        $stmt = $pdo->prepare("INSERT INTO connection_types (type_name, description) VALUES (:n, :d)");
        try {
            $stmt->execute(['n' => $typeName, 'd' => $desc]);
            set_flash('success', "Connection type \"$typeName\" added. Don't forget to set a rate for it below.");
        } catch (PDOException $e) {
            set_flash('error', 'That connection type name already exists.');
        }
    }
    redirect('rates.php');
}

// --- Handle: add rate ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_rate') {
    require_csrf();
    $ctId = (int)($_POST['connection_type_id'] ?? 0);
    $minConsumption = trim($_POST['minimum_consumption'] ?? '');
    $minCharge = trim($_POST['minimum_charge'] ?? '');
    $ratePerCubic = trim($_POST['rate_per_cubic'] ?? '');
    $effectiveDate = $_POST['effective_date'] ?? date('Y-m-d');
    $tierUpto = $_POST['tier_upto'] ?? [];
    $tierRate = $_POST['tier_rate'] ?? [];

    if (!$ctId || $minConsumption === '' || $minCharge === '' || $ratePerCubic === '') {
        set_flash('error', 'Please fill out all rate fields.');
    } else {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("
            INSERT INTO rates (connection_type_id, minimum_consumption, minimum_charge, rate_per_cubic, effective_date, is_active)
            VALUES (:ct, :mc, :ch, :rp, :ed, 1)
        ");
        $stmt->execute([
            'ct' => $ctId, 'mc' => $minConsumption, 'ch' => $minCharge, 'rp' => $ratePerCubic, 'ed' => $effectiveDate,
        ]);
        $rateId = $pdo->lastInsertId();

        // Optional progressive tiers: only rows where a rate was actually
        // filled in are saved, so blank leftover rows from the form are ignored.
        $order = 1;
        $tierStmt = $pdo->prepare("
            INSERT INTO rate_tiers (rate_id, tier_order, upto_consumption, rate_per_cubic)
            VALUES (:rid, :ord, :upto, :rp)
        ");
        foreach ($tierRate as $i => $rPerCubic) {
            $rPerCubic = trim($rPerCubic);
            if ($rPerCubic === '') continue;
            $upto = trim($tierUpto[$i] ?? '');
            $tierStmt->execute([
                'rid' => $rateId,
                'ord' => $order,
                'upto' => $upto === '' ? null : $upto,
                'rp' => $rPerCubic,
            ]);
            $order++;
        }
        $pdo->commit();

        $tierCount = $order - 1;
        $tierNote = $tierCount > 0 ? " with $tierCount tier(s)" : '';
        set_flash('success', "New rate added{$tierNote}. It will apply to bills generated on or after " . format_date($effectiveDate) . '.');
    }
    redirect('rates.php');
}

// --- Handle: toggle rate active/inactive ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['toggle_rate'])) {
    require_csrf();
    $rid = (int)$_GET['toggle_rate'];
    $pdo->prepare("UPDATE rates SET is_active = 1 - is_active WHERE id = :id")->execute(['id' => $rid]);
    set_flash('success', 'Rate status updated.');
    redirect('rates.php');
}

// --- Handle: toggle connection type active/inactive ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['toggle_type'])) {
    require_csrf();
    $tid = (int)$_GET['toggle_type'];
    $pdo->prepare("UPDATE connection_types SET is_active = 1 - is_active WHERE id = :id")->execute(['id' => $tid]);
    set_flash('success', 'Connection type status updated.');
    redirect('rates.php');
}

$types = $pdo->query("SELECT * FROM connection_types ORDER BY type_name")->fetchAll();
$rates = $pdo->query("
    SELECT r.*, ct.type_name FROM rates r
    JOIN connection_types ct ON ct.id = r.connection_type_id
    ORDER BY ct.type_name, r.effective_date DESC
")->fetchAll();

// Tiers for every rate above, grouped by rate_id, so we can show a
// bracket-by-bracket breakdown next to each rate that has one.
$tiersByRate = [];
if ($rates) {
    $ids = array_column($rates, 'id');
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $tierStmt = $pdo->prepare("SELECT * FROM rate_tiers WHERE rate_id IN ($placeholders) ORDER BY rate_id, tier_order");
    $tierStmt->execute($ids);
    foreach ($tierStmt->fetchAll() as $t) {
        $tiersByRate[$t['rate_id']][] = $t;
    }
}
?>

<div class="card">
  <div class="card-header"><h2>Connection Types</h2></div>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Type Name</th><th>Description</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($types as $t): ?>
        <tr>
          <td><?= h($t['type_name']) ?></td>
          <td><?= h($t['description']) ?></td>
          <td><?= $t['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-muted">Inactive</span>' ?></td>
          <td><a href="?toggle_type=<?= $t['id'] ?>" class="btn btn-outline btn-sm" data-post>
            <?= $t['is_active'] ? 'Deactivate' : 'Activate' ?>
          </a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <h3 style="margin-top:22px; font-size:14px;">Add New Connection Type</h3>
  <form method="post" class="form-row">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="add_type">
    <div class="form-group mb-0">
      <label class="required">Type Name</label>
      <input type="text" name="type_name" placeholder="e.g. Government, Bulk" required>
    </div>
    <div class="form-group mb-0">
      <label>Description</label>
      <input type="text" name="description" placeholder="Optional notes">
    </div>
    <div class="form-group mb-0" style="align-self:end;">
      <button class="btn btn-primary" type="submit">+ Add Type</button>
    </div>
  </form>
</div>

<div class="card">
  <div class="card-header"><h2>Rate History &amp; Current Rates</h2></div>
  <p class="hint" style="margin-top:-8px; margin-bottom:16px;">
    The system always uses the rate with the latest effective date (on or before the billing date) for each connection type.
    To change a price, simply add a new rate below — old bills keep the rate that applied when they were generated.
  </p>
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>Connection Type</th><th class="num">Min. Consumption</th><th class="num">Minimum Charge</th>
          <th>Pricing Beyond Minimum</th><th>Effective Date</th><th>Status</th><th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rates as $r):
          $tiers = $tiersByRate[$r['id']] ?? [];
          $tierSummary = format_tier_summary($pdo, $r, $tiers);
        ?>
        <tr>
          <td><?= h($r['type_name']) ?></td>
          <td class="num"><?= number_format($r['minimum_consumption'], 2) ?> m³</td>
          <td class="num"><?= money($pdo, $r['minimum_charge']) ?></td>
          <td>
            <?php if ($tierSummary): ?>
              <span class="badge badge-success" style="margin-right:6px;">Tiered</span>
              <span style="font-size:12.5px;"><?= h($tierSummary) ?></span>
            <?php else: ?>
              <?= money($pdo, $r['rate_per_cubic']) ?> / m³ <span class="hint">(flat)</span>
            <?php endif; ?>
          </td>
          <td><?= format_date($r['effective_date']) ?></td>
          <td><?= $r['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-muted">Inactive</span>' ?></td>
          <td><a href="?toggle_rate=<?= $r['id'] ?>" class="btn btn-outline btn-sm" data-post>
            <?= $r['is_active'] ? 'Deactivate' : 'Activate' ?>
          </a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <h3 style="margin-top:22px; font-size:14px;">Add New Rate</h3>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="add_rate">
    <div class="form-row">
      <div class="form-group">
        <label class="required">Connection Type</label>
        <select name="connection_type_id" required>
          <?php foreach ($types as $t): ?>
            <option value="<?= $t['id'] ?>"><?= h($t['type_name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label class="required">Minimum Consumption (m³)</label>
        <input type="number" step="0.01" name="minimum_consumption" value="10" required>
        <div class="hint">Consumption covered by the minimum/flat charge.</div>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="required">Minimum Charge</label>
        <input type="number" step="0.01" name="minimum_charge" required>
      </div>
      <div class="form-group">
        <label class="required">Rate per m³ (beyond minimum)</label>
        <input type="number" step="0.01" name="rate_per_cubic" required>
        <div class="hint">Used as a flat rate if you don't add tiers below. If you do add tiers, set this to match your highest bracket's rate.</div>
      </div>
      <div class="form-group">
        <label class="required">Effective Date</label>
        <input type="date" name="effective_date" value="<?= date('Y-m-d') ?>" required>
      </div>
    </div>

    <div class="form-group" style="margin-top:10px;">
      <label>Tiered / Progressive Pricing (optional)</label>
      <div class="hint" style="margin-bottom:10px;">
        Leave this empty for a flat rate. To charge more per m³ the more a consumer uses
        (e.g. ₱9.55/m³ for 11–20 m³, then ₱10.55/m³ for 21–30 m³, ₱11.55/m³ for 31+ m³),
        add one row per bracket. "Up to" is cumulative m³ <strong>beyond the minimum</strong> —
        leave it blank only on the last row, to mean "and beyond."
      </div>
      <div id="tier-rows">
        <div class="form-row tier-row">
          <div class="form-group mb-0">
            <label>Up to (m³ beyond minimum)</label>
            <input type="number" step="0.01" name="tier_upto[]" placeholder="e.g. 10">
          </div>
          <div class="form-group mb-0">
            <label>Rate per m³ in this bracket</label>
            <input type="number" step="0.01" name="tier_rate[]" placeholder="e.g. 9.55">
          </div>
          <div class="form-group mb-0" style="align-self:end;">
            <button type="button" class="btn btn-outline btn-sm remove-tier-btn">Remove</button>
          </div>
        </div>
      </div>
      <button type="button" id="add-tier-btn" class="btn btn-outline btn-sm" style="margin-top:6px;">+ Add Tier</button>
    </div>

    <button type="submit" class="btn btn-primary" style="margin-top:14px;">+ Add Rate</button>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
