<?php
$pageTitle = 'Meter Readers';
$pageSub   = 'Manage the field staff who take meter readings';
$activeNav = 'meter_readers';
require_once __DIR__ . '/../includes/header.php';

// --- Add ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add') {
    require_csrf();
    $name = trim($_POST['name'] ?? '');
    $contact = trim($_POST['contact_number'] ?? '');
    if ($name === '') {
        set_flash('error', 'Meter reader name is required.');
    } else {
        $stmt = $pdo->prepare("INSERT INTO meter_readers (name, contact_number) VALUES (:n, :c)");
        $stmt->execute(['n' => $name, 'c' => $contact]);
        set_flash('success', "Meter reader \"$name\" added.");
    }
    redirect('meter_readers.php');
}

// --- Edit ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'edit') {
    require_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $contact = trim($_POST['contact_number'] ?? '');
    if ($name === '') {
        set_flash('error', 'Meter reader name is required.');
    } else {
        $stmt = $pdo->prepare("UPDATE meter_readers SET name = :n, contact_number = :c WHERE id = :id");
        $stmt->execute(['n' => $name, 'c' => $contact, 'id' => $id]);
        set_flash('success', 'Meter reader updated.');
    }
    redirect('meter_readers.php');
}

// --- Toggle active/inactive ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['toggle'])) {
    require_csrf();
    $id = (int)$_GET['toggle'];
    $pdo->prepare("UPDATE meter_readers SET is_active = 1 - is_active WHERE id = :id")->execute(['id' => $id]);
    set_flash('success', 'Status updated.');
    redirect('meter_readers.php');
}

// --- Delete (safe: readings.meter_reader_id is ON DELETE SET NULL) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['delete'])) {
    require_csrf();
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("SELECT name FROM meter_readers WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $name = $stmt->fetchColumn();
    if ($name) {
        $pdo->prepare("DELETE FROM meter_readers WHERE id = :id")->execute(['id' => $id]);
        set_flash('success', "Meter reader \"$name\" deleted. Past readings they recorded are kept, just without a linked reader.");
    }
    redirect('meter_readers.php');
}

$readers = $pdo->query("
    SELECT mr.*, (SELECT COUNT(*) FROM readings r WHERE r.meter_reader_id = mr.id) reading_count
    FROM meter_readers mr
    ORDER BY mr.name
")->fetchAll();

$editId = (int)($_GET['edit'] ?? 0);
$editing = null;
if ($editId) {
    $stmt = $pdo->prepare("SELECT * FROM meter_readers WHERE id = :id");
    $stmt->execute(['id' => $editId]);
    $editing = $stmt->fetch();
}
?>

<div class="card">
  <div class="card-header"><h2>All Meter Readers <span class="text-muted">(<?= count($readers) ?>)</span></h2></div>

  <?php if (empty($readers)): ?>
    <div class="empty-state"><div class="ico">🚶</div>No meter readers yet. Add one below.</div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Name</th><th>Contact Number</th><th class="num">Readings Recorded</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($readers as $r): ?>
        <tr>
          <td><?= h($r['name']) ?></td>
          <td><?= h($r['contact_number'] ?: '—') ?></td>
          <td class="num"><?= number_format($r['reading_count']) ?></td>
          <td><?= $r['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-muted">Inactive</span>' ?></td>
          <td class="row-actions">
            <a href="?edit=<?= $r['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
            <a href="?toggle=<?= $r['id'] ?>" class="btn btn-outline btn-sm" data-post><?= $r['is_active'] ? 'Deactivate' : 'Activate' ?></a>
            <a href="?delete=<?= $r['id'] ?>" class="btn btn-danger btn-sm" data-post
               data-confirm="Delete this meter reader? Their past readings will be kept but no longer linked to a reader.">Delete</a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<div class="card" style="max-width:520px;">
  <div class="card-header"><h2><?= $editing ? 'Edit Meter Reader' : 'Add New Meter Reader' ?></h2></div>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="<?= $editing ? 'edit' : 'add' ?>">
    <?php if ($editing): ?><input type="hidden" name="id" value="<?= $editing['id'] ?>"><?php endif; ?>
    <div class="form-group">
      <label class="required">Full Name</label>
      <input type="text" name="name" value="<?= h($editing['name'] ?? '') ?>" required>
    </div>
    <div class="form-group">
      <label>Contact Number</label>
      <input type="text" name="contact_number" value="<?= h($editing['contact_number'] ?? '') ?>">
    </div>
    <div class="row-actions">
      <button type="submit" class="btn btn-primary"><?= $editing ? 'Update' : 'Add' ?> Meter Reader</button>
      <?php if ($editing): ?><a href="meter_readers.php" class="btn btn-outline">Cancel</a><?php endif; ?>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
