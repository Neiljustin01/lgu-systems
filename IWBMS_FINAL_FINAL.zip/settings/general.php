<?php
$pageTitle = 'General Settings';
$pageSub   = 'Municipality info, billing rules, and your admin account';
$activeNav = 'settings';
require_once __DIR__ . '/../includes/header.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_settings') {
    require_csrf();
    $fields = [
        'system_name', 'municipality_name', 'province_name', 'office_name',
        'office_address', 'office_contact', 'currency_symbol', 'due_days',
        'electricity_rate', 'scf_threshold', 'scf_base_amount', 'disconnection_grace_days',
    ];
    foreach ($fields as $f) {
        set_setting($pdo, $f, trim($_POST[$f] ?? ''));
    }
    set_flash('success', 'Settings updated successfully.');
    redirect('general.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'change_password') {
    require_csrf();
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE id = :id");
    $stmt->execute(['id' => $_SESSION['admin_id']]);
    $admin = $stmt->fetch();

    if (!$admin || !password_verify($currentPassword, $admin['password'])) {
        $errors[] = 'Current password is incorrect.';
    } elseif (strlen($newPassword) < 6) {
        $errors[] = 'New password must be at least 6 characters.';
    } elseif ($newPassword !== $confirmPassword) {
        $errors[] = 'New password and confirmation do not match.';
    } else {
        $hash = password_hash($newPassword, PASSWORD_BCRYPT);
        $upd = $pdo->prepare("UPDATE admin_users SET password = :p WHERE id = :id");
        $upd->execute(['p' => $hash, 'id' => $_SESSION['admin_id']]);
        set_flash('success', 'Password changed successfully.');
        redirect('general.php');
    }
}

$s = fn($key, $default = '') => get_setting($pdo, $key, $default);
?>

<?php if ($errors): ?>
  <div class="alert alert-danger"><?= implode('<br>', array_map('h', $errors)) ?></div>
<?php endif; ?>

<div class="card" style="max-width:760px;">
  <div class="card-header"><h2>Municipality &amp; Office Information</h2></div>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save_settings">
    <div class="form-row">
      <div class="form-group">
        <label>System Name</label>
        <input type="text" name="system_name" value="<?= h($s('system_name')) ?>">
      </div>
      <div class="form-group">
        <label>Currency Symbol</label>
        <input type="text" name="currency_symbol" value="<?= h($s('currency_symbol')) ?>">
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label>Municipality Name</label>
        <input type="text" name="municipality_name" value="<?= h($s('municipality_name')) ?>">
      </div>
      <div class="form-group">
        <label>Province</label>
        <input type="text" name="province_name" value="<?= h($s('province_name')) ?>">
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label>Office / Department Name</label>
        <input type="text" name="office_name" value="<?= h($s('office_name')) ?>">
      </div>
      <div class="form-group">
        <label>Office Contact Number</label>
        <input type="text" name="office_contact" value="<?= h($s('office_contact')) ?>">
      </div>
    </div>
    <div class="form-group">
      <label>Office Address</label>
      <input type="text" name="office_address" value="<?= h($s('office_address')) ?>">
    </div>

    <h3 style="font-size:14px; margin-top:22px;">Billing Rules</h3>
    <div class="form-row">
      <div class="form-group">
        <label class="required">Payment Due (days after billing)</label>
        <input type="number" name="due_days" value="<?= h($s('due_days', 15)) ?>" required min="1">
      </div>
      <div class="form-group">
        <label>Surcharge (unpaid prior bills)</label>
        <div class="hint" style="margin-top:9px; padding:9px 11px; border:1px solid var(--border); border-radius:6px; background:#f6f8f9;">
          Automatic — equal to the unpaid prior bill's own Consumption (cu.m) &times; the Rate per Cubic Meter it was billed at. Added fresh each time a new bill is generated while that prior bill stays unpaid. Not configurable here.
        </div>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="required">Disconnection Grace (days after Due Date)</label>
        <input type="number" name="disconnection_grace_days" value="<?= h($s('disconnection_grace_days', 15)) ?>" required min="0">
        <div class="hint">Informational only — shown as the "Disconnection Date" on the printed bill once it's overdue. Does not affect any charge.</div>
      </div>
    </div>

    <h3 style="font-size:14px; margin-top:22px;">Additional Charges (SCF &amp; Electricity)</h3>
    <div class="form-row">
      <div class="form-group">
        <label class="required">Electricity Rate (per m³ consumed)</label>
        <input type="number" step="0.01" name="electricity_rate" value="<?= h($s('electricity_rate', 6.5)) ?>" required min="0">
      </div>
      <div class="form-group">
        <label class="required">SCF Threshold (m³)</label>
        <input type="number" step="0.01" name="scf_threshold" value="<?= h($s('scf_threshold', 50)) ?>" required min="0">
        <div class="hint">Below this consumption, SCF is the flat base amount. At/above it, SCF = (consumption − threshold) + base amount.</div>
      </div>
      <div class="form-group">
        <label class="required">SCF Base Amount</label>
        <input type="number" step="0.01" name="scf_base_amount" value="<?= h($s('scf_base_amount', 10)) ?>" required min="0">
      </div>
    </div>

    <button type="submit" class="btn btn-primary">Save Settings</button>
  </form>
</div>

<div class="card" style="max-width:520px;">
  <div class="card-header"><h2>Change Admin Password</h2></div>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="change_password">
    <div class="form-group">
      <label class="required">Current Password</label>
      <input type="password" name="current_password" required>
    </div>
    <div class="form-group">
      <label class="required">New Password</label>
      <input type="password" name="new_password" required minlength="6">
    </div>
    <div class="form-group">
      <label class="required">Confirm New Password</label>
      <input type="password" name="confirm_password" required minlength="6">
    </div>
    <button type="submit" class="btn btn-navy">Update Password</button>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
