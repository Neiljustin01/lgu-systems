<?php
$consumerId = (int)($_GET['consumer_id'] ?? 0);

$pageTitle = 'Consumer Statement';
$pageSub   = 'Full billing and payment history for a single consumer';
$activeNav = 'statement';
if ($consumerId) {
    $backUrl   = '../consumers/view.php?id=' . $consumerId;
    $backLabel = 'Back to Consumer';
}
require_once __DIR__ . '/../includes/header.php';

$consumers = $pdo->query("SELECT id, account_number, first_name, last_name FROM consumers ORDER BY last_name, first_name")->fetchAll();

$consumer = null;
$bills = [];
$totalBilled = 0;
$totalPaid = 0;
$totalBalance = 0;

if ($consumerId) {
    $stmt = $pdo->prepare("
        SELECT c.*, ct.type_name FROM consumers c
        JOIN connection_types ct ON ct.id = c.connection_type_id
        WHERE c.id = :id
    ");
    $stmt->execute(['id' => $consumerId]);
    $consumer = $stmt->fetch();

    if ($consumer) {
        $stmt = $pdo->prepare("SELECT * FROM billing WHERE consumer_id = :id ORDER BY billing_period");
        $stmt->execute(['id' => $consumerId]);
        $bills = $stmt->fetchAll();
        foreach ($bills as $b) {
            $totalBilled  += $b['total_amount'];
            $totalPaid    += $b['amount_paid'];
            $totalBalance += $b['balance'];
        }
    }
}
?>

<div class="card no-print">
  <form method="get" class="form-row">
    <div class="form-group mb-0">
      <label>Consumer</label>
      <select name="consumer_id" required>
        <option value="">— Select consumer —</option>
        <?php foreach ($consumers as $c): ?>
          <option value="<?= $c['id'] ?>" <?= $consumerId === (int)$c['id'] ? 'selected' : '' ?>>
            <?= h($c['account_number'] . ' — ' . $c['last_name'] . ', ' . $c['first_name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group mb-0" style="align-self:end;">
      <button class="btn btn-outline" type="submit">View Statement</button>
      <?php if ($consumer): ?>
        <button type="button" class="btn btn-navy" onclick="window.print()">🖨️ Print</button>
      <?php endif; ?>
    </div>
  </form>
</div>

<?php if ($consumer): ?>
<?php $muniNamePrint = get_setting($pdo, 'municipality_name', 'Municipality'); ?>
<div class="print-header print-only">
  <img src="<?= BASE_URL ?>/assets/logo/seal.png" alt="<?= h($muniNamePrint) ?> Seal" class="print-header-logo print-header-logo-left" width="76" height="76">
  <img src="<?= BASE_URL ?>/assets/logo/watersystem.png" alt="Water System Logo" class="print-header-logo print-header-logo-right" width="76" height="76">
  <div class="print-header-text">
    <h2><?= h($muniNamePrint) ?></h2>
    <div><?= h(get_setting($pdo, 'office_name', 'Water Works Office')) ?></div>
  </div>
</div>
<div class="card">
  <div class="card-header"><h2>Statement of Account</h2></div>
  <div class="bill-meta-grid">
    <div><span>Consumer:</span> <strong><?= h($consumer['last_name'] . ', ' . $consumer['first_name']) ?></strong></div>
    <div><span>Account Number:</span> <strong><?= h($consumer['account_number']) ?></strong></div>
    <div><span>Connection Type:</span> <strong><?= h($consumer['type_name']) ?></strong></div>
    <div><span>Meter Number:</span> <strong><?= h($consumer['meter_number'] ?: '—') ?></strong></div>
    <div><span>Address:</span> <strong><?= h(format_consumer_address($consumer)) ?></strong></div>
    <div><span>Status:</span> <?= status_badge($consumer['status']) ?></div>
  </div>
</div>

<div class="stat-grid">
  <div class="stat-card info">
    <div class="stat-icon">🧾</div>
    <div class="stat-value"><?= money($pdo, $totalBilled) ?></div>
    <div class="stat-label">Total Billed (all time)</div>
  </div>
  <div class="stat-card success">
    <div class="stat-icon">💰</div>
    <div class="stat-value"><?= money($pdo, $totalPaid) ?></div>
    <div class="stat-label">Total Paid</div>
  </div>
  <div class="stat-card <?= $totalBalance > 0 ? 'warning' : 'success' ?>">
    <div class="stat-icon">⏳</div>
    <div class="stat-value"><?= money($pdo, $totalBalance) ?></div>
    <div class="stat-label">Current Outstanding Balance</div>
  </div>
</div>

<div class="card">
  <div class="card-header"><h2>Billing History</h2></div>
  <?php if (empty($bills)): ?>
    <div class="empty-state">No bills recorded yet for this consumer.</div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Period</th><th>Bill #</th><th class="num">Consumption</th><th class="num">Total</th><th class="num">Paid</th><th class="num">Balance</th><th>Status</th></tr></thead>
      <tbody>
        <?php foreach ($bills as $b): ?>
        <tr>
          <td><?= billing_month_label($b['billing_period']) ?></td>
          <td><?= h($b['bill_number']) ?></td>
          <td class="num"><?= number_format($b['consumption'], 2) ?> m³</td>
          <td class="num"><?= money($pdo, $b['total_amount']) ?></td>
          <td class="num"><?= money($pdo, $b['amount_paid']) ?></td>
          <td class="num"><?= money($pdo, $b['balance']) ?></td>
          <td><?= status_badge($b['status']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr>
          <td colspan="3" class="text-right"><strong>Totals</strong></td>
          <td class="num"><strong><?= money($pdo, $totalBilled) ?></strong></td>
          <td class="num"><strong><?= money($pdo, $totalPaid) ?></strong></td>
          <td class="num"><strong><?= money($pdo, $totalBalance) ?></strong></td>
          <td></td>
        </tr>
      </tfoot>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php elseif ($consumerId): ?>
  <div class="card"><div class="empty-state">Consumer not found.</div></div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
