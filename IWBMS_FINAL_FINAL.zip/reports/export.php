<?php
$pageTitle = 'Export & Backup Data';
$pageSub   = 'Download billing, readings, consumers, and full backups as files you can keep or open in Excel';
$activeNav = 'export';
require_once __DIR__ . '/../includes/header.php';

$period = $_GET['period'] ?? date('Y-m');
$periodDate = $period . '-01';

// -------------------------------------------------------------------
// Handle "Clear a Billing Month" — a destructive reset that deletes
// every reading/bill/payment for one month so it can be reused later.
// Requires typing the Billing Month name back exactly, so it can't be
// triggered by an accidental click.
// -------------------------------------------------------------------
$clearPeriod = $_GET['clear_period'] ?? $period;
$clearPeriodDate = $clearPeriod . '-01';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'clear_billing_month') {
    require_csrf();
    $clearPeriod = $_POST['clear_period'] ?? $clearPeriod;
    $clearPeriodDate = $clearPeriod . '-01';
    $expectedLabel = billing_month_label($clearPeriodDate);
    $typedLabel = trim($_POST['confirm_text'] ?? '');

    if (empty($_POST['confirm_check'])) {
        set_flash('error', 'Please check the confirmation box to clear ' . $expectedLabel . '.');
    } elseif (strcasecmp($typedLabel, $expectedLabel) !== 0) {
        set_flash('error', 'The text you typed didn\'t match "' . $expectedLabel . '" exactly, so nothing was deleted.');
    } else {
        $counts = clear_billing_month_data($pdo, $clearPeriodDate);
        set_flash('success', $expectedLabel . ' was cleared: ' . number_format($counts['bills']) . ' bill(s), '
            . number_format($counts['payments']) . ' payment(s), and ' . number_format($counts['readings'])
            . ' reading(s) deleted. That month is now empty and ready to be re-entered.');
    }
    redirect('export.php?period=' . urlencode($period) . '&clear_period=' . urlencode($clearPeriod));
}

$clearCounts = count_billing_month_data($pdo, $clearPeriodDate);

// -------------------------------------------------------------------
// Handle "Import Data" — re-uploading a previously exported CSV
// (Consumers, Readings, or Payments) to restore or bring in data.
// Results are shown directly on the page (not just a flash message)
// since an import can affect many rows and staff need to see exactly
// which ones were skipped and why.
// -------------------------------------------------------------------
$importResult = null;
$importType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'import_data') {
    require_csrf();
    $importType = $_POST['import_type'] ?? '';
    $overwriteReadings = !empty($_POST['overwrite_readings']);

    if (empty($_FILES['import_file']) || $_FILES['import_file']['error'] !== UPLOAD_ERR_OK) {
        set_flash('error', 'Please choose a CSV file to import.');
        redirect('export.php?period=' . urlencode($period) . '&clear_period=' . urlencode($clearPeriod) . '#import');
    }

    $tmpPath = $_FILES['import_file']['tmp_name'];
    $origName = $_FILES['import_file']['name'];
    if (strtolower(pathinfo($origName, PATHINFO_EXTENSION)) !== 'csv') {
        set_flash('error', '"' . $origName . '" isn\'t a .csv file. Export the data as CSV first, then upload that file.');
        redirect('export.php?period=' . urlencode($period) . '&clear_period=' . urlencode($clearPeriod) . '#import');
    }

    switch ($importType) {
        case 'consumers':
            $importResult = import_consumers_csv($pdo, $tmpPath);
            break;
        case 'readings':
            $importResult = import_readings_csv($pdo, $tmpPath, $overwriteReadings);
            break;
        case 'payments':
            $importResult = import_payments_csv($pdo, $tmpPath);
            break;
        default:
            set_flash('error', 'Please choose what kind of data this file contains.');
            redirect('export.php?period=' . urlencode($period) . '&clear_period=' . urlencode($clearPeriod) . '#import');
    }
}

// -------------------------------------------------------------------
// Handle an export request (any of the buttons below submit here with
// export=... in the query string). Each branch streams a file and exits,
// so nothing below it ever renders when an export is happening.
// -------------------------------------------------------------------
$exportType = $_GET['export'] ?? '';

if ($exportType === 'billing_month' || $exportType === 'billing_all') {
    $useAll = $exportType === 'billing_all';

    $sql = "
        SELECT
            c.account_number, c.first_name, c.last_name, c.middle_name,
            c.barangay, c.purok, c.address, c.meter_number,
            ct.type_name AS connection_type,
            b.bill_number, b.billing_period,
            b.previous_reading, b.current_reading, b.consumption,
            b.water_amount, b.previous_balance, b.scf_amount, b.electricity_amount,
            b.service_loan, b.surcharge_amount, b.others_amount,
            b.total_amount, b.amount_paid, b.balance, b.status,
            b.billing_date, b.due_date
        FROM billing b
        JOIN consumers c ON c.id = b.consumer_id
        JOIN connection_types ct ON ct.id = c.connection_type_id
    ";
    $params = [];
    if (!$useAll) {
        $sql .= " WHERE b.billing_period = :period";
        $params['period'] = $periodDate;
    }
    $sql .= " ORDER BY b.billing_period, c.last_name, c.first_name";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    $headers = [
        'Account #', 'First Name', 'Last Name', 'Middle Name',
        'Barangay', 'Purok', 'Address', 'Meter #', 'Connection Type',
        'Bill Number', 'Billing Month',
        'Previous Reading', 'Present Reading', 'Consumption (m3)',
        'Water Amount', 'Previous Balance', 'SCF', 'Electricity', 'Service Loan', 'Surcharge', 'Others',
        'Total Amount', 'Amount Paid', 'Balance', 'Status',
        'Billing Date', 'Due Date',
    ];
    $csvRows = [];
    foreach ($rows as $r) {
        $csvRows[] = [
            $r['account_number'], $r['first_name'], $r['last_name'], $r['middle_name'],
            $r['barangay'], $r['purok'], $r['address'], $r['meter_number'], $r['connection_type'],
            $r['bill_number'], billing_month_label($r['billing_period']),
            $r['previous_reading'], $r['current_reading'], $r['consumption'],
            $r['water_amount'], $r['previous_balance'], $r['scf_amount'], $r['electricity_amount'],
            $r['service_loan'], $r['surcharge_amount'], $r['others_amount'],
            $r['total_amount'], $r['amount_paid'], $r['balance'], ucfirst($r['status']),
            format_date($r['billing_date'], 'Y-m-d'), format_date($r['due_date'], 'Y-m-d'),
        ];
    }
    $fname = $useAll
        ? 'billing_all_' . date('Ymd_His') . '.csv'
        : 'billing_' . $period . '.csv';
    export_csv($fname, $headers, $csvRows);
}

if ($exportType === 'payments_month' || $exportType === 'payments_all') {
    $useAll = $exportType === 'payments_all';

    $sql = "
        SELECT
            c.account_number, c.first_name, c.last_name,
            b.bill_number, b.billing_period,
            p.or_number, p.amount_paid, p.payment_date, p.received_by
        FROM payments p
        JOIN billing b ON b.id = p.billing_id
        JOIN consumers c ON c.id = b.consumer_id
    ";
    $params = [];
    if (!$useAll) {
        $sql .= " WHERE b.billing_period = :period";
        $params['period'] = $periodDate;
    }
    $sql .= " ORDER BY p.payment_date, c.last_name, c.first_name";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    $headers = ['Account #', 'First Name', 'Last Name', 'Bill Number', 'Billing Month', 'OR Number', 'Amount Paid', 'Payment Date', 'Received By'];
    $csvRows = [];
    foreach ($rows as $r) {
        $csvRows[] = [
            $r['account_number'], $r['first_name'], $r['last_name'],
            $r['bill_number'], billing_month_label($r['billing_period']),
            $r['or_number'], $r['amount_paid'], format_date($r['payment_date'], 'Y-m-d'), $r['received_by'],
        ];
    }
    $fname = $useAll
        ? 'payments_all_' . date('Ymd_His') . '.csv'
        : 'payments_' . $period . '.csv';
    export_csv($fname, $headers, $csvRows);
}

if ($exportType === 'readings_month' || $exportType === 'readings_all') {
    $useAll = $exportType === 'readings_all';

    $sql = "
        SELECT
            c.account_number, c.first_name, c.last_name, c.meter_number,
            r.reading_period, r.previous_reading, r.current_reading, r.consumption,
            r.reading_date, mr.name AS reader_name
        FROM readings r
        JOIN consumers c ON c.id = r.consumer_id
        LEFT JOIN meter_readers mr ON mr.id = r.meter_reader_id
    ";
    $params = [];
    if (!$useAll) {
        $sql .= " WHERE r.reading_period = :period";
        $params['period'] = $periodDate;
    }
    $sql .= " ORDER BY r.reading_period, c.last_name, c.first_name";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    $headers = ['Account #', 'First Name', 'Last Name', 'Meter #', 'Billing Month', 'Previous Reading', 'Present Reading', 'Consumption (m3)', 'Reading Date', 'Meter Reader'];
    $csvRows = [];
    foreach ($rows as $r) {
        $csvRows[] = [
            $r['account_number'], $r['first_name'], $r['last_name'], $r['meter_number'],
            billing_month_label($r['reading_period']),
            $r['previous_reading'], $r['current_reading'], $r['consumption'],
            format_date($r['reading_date'], 'Y-m-d'), $r['reader_name'],
        ];
    }
    $fname = $useAll
        ? 'readings_all_' . date('Ymd_His') . '.csv'
        : 'readings_' . $period . '.csv';
    export_csv($fname, $headers, $csvRows);
}

if ($exportType === 'consumers') {
    $rows = $pdo->query("
        SELECT c.account_number, c.first_name, c.last_name, c.middle_name,
               c.contact_number, c.email, c.purok, c.barangay, c.address,
               ct.type_name AS connection_type, c.meter_number, c.meter_initial_reading,
               c.date_connected, c.status, mr.name AS assigned_reader, c.route_sequence, c.remarks
        FROM consumers c
        JOIN connection_types ct ON ct.id = c.connection_type_id
        LEFT JOIN meter_readers mr ON mr.id = c.default_meter_reader_id
        ORDER BY c.last_name, c.first_name
    ")->fetchAll();

    $headers = ['Account #', 'First Name', 'Last Name', 'Middle Name', 'Contact #', 'Email', 'Purok', 'Barangay', 'Address', 'Connection Type', 'Meter #', 'Initial Reading', 'Date Connected', 'Status', 'Assigned Reader', 'Route Order', 'Remarks'];
    $csvRows = [];
    foreach ($rows as $r) {
        $csvRows[] = [
            $r['account_number'], $r['first_name'], $r['last_name'], $r['middle_name'],
            $r['contact_number'], $r['email'], $r['purok'], $r['barangay'], $r['address'],
            $r['connection_type'], $r['meter_number'], $r['meter_initial_reading'],
            format_date($r['date_connected'], 'Y-m-d'), ucfirst($r['status']),
            $r['assigned_reader'], $r['route_sequence'], $r['remarks'],
        ];
    }
    export_csv('consumers_' . date('Ymd_His') . '.csv', $headers, $csvRows);
}

if ($exportType === 'full_backup') {
    // Record when this happened so the dashboard can remind the admin if
    // it's been a while since the last one — there's no cron job in an
    // offline install, so this reminder is the only thing standing in
    // for a scheduled backup task.
    set_setting($pdo, 'last_backup_at', date('Y-m-d H:i:s'));
    // Streams the backup directly to the browser — sets its own headers
    // and exits when done. See generate_sql_backup() in functions.php.
    generate_sql_backup($pdo, 'water_billing_backup_' . date('Ymd_His') . '.sql');
}

// -------------------------------------------------------------------
// Quick counts, just so the page isn't empty numbers-wise
// -------------------------------------------------------------------
$stmt = $pdo->prepare("SELECT COUNT(*) FROM billing WHERE billing_period = :p");
$stmt->execute(['p' => $periodDate]);
$billCountThisMonth = (int)$stmt->fetchColumn();

$totalBills = (int)$pdo->query("SELECT COUNT(*) FROM billing")->fetchColumn();
$totalConsumers = (int)$pdo->query("SELECT COUNT(*) FROM consumers")->fetchColumn();
?>

<div class="card">
  <div class="card-header"><h2>1. Billing Month Export</h2></div>
  <p class="hint" style="padding:0 20px;">Pick the Billing Month you want, then download it as a CSV spreadsheet (opens directly in Excel) — every important column: consumer info, readings, all charge breakdowns, payment status, and balances.</p>
  <form method="get" class="form-row" style="padding:0 20px 20px;">
    <div class="form-group mb-0">
      <label>Billing Month</label>
      <?= billing_month_select('period', $period, '') ?>
      <div class="hint"><?= number_format($billCountThisMonth) ?> bill(s) recorded for <?= h(billing_month_label($periodDate)) ?>.</div>
    </div>
    <div class="form-group mb-0" style="align-self:end; display:flex; gap:8px; flex-wrap:wrap;">
      <button type="submit" name="export" value="billing_month" class="btn btn-primary">⬇ Export This Month (Billing)</button>
      <button type="submit" name="export" value="payments_month" class="btn btn-outline">⬇ Export This Month (Payments)</button>
      <button type="submit" name="export" value="readings_month" class="btn btn-outline">⬇ Export This Month (Readings)</button>
    </div>
  </form>
</div>

<div class="card">
  <div class="card-header"><h2>2. Full History Export (All Billing Months)</h2></div>
  <p class="hint" style="padding:0 20px;">Every bill, payment, or reading the system has ever recorded, in one file — useful for year-end reports, audits, or moving data into Excel. <?= number_format($totalBills) ?> bill(s) total.</p>
  <div class="row-actions" style="padding:0 20px 20px;">
    <a href="?export=billing_all" class="btn btn-primary">⬇ All Billing Records (CSV)</a>
    <a href="?export=payments_all" class="btn btn-outline">⬇ All Payment Records (CSV)</a>
    <a href="?export=readings_all" class="btn btn-outline">⬇ All Meter Readings (CSV)</a>
  </div>
</div>

<div class="card">
  <div class="card-header"><h2>3. Consumers Master List</h2></div>
  <p class="hint" style="padding:0 20px;">The full consumer roster with contact info, address, meter number, connection type, and assigned reader — <?= number_format($totalConsumers) ?> consumer(s).</p>
  <div class="row-actions" style="padding:0 20px 20px;">
    <a href="?export=consumers" class="btn btn-outline">⬇ Export Consumers (CSV)</a>
  </div>
</div>

<div class="card">
  <div class="card-header"><h2>4. Full Database Backup</h2></div>
  <p class="hint" style="padding:0 20px;">
    Downloads <strong>everything</strong> — every consumer, reading, bill, payment, rate, and setting — as one
    <code>.sql</code> file. This is your safety net: since this system runs offline on your own computer,
    nothing is backed up anywhere else automatically. Keep a copy of this file somewhere safe
    (a USB drive, another computer, cloud storage) after big batches of work, like right after
    generating a month's bills or a big payment collection day.
  </p>
  <p class="hint" style="padding:0 20px;">
    <strong>To restore it later:</strong> open phpMyAdmin → select (or create) the
    <code>water_billing_system</code> database → <strong>Import</strong> tab → choose this file → <strong>Go</strong>.
  </p>
  <div class="row-actions" style="padding:0 20px 20px;">
    <a href="?export=full_backup" class="btn btn-navy">⬇ Download Full Backup (.sql)</a>
  </div>
</div>

<div class="card" id="import">
  <div class="card-header"><h2>5. Import Data (Restore from CSV)</h2></div>
  <p class="hint" style="padding:0 20px;">
    Upload a CSV file previously downloaded from this page (Sections 1–3 above) to bring that data back in —
    useful after restoring an old backup, moving to a new computer, or re-entering a month that was cleared.
    The file's column headers must match an export from this system exactly (don't rename or reorder them).
  </p>
  <ul class="hint" style="padding:0 20px 0 40px; margin-top:-8px;">
    <li><strong>Consumers</strong> — updates any consumer already on file (matched by Account #) and adds any new ones.</li>
    <li><strong>Meter Readings</strong> — restores readings for a Billing Month. Existing readings for that consumer + month are left alone unless you check "Overwrite".</li>
    <li><strong>Payments</strong> — adds payment records against bills that already exist (matched by Bill Number) and updates each bill's balance. Re-uploading the same file won't double-count a payment that's already recorded (matched by OR Number).</li>
  </ul>
  <p class="hint" style="padding:0 20px;">
    <strong>Note:</strong> full Billing rows aren't imported directly, since bill amounts depend on the rates active
    at the time a bill is generated (rate details aren't part of the Billing export). Instead: import the
    Meter Readings for that month here, then use <strong>Billing → Generate Bills</strong> to create correct bills
    from those readings, and finally import Payments if needed.
  </p>

  <?php if ($importResult): ?>
    <div class="alert <?= $importResult['inserted'] || $importResult['updated'] ? 'alert-success' : 'alert-danger' ?>" style="margin:0 20px 16px;">
      <strong>Import finished:</strong>
      <?= number_format($importResult['inserted']) ?> added,
      <?= number_format($importResult['updated']) ?> updated,
      <?= number_format($importResult['skipped']) ?> skipped.
      <?php if ($importResult['errors']): ?>
        <div style="margin-top:8px; max-height:220px; overflow:auto; font-size:0.9em;">
          <?php foreach (array_slice($importResult['errors'], 0, 200) as $err): ?>
            <div>• <?= h($err) ?></div>
          <?php endforeach; ?>
          <?php if (count($importResult['errors']) > 200): ?>
            <div>…and <?= number_format(count($importResult['errors']) - 200) ?> more.</div>
          <?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data" class="form-row" style="padding:0 20px 20px; align-items:end;">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="import_data">
    <div class="form-group mb-0">
      <label>Data Type</label>
      <select name="import_type" required>
        <option value="">— Choose —</option>
        <option value="consumers" <?= $importType === 'consumers' ? 'selected' : '' ?>>Consumers</option>
        <option value="readings" <?= $importType === 'readings' ? 'selected' : '' ?>>Meter Readings</option>
        <option value="payments" <?= $importType === 'payments' ? 'selected' : '' ?>>Payments</option>
      </select>
    </div>
    <div class="form-group mb-0">
      <label>CSV File</label>
      <input type="file" name="import_file" accept=".csv" required>
    </div>
    <div class="form-group mb-0">
      <label style="font-weight:400;">
        <input type="checkbox" name="overwrite_readings" value="1" style="width:auto; margin-right:6px;">
        Overwrite existing readings
      </label>
    </div>
    <div class="form-group mb-0">
      <button type="submit" class="btn btn-primary">⬆ Import</button>
    </div>
  </form>
</div>

<div class="card" style="border-color:#f0c4c4;">
  <div class="card-header"><h2>6. Clear a Billing Month (Reset for Reuse)</h2></div>
  <p class="hint" style="padding:0 20px;">
    Permanently deletes every meter reading, bill, and payment recorded for one Billing Month, so that
    month becomes empty again and can be re-entered from scratch — useful after testing, or to redo a
    month that was set up wrong. <strong>Always download a backup first (Section 4) — this cannot be undone.</strong>
  </p>

  <form method="get" class="form-row" style="padding:0 20px 20px; align-items:end;">
    <input type="hidden" name="period" value="<?= h($period) ?>">
    <div class="form-group mb-0">
      <label>Billing Month to Clear</label>
      <?= billing_month_select('clear_period', $clearPeriod, 'onchange="this.form.submit()"') ?>
    </div>
  </form>

  <div style="padding:0 20px 20px;">
    <p class="hint">
      <strong><?= h(billing_month_label($clearPeriodDate)) ?></strong> currently has
      <strong><?= number_format($clearCounts['readings']) ?></strong> reading(s),
      <strong><?= number_format($clearCounts['bills']) ?></strong> bill(s), and
      <strong><?= number_format($clearCounts['payments']) ?></strong> payment(s) recorded.
    </p>

    <?php if ($clearCounts['readings'] === 0 && $clearCounts['bills'] === 0 && $clearCounts['payments'] === 0): ?>
      <p class="hint">Nothing recorded for this month yet — there's nothing to clear.</p>
    <?php else: ?>
      <form method="post" onsubmit="return confirm('This will permanently delete ALL readings, bills, and payments for <?= h(billing_month_label($clearPeriodDate)) ?>. This cannot be undone. Continue?');">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="clear_billing_month">
        <input type="hidden" name="clear_period" value="<?= h($clearPeriod) ?>">
        <div class="form-group">
          <label>Type <strong><?= h(billing_month_label($clearPeriodDate)) ?></strong> exactly to confirm</label>
          <input type="text" name="confirm_text" placeholder="<?= h(billing_month_label($clearPeriodDate)) ?>" required autocomplete="off">
        </div>
        <div class="form-group">
          <label style="font-weight:400;">
            <input type="checkbox" name="confirm_check" value="1" required style="width:auto; margin-right:6px;">
            I understand this permanently deletes all data for this month and cannot be undone.
          </label>
        </div>
        <button type="submit" class="btn btn-danger">🗑 Clear <?= h(billing_month_label($clearPeriodDate)) ?></button>
      </form>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
