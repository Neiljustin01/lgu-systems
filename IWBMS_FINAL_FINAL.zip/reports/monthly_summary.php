<?php
$pageTitle = 'Monthly Summary';
$pageSub   = 'Collections and billing summary per month';
$activeNav = 'summary';
require_once __DIR__ . '/../includes/header.php';

refresh_overdue_bills($pdo);

$period = $_GET['period'] ?? date('Y-m');
$periodDate = $period . '-01';

// Overall totals for the month
$stmt = $pdo->prepare("
    SELECT
        COUNT(*) bill_count,
        COALESCE(SUM(total_amount),0) total_billed,
        COALESCE(SUM(amount_paid),0) total_collected,
        COALESCE(SUM(balance),0) total_outstanding,
        COALESCE(SUM(consumption),0) total_consumption,
        COALESCE(SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END),0) paid_count,
        COALESCE(SUM(CASE WHEN status = 'unpaid' THEN 1 ELSE 0 END),0) unpaid_count,
        COALESCE(SUM(CASE WHEN status = 'partial' THEN 1 ELSE 0 END),0) partial_count,
        COALESCE(SUM(CASE WHEN status = 'overdue' THEN 1 ELSE 0 END),0) overdue_count
    FROM billing
    WHERE billing_period = :period
");
$stmt->execute(['period' => $periodDate]);
$summary = $stmt->fetch();

// Breakdown per connection type
$byType = $pdo->prepare("
    SELECT ct.type_name,
           COUNT(*) bill_count,
           COALESCE(SUM(b.total_amount),0) total_billed,
           COALESCE(SUM(b.amount_paid),0) total_collected,
           COALESCE(SUM(b.consumption),0) total_consumption
    FROM billing b
    JOIN consumers c ON c.id = b.consumer_id
    JOIN connection_types ct ON ct.id = c.connection_type_id
    WHERE b.billing_period = :period
    GROUP BY ct.id, ct.type_name
    ORDER BY total_billed DESC
");
$byType->execute(['period' => $periodDate]);
$byType = $byType->fetchAll();

// Daily collections for bills belonging to this Billing Month (i.e. the
// same b.billing_period every other section on this page uses) — NOT the
// calendar month of the payment itself. Billing Month labels are always
// one month behind the stored billing_period (see billing_month_label()),
// so filtering by the payment's own calendar month would show collections
// for the wrong month entirely versus everything else on this page.
$daily = $pdo->prepare("
    SELECT p.payment_date, COALESCE(SUM(p.amount_paid),0) collected, COUNT(*) txn_count
    FROM payments p
    JOIN billing b ON b.id = p.billing_id
    WHERE b.billing_period = :period
    GROUP BY p.payment_date
    ORDER BY p.payment_date
");
$daily->execute(['period' => $periodDate]);
$daily = $daily->fetchAll();

// Top unpaid consumers this month
$unpaidList = $pdo->prepare("
    SELECT b.*, c.first_name, c.last_name, c.account_number
    FROM billing b JOIN consumers c ON c.id = b.consumer_id
    WHERE b.billing_period = :period AND b.status IN ('unpaid','partial','overdue')
    ORDER BY b.balance DESC
    LIMIT 15
");
$unpaidList->execute(['period' => $periodDate]);
$unpaidList = $unpaidList->fetchAll();

$collectionRate = $summary['total_billed'] > 0 ? ($summary['total_collected'] / $summary['total_billed']) * 100 : 0;
$muniNamePrint = get_setting($pdo, 'municipality_name', 'Municipality');
?>

<div class="print-header print-only">
  <img src="<?= BASE_URL ?>/assets/logo/seal.png" alt="<?= h($muniNamePrint) ?> Seal" class="print-header-logo print-header-logo-left" width="76" height="76">
  <img src="<?= BASE_URL ?>/assets/logo/watersystem.png" alt="Water System Logo" class="print-header-logo print-header-logo-right" width="76" height="76">
  <div class="print-header-text">
    <h2><?= h($muniNamePrint) ?></h2>
    <div><?= h(get_setting($pdo, 'office_name', 'Water Works Office')) ?></div>
    <h3 style="margin-top:10px;">Monthly Summary — <?= h(billing_month_label($periodDate)) ?></h3>
  </div>
</div>

<div class="card">
  <form method="get" class="form-row">
    <div class="form-group mb-0">
      <label>Billing Month</label>
      <?= billing_month_select('period', $period, '') ?>
    </div>
    <div class="form-group mb-0" style="align-self:end;">
      <button class="btn btn-outline" type="submit">View Summary</button>
      <button type="button" class="btn btn-navy" onclick="window.print()">🖨️ Print</button>
    </div>
  </form>
</div>

<div class="stat-grid">
  <div class="stat-card info">
    <div class="stat-icon">🧾</div>
    <div class="stat-value"><?= number_format($summary['bill_count']) ?></div>
    <div class="stat-label">Bills Generated — Billing Month: <?= h(billing_month_label($periodDate)) ?></div>
  </div>
  <div class="stat-card teal">
    <div class="stat-icon">💧</div>
    <div class="stat-value"><?= number_format($summary['total_consumption'], 1) ?> m³</div>
    <div class="stat-label">Total Water Consumption</div>
  </div>
  <div class="stat-card success">
    <div class="stat-icon">💰</div>
    <div class="stat-value"><?= money($pdo, $summary['total_collected']) ?></div>
    <div class="stat-label">Total Collected (<?= number_format($collectionRate, 1) ?>% of billed)</div>
  </div>
  <div class="stat-card warning">
    <div class="stat-icon">⏳</div>
    <div class="stat-value"><?= money($pdo, $summary['total_outstanding']) ?></div>
    <div class="stat-label">Outstanding Balance</div>
  </div>
</div>

<div class="card">
  <div class="card-header"><h2>Bill Status Breakdown</h2></div>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Status</th><th class="num">Count</th></tr></thead>
      <tbody>
        <tr><td><?= status_badge('paid') ?></td><td class="num"><?= number_format($summary['paid_count']) ?></td></tr>
        <tr><td><?= status_badge('partial') ?></td><td class="num"><?= number_format($summary['partial_count']) ?></td></tr>
        <tr><td><?= status_badge('unpaid') ?></td><td class="num"><?= number_format($summary['unpaid_count']) ?></td></tr>
        <tr><td><?= status_badge('overdue') ?></td><td class="num"><?= number_format($summary['overdue_count']) ?></td></tr>
      </tbody>
    </table>
  </div>
</div>

<div class="card">
  <div class="card-header"><h2>Breakdown by Connection Type</h2></div>
  <?php if (empty($byType)): ?>
    <div class="empty-state">No bills for this month yet.</div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Connection Type</th><th class="num">Bills</th><th class="num">Consumption</th><th class="num">Total Billed</th><th class="num">Total Collected</th></tr></thead>
      <tbody>
        <?php foreach ($byType as $t): ?>
        <tr>
          <td><?= h($t['type_name']) ?></td>
          <td class="num"><?= number_format($t['bill_count']) ?></td>
          <td class="num"><?= number_format($t['total_consumption'], 1) ?> m³</td>
          <td class="num"><?= money($pdo, $t['total_billed']) ?></td>
          <td class="num"><?= money($pdo, $t['total_collected']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-header"><h2>Daily Collections</h2></div>
  <?php if (empty($daily)): ?>
    <div class="empty-state">No payments recorded yet for this month.</div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Date</th><th class="num">Transactions</th><th class="num">Amount Collected</th></tr></thead>
      <tbody>
        <?php foreach ($daily as $d): ?>
        <tr>
          <td><?= format_date($d['payment_date']) ?></td>
          <td class="num"><?= number_format($d['txn_count']) ?></td>
          <td class="num"><?= money($pdo, $d['collected']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-header"><h2>Top Unpaid / Outstanding Accounts</h2></div>
  <?php if (empty($unpaidList)): ?>
    <div class="empty-state">🎉 No unpaid balances for this month.</div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Bill #</th><th>Consumer</th><th class="num">Balance</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($unpaidList as $u): ?>
        <tr>
          <td><?= h($u['bill_number']) ?></td>
          <td><?= h($u['last_name'] . ', ' . $u['first_name']) ?> (<?= h($u['account_number']) ?>)</td>
          <td class="num"><?= money($pdo, $u['balance']) ?></td>
          <td><?= status_badge($u['status']) ?></td>
          <td class="row-actions"><a href="../billing/view.php?id=<?= $u['id'] ?>" class="btn btn-outline btn-sm">View</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
