<?php
/**
 * Database connection (PDO)
 * ---------------------------------------------------------------
 * Edit the four constants below only if your XAMPP MySQL setup is
 * different from the default (root user, no password, port 3306).
 * ---------------------------------------------------------------
 */

// Load the friendly error handler first, as early as possible, so it
// protects this file too (and everything that runs after it).
require_once __DIR__ . '/../includes/error_handler.php';

define('DB_HOST', 'localhost');
define('DB_NAME', 'water_billing_system');
define('DB_USER', 'root');
define('DB_PASS', '');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die('
        <div style="font-family: Arial, sans-serif; max-width:600px; margin:80px auto; padding:24px 28px;
                    border:1px solid #e2b8b8; background:#fdf3f3; border-radius:8px; color:#7a2020;">
            <h2 style="margin-top:0;">Database connection failed</h2>
            <p>' . htmlspecialchars($e->getMessage()) . '</p>
            <p>Checklist:</p>
            <ul>
                <li>Is MySQL running in the XAMPP Control Panel?</li>
                <li>Have you imported <code>database/water_billing.sql</code> in phpMyAdmin?</li>
                <li>Do the credentials in <code>config/database.php</code> match your MySQL setup?</li>
            </ul>
        </div>
    ');
}
