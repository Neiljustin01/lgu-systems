<?php
$pageTitle = 'Consumers';
$pageSub   = 'Manage household and business water connections';
$activeNav = 'consumers';
require_once __DIR__ . '/../includes/header.php';

$search = trim($_GET['q'] ?? '');
$statusFilter = $_GET['status'] ?? '';
$typeFilter   = $_GET['type'] ?? '';
$readerFilter = $_GET['reader'] ?? '';

// --- Handle bulk "assign to reader" action ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'bulk_assign') {
    require_csrf();
    $selectedIds = array_map('intval', $_POST['consumer_ids'] ?? []);
    $bulkReaderId = $_POST['bulk_reader_id'] ?: null;
    $autoSequence = isset($_POST['auto_sequence']);

    if (empty($selectedIds)) {
        set_flash('error', 'Select at least one consumer to assign.');
    } else {
        $nextSeq = $autoSequence ? get_next_route_sequence($pdo, $bulkReaderId) : null;
        foreach ($selectedIds as $cid) {
            if ($autoSequence) {
                $stmt = $pdo->prepare("UPDATE consumers SET default_meter_reader_id = :r, route_sequence = :seq WHERE id = :id");
                $stmt->execute(['r' => $bulkReaderId, 'seq' => $nextSeq, 'id' => $cid]);
                $nextSeq += 10;
            } else {
                $stmt = $pdo->prepare("UPDATE consumers SET default_meter_reader_id = :r WHERE id = :id");
                $stmt->execute(['r' => $bulkReaderId, 'id' => $cid]);
            }
        }
        $readerName = $bulkReaderId
            ? $pdo->query("SELECT name FROM meter_readers WHERE id = " . (int)$bulkReaderId)->fetchColumn()
            : null;
        set_flash('success', count($selectedIds) . ' consumer(s) ' . ($readerName ? "assigned to \"$readerName\"" : 'unassigned') . '.');
    }
    redirect('list.php?' . http_build_query(['q' => $search, 'status' => $statusFilter, 'type' => $typeFilter, 'reader' => $readerFilter]));
}

$where  = [];
$params = [];

if ($search !== '') {
    $where[] = "(c.first_name LIKE :s1 OR c.last_name LIKE :s2 OR c.account_number LIKE :s3 OR c.meter_number LIKE :s4)";
    $params['s1'] = "%$search%";
    $params['s2'] = "%$search%";
    $params['s3'] = "%$search%";
    $params['s4'] = "%$search%";
}
if ($statusFilter !== '') {
    $where[] = "c.status = :status";
    $params['status'] = $statusFilter;
}
if ($typeFilter !== '') {
    $where[] = "c.connection_type_id = :type";
    $params['type'] = $typeFilter;
}
if ($readerFilter !== '') {
    if ($readerFilter === 'none') {
        $where[] = "c.default_meter_reader_id IS NULL";
    } else {
        $where[] = "c.default_meter_reader_id = :reader";
        $params['reader'] = $readerFilter;
    }
}

$whereSql = $where ? (" WHERE " . implode(' AND ', $where)) : '';

// Count matching rows first (same filters, no LIMIT) to drive pagination.
$countSql = "
    SELECT COUNT(*)
    FROM consumers c
    JOIN connection_types ct ON ct.id = c.connection_type_id
    LEFT JOIN meter_readers mr ON mr.id = c.default_meter_reader_id
" . $whereSql;
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$pager = paginate((int)$countStmt->fetchColumn(), 25);

$sql = "
    SELECT c.*, ct.type_name, mr.name AS reader_name
    FROM consumers c
    JOIN connection_types ct ON ct.id = c.connection_type_id
    LEFT JOIN meter_readers mr ON mr.id = c.default_meter_reader_id
" . $whereSql;
// When filtering to one reader, sort by route order to mirror the physical route.
// Otherwise sort by name for easy lookup.
$sql .= ($readerFilter !== '' && $readerFilter !== 'none')
    ? " ORDER BY c.route_sequence IS NULL, c.route_sequence, c.last_name, c.first_name"
    : " ORDER BY c.last_name, c.first_name";
$sql .= " LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($sql);
foreach ($params as $k => $v) $stmt->bindValue($k, $v);
$stmt->bindValue('limit', $pager['perPage'], PDO::PARAM_INT);
$stmt->bindValue('offset', $pager['offset'], PDO::PARAM_INT);
$stmt->execute();
$consumers = $stmt->fetchAll();

$types = get_connection_types($pdo);
$meterReaders = get_meter_readers($pdo);
?>

<div class="card">
  <div class="card-header">
    <h2>All Consumers <span class="text-muted">(<?= number_format($pager['totalRows']) ?>)</span></h2>
    <div class="actions">
      <a href="add.php" class="btn btn-primary">+ Add Consumer</a>
    </div>
  </div>

  <form method="get" class="form-row" style="margin-bottom:18px;">
    <div class="form-group mb-0">
      <label>Search</label>
      <input type="text" name="q" value="<?= h($search) ?>" placeholder="Name, account #, or meter #">
    </div>
    <div class="form-group mb-0">
      <label>Status</label>
      <select name="status">
        <option value="">All statuses</option>
        <?php foreach (consumer_statuses() as $s): ?>
          <option value="<?= $s ?>" <?= $statusFilter === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group mb-0">
      <label>Connection Type</label>
      <select name="type">
        <option value="">All types</option>
        <?php foreach ($types as $t): ?>
          <option value="<?= $t['id'] ?>" <?= (string)$typeFilter === (string)$t['id'] ? 'selected' : '' ?>><?= h($t['type_name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group mb-0">
      <label>Meter Reader</label>
      <select name="reader">
        <option value="">All readers</option>
        <option value="none" <?= $readerFilter === 'none' ? 'selected' : '' ?>>— Not yet assigned —</option>
        <?php foreach ($meterReaders as $mr): ?>
          <option value="<?= $mr['id'] ?>" <?= (string)$readerFilter === (string)$mr['id'] ? 'selected' : '' ?>><?= h($mr['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group mb-0" style="align-self:end;">
      <button class="btn btn-outline" type="submit">Filter</button>
      <a href="list.php" class="btn btn-outline">Reset</a>
    </div>
  </form>

  <?php if ($pager['totalRows'] > 10): ?>
  <div style="display:flex; justify-content:flex-end; margin-bottom:12px;">
    <?= per_page_select() ?>
  </div>
  <?php endif; ?>

  <?php if (empty($consumers)): ?>
    <div class="empty-state">
      <div class="ico">👤</div>
      No consumers found. <a href="add.php">Add your first consumer</a> to get started.
    </div>
  <?php else: ?>
  <form method="post" id="bulkForm">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="bulk_assign">

    <div class="form-row" style="align-items:end; margin-bottom:12px; background:#f6f8f9; padding:12px 14px; border-radius:8px;">
      <div class="form-group mb-0">
        <label>Assign selected consumers to</label>
        <select name="bulk_reader_id">
          <option value="">— Unassign —</option>
          <?php foreach ($meterReaders as $mr): ?>
            <option value="<?= $mr['id'] ?>"><?= h($mr['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group mb-0">
        <label style="font-weight:400; display:flex; align-items:center; gap:6px;">
          <input type="checkbox" name="auto_sequence" value="1" style="width:auto;" checked>
          Also number their route order (in the sequence shown below)
        </label>
      </div>
      <div class="form-group mb-0">
        <button type="submit" class="btn btn-navy btn-sm" onclick="return confirm('Assign the checked consumers?');">Apply to Selected</button>
        <span class="hint" id="selectedCount">0 selected</span>
      </div>
    </div>

    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th style="width:30px;"><input type="checkbox" id="checkAllConsumers"></th>
            <th>Account #</th>
            <th>Name</th>
            <th>Address</th>
            <th>Type</th>
            <th>Meter #</th>
            <th>Reader</th>
            <th class="num">Route #</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($consumers as $c): ?>
          <tr>
            <td><input type="checkbox" name="consumer_ids[]" value="<?= $c['id'] ?>" class="row-check"></td>
            <td><?= h($c['account_number']) ?></td>
            <td><?= h($c['last_name'] . ', ' . $c['first_name']) ?></td>
            <td><?= h(format_consumer_address($c)) ?></td>
            <td><?= h($c['type_name']) ?></td>
            <td><?= h($c['meter_number']) ?></td>
            <td><?= h($c['reader_name'] ?: '—') ?></td>
            <td class="num"><?= $c['route_sequence'] !== null ? (int)$c['route_sequence'] : '—' ?></td>
            <td><?= status_badge($c['status']) ?></td>
            <td class="row-actions">
              <a href="view.php?id=<?= $c['id'] ?>" class="btn btn-outline btn-sm">View</a>
              <a href="edit.php?id=<?= $c['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
              <a href="delete.php?id=<?= $c['id'] ?>" class="btn btn-danger btn-sm" data-post
                 data-confirm="Delete this consumer? This also removes their readings and bills. This cannot be undone.">Delete</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php if ($pager['totalPages'] > 1): ?>
      <div class="hint" style="margin-top:8px;">"Apply to Selected" only affects the checkboxes ticked on this page — repeat on other pages if needed.</div>
    <?php endif; ?>
    <?= pagination_links($pager) ?>
  </form>
  <?php endif; ?>
</div>

<script>
(function () {
  var checkAll = document.getElementById('checkAllConsumers');
  var rowChecks = document.querySelectorAll('.row-check');
  var counter = document.getElementById('selectedCount');

  function updateCount() {
    var n = document.querySelectorAll('.row-check:checked').length;
    if (counter) counter.textContent = n + ' selected';
  }
  if (checkAll) {
    checkAll.addEventListener('change', function () {
      rowChecks.forEach(function (cb) { cb.checked = checkAll.checked; });
      updateCount();
    });
  }
  rowChecks.forEach(function (cb) { cb.addEventListener('change', updateCount); });
  updateCount();
})();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
