<?php
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

$readerId = (int)($_GET['reader_id'] ?? 0);
$next = get_next_route_sequence($pdo, $readerId ?: null);

echo json_encode(['next' => $next]);
