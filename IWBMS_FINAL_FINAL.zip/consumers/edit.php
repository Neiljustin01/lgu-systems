<?php
$id = (int)($_GET['id'] ?? 0);

$pageTitle = 'Edit Consumer';
$pageSub   = 'Update consumer and connection details';
$activeNav = 'consumers';
$backUrl   = 'view.php?id=' . $id;
$backLabel = 'Back to Profile';
require_once __DIR__ . '/../includes/header.php';

$stmt = $pdo->prepare("SELECT * FROM consumers WHERE id = :id");
$stmt->execute(['id' => $id]);
$consumer = $stmt->fetch();

if (!$consumer) {
    set_flash('error', 'Consumer not found.');
    redirect('list.php');
}

$types = get_connection_types($pdo);
$meterReaders = get_meter_readers($pdo);
$errors = [];
$data = $consumer;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    foreach (['account_number','first_name','last_name','middle_name','contact_number','email',
              'purok','barangay','address','connection_type_id','meter_number',
              'meter_initial_reading','date_connected','status','default_meter_reader_id',
              'route_sequence','remarks'] as $key) {
        $data[$key] = trim($_POST[$key] ?? '');
    }

    if ($data['first_name'] === '') $errors[] = 'First name is required.';
    if ($data['last_name'] === '') $errors[] = 'Last name is required.';
    if ($data['account_number'] === '') $errors[] = 'Account number is required.';

    if (!$errors) {
        $chk = $pdo->prepare("SELECT COUNT(*) FROM consumers WHERE account_number = :a AND id != :id");
        $chk->execute(['a' => $data['account_number'], 'id' => $id]);
        if ($chk->fetchColumn() > 0) {
            $errors[] = 'That account number is already used by another consumer.';
        }
    }

    if (!$errors) {
        $stmt = $pdo->prepare("
            UPDATE consumers SET
                account_number = :account_number,
                first_name = :first_name,
                last_name = :last_name,
                middle_name = :middle_name,
                contact_number = :contact_number,
                email = :email,
                purok = :purok,
                barangay = :barangay,
                address = :address,
                connection_type_id = :connection_type_id,
                meter_number = :meter_number,
                meter_initial_reading = :meter_initial_reading,
                date_connected = :date_connected,
                status = :status,
                default_meter_reader_id = :default_meter_reader_id,
                route_sequence = :route_sequence,
                remarks = :remarks
            WHERE id = :id
        ");
        $stmt->execute([
            'account_number' => $data['account_number'],
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'middle_name' => $data['middle_name'],
            'contact_number' => $data['contact_number'],
            'email' => $data['email'],
            'purok' => $data['purok'],
            'barangay' => $data['barangay'],
            'address' => $data['address'],
            'connection_type_id' => $data['connection_type_id'],
            'meter_number' => $data['meter_number'],
            'meter_initial_reading' => $data['meter_initial_reading'],
            'date_connected' => $data['date_connected'],
            'status' => $data['status'],
            'default_meter_reader_id' => $data['default_meter_reader_id'] ?: null,
            'route_sequence' => $data['route_sequence'] !== '' ? $data['route_sequence'] : null,
            'remarks' => $data['remarks'],
            'id' => $id,
        ]);
        set_flash('success', 'Consumer updated successfully.');
        redirect('view.php?id=' . $id);
    }
}
?>

<div class="card" style="max-width:820px;">
  <div class="card-header"><h2>Consumer Information — <?= h($consumer['account_number']) ?></h2></div>

  <?php if ($errors): ?>
    <div class="alert alert-danger"><?= implode('<br>', array_map('h', $errors)) ?></div>
  <?php endif; ?>

  <form method="post" novalidate>
    <?= csrf_field() ?>
    <div class="form-row">
      <div class="form-group">
        <label class="required">Account Number</label>
        <input type="text" name="account_number" value="<?= h($data['account_number']) ?>" required>
      </div>
      <div class="form-group">
        <label class="required">Connection Type</label>
        <select name="connection_type_id" required>
          <?php foreach ($types as $t): ?>
            <option value="<?= $t['id'] ?>" <?= (string)$data['connection_type_id'] === (string)$t['id'] ? 'selected' : '' ?>><?= h($t['type_name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="required">Last Name</label>
        <input type="text" name="last_name" value="<?= h($data['last_name']) ?>" required>
      </div>
      <div class="form-group">
        <label class="required">First Name</label>
        <input type="text" name="first_name" value="<?= h($data['first_name']) ?>" required>
      </div>
      <div class="form-group">
        <label>Middle Name</label>
        <input type="text" name="middle_name" value="<?= h($data['middle_name']) ?>">
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Contact Number</label>
        <input type="text" name="contact_number" value="<?= h($data['contact_number']) ?>">
      </div>
      <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" value="<?= h($data['email']) ?>">
      </div>
    </div>

    <?php
      // Consumers now use a single Address field (same list as Add Consumer).
      // Older records may still have purok/barangay filled in from before
      // this change — if so, and "address" itself is blank, pre-fill the
      // "Others" box with that legacy value so nothing gets silently lost.
      $legacyAddress = trim($data['purok'] . ' ' . $data['barangay']);
      $currentAddress = $data['address'] !== '' ? $data['address'] : $legacyAddress;
      $addressOptions = get_electrified_addresses();
      $addressIsKnown = in_array($currentAddress, $addressOptions, true);
      $addressIsOther = $currentAddress !== '' && !$addressIsKnown;
    ?>
    <div class="form-group">
      <label class="required">Address</label>
      <select id="addressSelect" required onchange="handleAddressChange()">
        <option value="">— Select address —</option>
        <?php foreach ($addressOptions as $opt): ?>
          <option value="<?= h($opt) ?>" <?= ($currentAddress === $opt) ? 'selected' : '' ?>><?= h($opt) ?></option>
        <?php endforeach; ?>
        <option value="__other__" <?= $addressIsOther ? 'selected' : '' ?>>Others (specify)</option>
      </select>
      <input type="text" id="addressOther" placeholder="Type the address"
             value="<?= $addressIsOther ? h($currentAddress) : '' ?>"
             style="margin-top:8px; <?= $addressIsOther ? '' : 'display:none;' ?>">
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Meter Number</label>
        <input type="text" name="meter_number" value="<?= h($data['meter_number']) ?>">
      </div>
      <div class="form-group">
        <label class="required">Initial Meter Reading</label>
        <input type="number" step="0.01" name="meter_initial_reading" value="<?= h($data['meter_initial_reading']) ?>" required>
      </div>
      <div class="form-group">
        <label>Date Connected</label>
        <input type="date" name="date_connected" value="<?= h($data['date_connected']) ?>">
      </div>
    </div>

    <h3 style="font-size:14px; margin-top:6px;">Meter Reading Route</h3>
    <div class="form-row">
      <div class="form-group">
        <label>Assigned Meter Reader</label>
        <select name="default_meter_reader_id" id="readerSelect">
          <option value="">— Not assigned —</option>
          <?php foreach ($meterReaders as $mr): ?>
            <option value="<?= $mr['id'] ?>" <?= (string)($data['default_meter_reader_id'] ?? '') === (string)$mr['id'] ? 'selected' : '' ?>><?= h($mr['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <div class="hint">Which reader normally reads this consumer's meter — lets you filter the reading grid per reader.</div>
      </div>
      <div class="form-group">
        <label>Route Order #</label>
        <input type="number" name="route_sequence" id="routeSequence" value="<?= h($data['route_sequence']) ?>">
        <div class="hint">Matches the walking order of the route (like the old "SN" column).</div>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="required">Status</label>
        <select name="status">
          <?php foreach (consumer_statuses() as $s): ?>
            <option value="<?= $s ?>" <?= $data['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <div class="form-group">
      <label>Remarks</label>
      <textarea name="remarks" rows="3"><?= h($data['remarks']) ?></textarea>
    </div>

    <div class="row-actions">
      <button type="submit" class="btn btn-primary">Update Consumer</button>
      <a href="view.php?id=<?= $id ?>" class="btn btn-outline">Cancel</a>
    </div>
  </form>
</div>

<script>
document.getElementById('readerSelect')?.addEventListener('change', function () {
  var seqField = document.getElementById('routeSequence');
  if (seqField.value !== '') return;
  var readerId = this.value;
  fetch('next_sequence.php?reader_id=' + encodeURIComponent(readerId))
    .then(function (r) { return r.json(); })
    .then(function (data) { if (data && data.next) seqField.value = data.next; })
    .catch(function () { /* silently ignore */ });
});

// Address dropdown: show/hide the free-text box when "Others" is picked.
function handleAddressChange() {
  var sel = document.getElementById('addressSelect');
  var other = document.getElementById('addressOther');
  if (sel.value === '__other__') {
    other.style.display = '';
    other.required = true;
    other.focus();
  } else {
    other.style.display = 'none';
    other.required = false;
    other.value = '';
  }
}

// On submit, inject the actual chosen address (dropdown value, or the
// typed "Others" text) into a real "address" field the server understands.
// Also clear out legacy purok/barangay so the address isn't duplicated
// across old and new fields going forward.
document.querySelector('form')?.addEventListener('submit', function (e) {
  var sel = document.getElementById('addressSelect');
  var other = document.getElementById('addressOther');
  var finalAddress = sel.value === '__other__' ? other.value.trim() : sel.value;

  if (finalAddress === '') {
    e.preventDefault();
    alert('Please choose or specify an address.');
    (sel.value === '__other__' ? other : sel).focus();
    return;
  }

  var hidden = document.createElement('input');
  hidden.type = 'hidden';
  hidden.name = 'address';
  hidden.value = finalAddress;
  this.appendChild(hidden);

  ['purok', 'barangay'].forEach(function (name) {
    var hiddenClear = document.createElement('input');
    hiddenClear.type = 'hidden';
    hiddenClear.name = name;
    hiddenClear.value = '';
    this.appendChild(hiddenClear);
  }, this);
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
