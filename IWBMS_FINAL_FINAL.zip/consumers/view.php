<?php
$pageTitle = 'Consumer Profile';
$activeNav = 'consumers';
$backUrl   = 'list.php';
$backLabel = 'Back to Consumers';
require_once __DIR__ . '/../includes/header.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("
    SELECT c.*, ct.type_name FROM consumers c
    JOIN connection_types ct ON ct.id = c.connection_type_id
    WHERE c.id = :id
");
$stmt->execute(['id' => $id]);
$consumer = $stmt->fetch();

if (!$consumer) {
    set_flash('error', 'Consumer not found.');
    redirect('list.php');
}
$pageSub = $consumer['account_number'] . ' — ' . $consumer['first_name'] . ' ' . $consumer['last_name'];

$readings = $pdo->prepare("SELECT * FROM readings WHERE consumer_id = :id ORDER BY reading_period DESC LIMIT 12");
$readings->execute(['id' => $id]);
$readings = $readings->fetchAll();

$bills = $pdo->prepare("SELECT * FROM billing WHERE consumer_id = :id ORDER BY billing_period DESC LIMIT 12");
$bills->execute(['id' => $id]);
$bills = $bills->fetchAll();

$totalOutstanding = $pdo->prepare("SELECT COALESCE(SUM(balance),0) FROM billing WHERE consumer_id = :id AND status IN ('unpaid','partial','overdue')");
$totalOutstanding->execute(['id' => $id]);
$totalOutstanding = (float)$totalOutstanding->fetchColumn();
?>

<div class="card-header" style="margin-bottom:14px;">
  <div class="row-actions">
    <a href="edit.php?id=<?= $id ?>" class="btn btn-outline btn-sm">✏️ Edit</a>
    <a href="../reports/consumer_statement.php?consumer_id=<?= $id ?>" class="btn btn-outline btn-sm">📄 View Statement</a>
    <a href="list.php" class="btn btn-outline btn-sm">← Back to list</a>
  </div>
</div>

<div class="stat-grid">
  <div class="stat-card teal">
    <div class="stat-icon">🔧</div>
    <div class="stat-value"><?= h($consumer['type_name']) ?></div>
    <div class="stat-label">Connection Type</div>
  </div>
  <div class="stat-card info">
    <div class="stat-icon">🧮</div>
    <div class="stat-value"><?= h($consumer['meter_number'] ?: '—') ?></div>
    <div class="stat-label">Meter Number</div>
  </div>
  <div class="stat-card <?= $totalOutstanding > 0 ? 'warning' : 'success' ?>">
    <div class="stat-icon">💰</div>
    <div class="stat-value"><?= money($pdo, $totalOutstanding) ?></div>
    <div class="stat-label">Outstanding Balance</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon"><?= in_array($consumer['status'], active_like_statuses(), true) ? '✅' : '⛔' ?></div>
    <div class="stat-value"><?= status_badge($consumer['status']) ?></div>
    <div class="stat-label">Account Status</div>
  </div>
</div>

<div class="card">
  <div class="card-header"><h2>Consumer Details</h2></div>
  <div class="bill-meta-grid">
    <div><span>Full Name:</span> <strong><?= h($consumer['last_name'] . ', ' . $consumer['first_name'] . ' ' . $consumer['middle_name']) ?></strong></div>
    <div><span>Account Number:</span> <strong><?= h($consumer['account_number']) ?></strong></div>
    <div><span>Contact Number:</span> <strong><?= h($consumer['contact_number'] ?: '—') ?></strong></div>
    <div><span>Email:</span> <strong><?= h($consumer['email'] ?: '—') ?></strong></div>
    <div><span>Address:</span> <strong><?= h(format_consumer_address($consumer)) ?></strong></div>
    <div><span>Date Connected:</span> <strong><?= format_date($consumer['date_connected']) ?></strong></div>
    <div><span>Initial Reading:</span> <strong><?= number_format($consumer['meter_initial_reading'], 2) ?> m³</strong></div>
    <div><span>Remarks:</span> <strong><?= h($consumer['remarks'] ?: '—') ?></strong></div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <h2>Recent Meter Readings</h2>
    <a href="../readings/add.php?consumer_id=<?= $id ?>" class="btn btn-primary btn-sm">+ Add Reading</a>
  </div>
  <?php if (empty($readings)): ?>
    <div class="empty-state"><div class="ico">🧮</div>No readings recorded yet.</div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Period</th><th class="num">Previous</th><th class="num">Current</th><th class="num">Consumption</th><th>Reading Date</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($readings as $r): ?>
        <tr>
          <td><?= billing_month_label($r['reading_period']) ?></td>
          <td class="num"><?= number_format($r['previous_reading'], 2) ?></td>
          <td class="num"><?= number_format($r['current_reading'], 2) ?></td>
          <td class="num"><?= number_format($r['consumption'], 2) ?> m³</td>
          <td><?= format_date($r['reading_date']) ?></td>
          <td class="row-actions"><a href="../readings/edit.php?id=<?= $r['id'] ?>" class="btn btn-outline btn-sm">Edit</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-header"><h2>Billing History</h2></div>
  <?php if (empty($bills)): ?>
    <div class="empty-state"><div class="ico">🧾</div>No bills generated yet for this consumer.</div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Bill #</th><th>Period</th><th class="num">Consumption</th><th class="num">Amount</th><th class="num">Balance</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($bills as $b): ?>
        <tr>
          <td><?= h($b['bill_number']) ?></td>
          <td><?= billing_month_label($b['billing_period']) ?></td>
          <td class="num"><?= number_format($b['consumption'], 2) ?> m³</td>
          <td class="num"><?= money($pdo, $b['total_amount']) ?></td>
          <td class="num"><?= money($pdo, $b['balance']) ?></td>
          <td><?= status_badge($b['status']) ?></td>
          <td class="row-actions"><a href="../billing/view.php?id=<?= $b['id'] ?>" class="btn btn-outline btn-sm">View</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
