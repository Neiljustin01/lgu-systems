<?php
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    set_flash('error', 'Invalid request method.');
    redirect('list.php');
}
require_csrf();

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM consumers WHERE id = :id");
$stmt->execute(['id' => $id]);
$consumer = $stmt->fetch();

if ($consumer) {
    // Refuse to delete a consumer who has any payment history — doing so
    // would cascade-delete their billing rows and, through those, every
    // payment/OR record ever entered for them (readings and bills alone
    // cascade too, but payments are the one thing that must never
    // silently disappear). Deactivating the consumer (status = inactive)
    // is the safe way to retire an account instead.
    $payCount = $pdo->prepare("
        SELECT COUNT(*) FROM payments p
        JOIN billing b ON b.id = p.billing_id
        WHERE b.consumer_id = :id
    ");
    $payCount->execute(['id' => $id]);
    if ((int)$payCount->fetchColumn() > 0) {
        set_flash('error', 'This consumer cannot be deleted because they have payment/OR history on record. Set their status to Inactive instead.');
    } else {
        // readings and billing rows (with no payments) are removed automatically via ON DELETE CASCADE
        $del = $pdo->prepare("DELETE FROM consumers WHERE id = :id");
        $del->execute(['id' => $id]);
        set_flash('success', 'Consumer "' . $consumer['first_name'] . ' ' . $consumer['last_name'] . '" was deleted.');
    }
} else {
    set_flash('error', 'Consumer not found.');
}

redirect('list.php');
