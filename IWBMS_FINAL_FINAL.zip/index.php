<?php
$pageTitle = 'Dashboard';
$pageSub   = 'Overview of consumers, billing and collections';
$activeNav = 'dashboard';
require_once __DIR__ . '/includes/header.php';

refresh_overdue_bills($pdo);

// --- Offline-system reminders -------------------------------------------
// There's no cron job watching this install (it only runs while someone
// has it open), so these two nudges stand in for what a scheduled task
// would normally do: remind the admin to back up, and flag if reading
// entry has gone quiet for longer than a normal billing cycle.
$lastBackupAt = get_setting($pdo, 'last_backup_at', '');
$backupDaysAgo = $lastBackupAt ? (int)floor((time() - strtotime($lastBackupAt)) / 86400) : null;
$backupIsStale = $backupDaysAgo === null || $backupDaysAgo >= 14;

$lastReadingAt = $pdo->query("SELECT MAX(created_at) FROM readings")->fetchColumn();
$readingDaysAgo = $lastReadingAt ? (int)floor((time() - strtotime($lastReadingAt)) / 86400) : null;
$readingsAreStale = $readingDaysAgo !== null && $readingDaysAgo >= 35;

$thisMonthStart = date('Y-m-01');

// --- Core stats ---
$totalConsumers  = (int)$pdo->query("SELECT COUNT(*) FROM consumers")->fetchColumn();
$activeStatusPlaceholders = implode(',', array_fill(0, count(active_like_statuses()), '?'));
$stmt = $pdo->prepare("SELECT COUNT(*) FROM consumers WHERE status IN ($activeStatusPlaceholders)");
$stmt->execute(active_like_statuses());
$activeConsumers = (int)$stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COALESCE(SUM(total_amount),0), COUNT(*) FROM billing WHERE billing_period = :m");
$stmt->execute(['m' => $thisMonthStart]);
[$billedThisMonth, $billsThisMonth] = $stmt->fetch(PDO::FETCH_NUM);

$stmt = $pdo->prepare("SELECT COALESCE(SUM(amount_paid),0) FROM billing WHERE billing_period = :m");
$stmt->execute(['m' => $thisMonthStart]);
$collectedThisMonth = (float)$stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COALESCE(SUM(balance),0), COUNT(*) FROM billing WHERE status IN ('unpaid','partial','overdue')");
$stmt->execute();
[$totalOutstanding, $unpaidCount] = $stmt->fetch(PDO::FETCH_NUM);

$overdueCount = (int)$pdo->query("SELECT COUNT(*) FROM billing WHERE status = 'overdue'")->fetchColumn();

// --- Recent bills ---
$recentBills = $pdo->query("
    SELECT b.*, c.first_name, c.last_name, c.account_number
    FROM billing b
    JOIN consumers c ON c.id = b.consumer_id
    ORDER BY b.created_at DESC
    LIMIT 8
")->fetchAll();

// --- Collection trend, last 6 months ---
$trend = $pdo->query("
    SELECT DATE_FORMAT(billing_period, '%Y-%m') ym,
           COALESCE(SUM(total_amount),0) billed,
           COALESCE(SUM(amount_paid),0) collected
    FROM billing
    WHERE billing_period >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
    GROUP BY ym
    ORDER BY ym
")->fetchAll();

// Scale reference for the trend bar chart (tallest bar = 100% of the chart height)
$trendMax = 0;
foreach ($trend as $row) {
    $trendMax = max($trendMax, (float)$row['billed'], (float)$row['collected']);
}
if ($trendMax <= 0) $trendMax = 1;

// --- Top delinquent accounts (outstanding balance across ALL unpaid/partial/overdue bills) ---
$delinquent = $pdo->query("
    SELECT c.id, c.account_number, c.first_name, c.last_name,
           COALESCE(SUM(b.balance),0) total_balance,
           SUM(CASE WHEN b.status = 'overdue' THEN 1 ELSE 0 END) overdue_bills,
           COUNT(*) unpaid_bills
    FROM billing b
    JOIN consumers c ON c.id = b.consumer_id
    WHERE b.status IN ('unpaid','partial','overdue')
    GROUP BY c.id, c.account_number, c.first_name, c.last_name
    ORDER BY total_balance DESC
    LIMIT 8
")->fetchAll();
$delinquentMax = 0;
foreach ($delinquent as $d) $delinquentMax = max($delinquentMax, (float)$d['total_balance']);
if ($delinquentMax <= 0) $delinquentMax = 1;
?>

<?php if ($backupIsStale || $readingsAreStale): ?>
<div class="alert alert-warning">
  <?php if ($backupIsStale): ?>
    <div<?= $readingsAreStale ? ' style="margin-bottom:6px;"' : '' ?>>
      💾 <strong><?= $lastBackupAt ? 'Backup reminder:' : "You haven't downloaded a backup yet." ?></strong>
      <?php if ($lastBackupAt): ?>
        Last backup was <?= h(time_ago($lastBackupAt)) ?>.
      <?php endif; ?>
      Since this system runs locally, a backup is your only copy if this computer has a problem.
      <a href="reports/export.php">Download a backup now →</a>
    </div>
  <?php endif; ?>
  <?php if ($readingsAreStale): ?>
    <div>
      🧮 <strong>No meter readings recorded in <?= h(time_ago($lastReadingAt)) ?>.</strong>
      If a billing cycle is due, head to <a href="readings/grid.php">Meter Readings</a> to catch up.
    </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<div class="stat-grid">
  <div class="stat-card teal">
    <div class="stat-icon">👤</div>
    <div class="stat-value"><?= number_format($totalConsumers) ?></div>
    <div class="stat-label">Total Consumers (<?= number_format($activeConsumers) ?> active)</div>
  </div>
  <div class="stat-card info">
    <div class="stat-icon">🧾</div>
    <div class="stat-value"><?= money($pdo, $billedThisMonth) ?></div>
    <div class="stat-label"><?= number_format($billsThisMonth) ?> bills generated — <?= billing_month_label($thisMonthStart) ?></div>
  </div>
  <div class="stat-card success">
    <div class="stat-icon">💰</div>
    <div class="stat-value"><?= money($pdo, $collectedThisMonth) ?></div>
    <div class="stat-label">Collected — <?= billing_month_label($thisMonthStart) ?></div>
  </div>
  <div class="stat-card warning">
    <div class="stat-icon">⏳</div>
    <div class="stat-value"><?= money($pdo, $totalOutstanding) ?></div>
    <div class="stat-label"><?= number_format($unpaidCount) ?> unpaid bill(s), <?= number_format($overdueCount) ?> overdue</div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <h2>Collection Trend — last 6 months</h2>
    <a href="reports/monthly_summary.php" class="btn btn-outline btn-sm">Full report →</a>
  </div>
  <?php if (empty($trend)): ?>
    <div class="empty-state"><div class="ico">📈</div>No billing data yet. Generate your first bills to see the trend here.</div>
  <?php else: ?>
  <div class="chart-trend">
    <?php foreach ($trend as $row):
        $billed = (float)$row['billed'];
        $collected = (float)$row['collected'];
        $rate = $billed > 0 ? ($collected / $billed) * 100 : 0;
        $billedPct = min(100, ($billed / $trendMax) * 100);
        $collectedPct = min(100, ($collected / $trendMax) * 100);
    ?>
    <div class="chart-trend-col" title="<?= h(billing_month_label($row['ym'] . '-01')) ?>: <?= money($pdo, $collected) ?> collected of <?= money($pdo, $billed) ?> billed (<?= number_format($rate, 1) ?>%)">
      <div class="chart-trend-bars">
        <div class="chart-trend-bar billed" style="height:<?= $billedPct ?>%;"></div>
        <div class="chart-trend-bar collected" style="height:<?= $collectedPct ?>%;"></div>
      </div>
      <div class="chart-trend-rate"><?= number_format($rate, 0) ?>%</div>
      <div class="chart-trend-label"><?= h(date('M \'y', strtotime($row['ym'] . '-01'))) ?></div>
    </div>
    <?php endforeach; ?>
  </div>
  <div class="chart-legend">
    <div class="chart-legend-item"><span class="chart-legend-swatch billed"></span> Total Billed</div>
    <div class="chart-legend-item"><span class="chart-legend-swatch collected"></span> Total Collected</div>
  </div>
  <div class="table-wrap" style="margin-top:18px;">
    <table class="data-table">
      <thead><tr><th>Month</th><th class="num">Total Billed</th><th class="num">Total Collected</th><th class="num">Collection Rate</th></tr></thead>
      <tbody>
        <?php foreach ($trend as $row):
            $rate = $row['billed'] > 0 ? ($row['collected'] / $row['billed']) * 100 : 0; ?>
        <tr>
          <td><?= h(billing_month_label($row['ym'] . '-01')) ?></td>
          <td class="num"><?= money($pdo, $row['billed']) ?></td>
          <td class="num"><?= money($pdo, $row['collected']) ?></td>
          <td class="num"><?= number_format($rate, 1) ?>%</td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-header">
    <h2>Top Delinquent Accounts</h2>
    <a href="billing/list.php?status=overdue" class="btn btn-outline btn-sm">View overdue bills →</a>
  </div>
  <?php if (empty($delinquent)): ?>
    <div class="empty-state"><div class="ico">🎉</div>No outstanding balances right now — every generated bill is paid up.</div>
  <?php else: ?>
  <div class="delinquent-list">
    <?php foreach ($delinquent as $i => $d):
        $pct = min(100, ((float)$d['total_balance'] / $delinquentMax) * 100);
    ?>
    <div class="delinquent-row">
      <div class="delinquent-rank"><?= $i + 1 ?></div>
      <div class="delinquent-main">
        <div class="delinquent-name"><?= h($d['last_name'] . ', ' . $d['first_name']) ?> <span class="text-muted">(<?= h($d['account_number']) ?>)</span></div>
        <div class="delinquent-meta">
          <?= (int)$d['unpaid_bills'] ?> unpaid bill<?= $d['unpaid_bills'] == 1 ? '' : 's' ?><?php if ($d['overdue_bills'] > 0): ?>, <?= (int)$d['overdue_bills'] ?> overdue<?php endif; ?>
        </div>
        <div class="delinquent-track"><div class="delinquent-fill" style="width:<?= $pct ?>%;"></div></div>
      </div>
      <div class="delinquent-amount"><?= money($pdo, $d['total_balance']) ?></div>
    </div>
    <?php endforeach; ?>
  </div>
  <div class="hint" style="margin-top:12px;">Ranked by total outstanding balance across all unpaid, partial and overdue bills — not just this month.</div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-header">
    <h2>Recent Bills</h2>
    <a href="billing/list.php" class="btn btn-outline btn-sm">View all →</a>
  </div>
  <?php if (empty($recentBills)): ?>
    <div class="empty-state"><div class="ico">🧾</div>No bills generated yet. Go to <strong>Billing</strong> to generate this month's bills from recorded readings.</div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Bill #</th><th>Consumer</th><th>Period</th><th class="num">Amount</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($recentBills as $b): ?>
        <tr>
          <td><?= h($b['bill_number']) ?></td>
          <td><?= h($b['last_name'] . ', ' . $b['first_name']) ?> <span class="text-muted">(<?= h($b['account_number']) ?>)</span></td>
          <td><?= billing_month_label($b['billing_period']) ?></td>
          <td class="num"><?= money($pdo, $b['total_amount']) ?></td>
          <td><?= status_badge($b['status']) ?></td>
          <td class="row-actions"><a href="billing/view.php?id=<?= $b['id'] ?>" class="btn btn-outline btn-sm">View</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
