<?php
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    set_flash('error', 'Invalid request method.');
    redirect('list.php');
}
require_csrf();

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM readings WHERE id = :id");
$stmt->execute(['id' => $id]);
$reading = $stmt->fetch();

if (!$reading) {
    set_flash('error', 'Reading not found.');
    redirect('list.php');
}

$hasBill = $pdo->prepare("SELECT COUNT(*) FROM billing WHERE reading_id = :id");
$hasBill->execute(['id' => $id]);

if ((int)$hasBill->fetchColumn() > 0) {
    set_flash('error', 'This reading cannot be deleted because a bill has already been generated from it. Delete the related bill first.');
} else {
    $del = $pdo->prepare("DELETE FROM readings WHERE id = :id");
    $del->execute(['id' => $id]);
    set_flash('success', 'Reading deleted.');
}

redirect('list.php?period=' . date('Y-m', strtotime($reading['reading_period'])));
