<?php
$period = $_GET['period'] ?? date('Y-m');

$pageTitle = 'Meter Readings — Detail List';
$pageSub   = 'Review or edit individual readings one at a time';
$activeNav = 'readings';
$backUrl   = 'grid.php?period=' . urlencode($period);
$backLabel = 'Back to Bulk Entry Grid';
require_once __DIR__ . '/../includes/header.php';

$search = trim($_GET['q'] ?? '');

$where  = ["r.reading_period = :period"];
$params = ['period' => $period . '-01'];

if ($search !== '') {
    $where[] = "(c.first_name LIKE :s1 OR c.last_name LIKE :s2 OR c.account_number LIKE :s3)";
    $params['s1'] = "%$search%";
    $params['s2'] = "%$search%";
    $params['s3'] = "%$search%";
}

$whereSql = " WHERE " . implode(' AND ', $where);

$countSql = "
    SELECT COUNT(*)
    FROM readings r
    JOIN consumers c ON c.id = r.consumer_id
    LEFT JOIN meter_readers mr ON mr.id = r.meter_reader_id
" . $whereSql;
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$pager = paginate((int)$countStmt->fetchColumn(), 25);

$sql = "
    SELECT r.*, c.first_name, c.last_name, c.account_number, mr.name AS reader_name
    FROM readings r
    JOIN consumers c ON c.id = r.consumer_id
    LEFT JOIN meter_readers mr ON mr.id = r.meter_reader_id
" . $whereSql . "
    ORDER BY c.last_name, c.first_name
    LIMIT :limit OFFSET :offset
";
$stmt = $pdo->prepare($sql);
foreach ($params as $k => $v) $stmt->bindValue($k, $v);
$stmt->bindValue('limit', $pager['perPage'], PDO::PARAM_INT);
$stmt->bindValue('offset', $pager['offset'], PDO::PARAM_INT);
$stmt->execute();
$readings = $stmt->fetchAll();

// Consumers still missing a reading this period (active-like statuses only)
$activeStatuses = active_like_statuses();
$activePlaceholders = implode(',', array_fill(0, count($activeStatuses), '?'));
$stmt2 = $pdo->prepare("
    SELECT c.id, c.account_number, c.first_name, c.last_name
    FROM consumers c
    WHERE c.status IN ($activePlaceholders)
      AND c.id NOT IN (
          SELECT consumer_id FROM readings WHERE reading_period = ?
      )
    ORDER BY c.last_name, c.first_name
");
$stmt2->execute([...$activeStatuses, $period . '-01']);
$missing = $stmt2->fetchAll();
?>

<div class="card">
  <div class="card-header">
    <h2>Readings for Billing Month: <?= h(billing_month_label($period . '-01')) ?> <span class="text-muted">(readings <?= h(reading_range_hint($period . '-01')) ?>)</span> <span class="text-muted">— <?= number_format($pager['totalRows']) ?> total</span></h2>
    <div class="actions">
      <a href="grid.php?period=<?= h($period) ?>" class="btn btn-navy">🧮 Bulk Entry Grid</a>
      <a href="add.php?period=<?= h($period) ?>" class="btn btn-primary">+ Add Single Reading</a>
    </div>
  </div>

  <form method="get" class="form-row" style="margin-bottom:18px;">
    <div class="form-group mb-0">
      <label>Billing Month</label>
      <?= billing_month_select('period', $period, 'onchange="this.form.submit()"') ?>
    </div>
    <div class="form-group mb-0">
      <label>Search Consumer</label>
      <input type="text" name="q" value="<?= h($search) ?>" placeholder="Name or account #">
    </div>
    <div class="form-group mb-0" style="align-self:end;">
      <button class="btn btn-outline" type="submit">Filter</button>
    </div>
  </form>

  <?php if ($pager['totalRows'] > 10): ?>
  <div style="display:flex; justify-content:flex-end; margin-bottom:12px;">
    <?= per_page_select() ?>
  </div>
  <?php endif; ?>

  <?php if (empty($readings)): ?>
    <div class="empty-state"><div class="ico">🧮</div>No readings recorded yet for this month.</div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Account #</th><th>Consumer</th><th class="num">Previous</th><th class="num">Current</th><th class="num">Consumption</th><th>Reading Date</th><th>Meter Reader</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($readings as $r): ?>
        <tr>
          <td><?= h($r['account_number']) ?></td>
          <td><?= h($r['last_name'] . ', ' . $r['first_name']) ?></td>
          <td class="num"><?= number_format($r['previous_reading'], 2) ?></td>
          <td class="num"><?= number_format($r['current_reading'], 2) ?></td>
          <td class="num"><?= number_format($r['consumption'], 2) ?> m³</td>
          <td><?= format_date($r['reading_date']) ?></td>
          <td><?= h($r['reader_name'] ?: '—') ?></td>
          <td class="row-actions">
            <a href="edit.php?id=<?= $r['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
            <a href="delete.php?id=<?= $r['id'] ?>" class="btn btn-danger btn-sm" data-post
               data-confirm="Delete this reading? This is only possible if no bill has been generated from it yet.">Delete</a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= pagination_links($pager) ?>
  <?php endif; ?>
</div>

<?php if (!empty($missing)): ?>
<div class="card">
  <div class="card-header"><h2>Active Consumers Without a Reading This Month <span class="text-muted">(<?= count($missing) ?>)</span></h2></div>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Account #</th><th>Consumer</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($missing as $m): ?>
        <tr>
          <td><?= h($m['account_number']) ?></td>
          <td><?= h($m['last_name'] . ', ' . $m['first_name']) ?></td>
          <td><a href="add.php?consumer_id=<?= $m['id'] ?>&period=<?= h($period) ?>" class="btn btn-outline btn-sm">Add Reading</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
