<?php
$period = $_GET['period'] ?? date('Y-m');
$preselectedConsumer = (int)($_GET['consumer_id'] ?? 0);

$pageTitle = 'Add Meter Reading';
$pageSub   = 'Record this month\'s meter reading for a consumer';
$activeNav = 'readings';
if ($preselectedConsumer) {
    $backUrl   = '../consumers/view.php?id=' . $preselectedConsumer;
    $backLabel = 'Back to Consumer';
} else {
    $backUrl   = 'list.php?period=' . urlencode($period);
    $backLabel = 'Back to Readings';
}
require_once __DIR__ . '/../includes/header.php';

$activeStatuses = active_like_statuses();
$activePlaceholders = implode(',', array_fill(0, count($activeStatuses), '?'));
$stmtConsumers = $pdo->prepare("SELECT id, account_number, first_name, last_name, meter_initial_reading FROM consumers WHERE status IN ($activePlaceholders) ORDER BY last_name, first_name");
$stmtConsumers->execute($activeStatuses);
$consumers = $stmtConsumers->fetchAll();
$meterReaders = get_meter_readers($pdo);

$errors = [];
$data = [
    'consumer_id' => $preselectedConsumer,
    'reading_period' => $period,
    'previous_reading' => '',
    'current_reading' => '',
    'reading_date' => date('Y-m-d'),
    'meter_reader_id' => '',
    'recorded_by' => $_SESSION['admin_name'] ?? '',
    'remarks' => '',
];

/** Work out the correct previous reading for a consumer + period */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $data['consumer_id']      = (int)($_POST['consumer_id'] ?? 0);
    $data['reading_period']   = $_POST['reading_period'] ?? $period;
    $data['previous_reading'] = trim($_POST['previous_reading'] ?? '');
    $data['current_reading']  = trim($_POST['current_reading'] ?? '');
    $data['reading_date']     = $_POST['reading_date'] ?? date('Y-m-d');
    $data['meter_reader_id']  = $_POST['meter_reader_id'] ?? '';
    $data['recorded_by']      = trim($_POST['recorded_by'] ?? '');
    $data['remarks']          = trim($_POST['remarks'] ?? '');

    if (!$data['consumer_id']) $errors[] = 'Please select a consumer.';
    if ($data['previous_reading'] === '') $errors[] = 'Previous reading is required.';
    if ($data['current_reading'] === '') $errors[] = 'Current reading is required.';
    if (is_numeric($data['previous_reading']) && is_numeric($data['current_reading'])
        && (float)$data['current_reading'] < (float)$data['previous_reading']) {
        $errors[] = 'Current reading cannot be lower than the previous reading.';
    }

    $periodDate = date('Y-m-01', strtotime($data['reading_period'] . '-01'));

    if (!$errors) {
        $chk = $pdo->prepare("SELECT COUNT(*) FROM readings WHERE consumer_id = :cid AND reading_period = :period");
        $chk->execute(['cid' => $data['consumer_id'], 'period' => $periodDate]);
        if ($chk->fetchColumn() > 0) {
            $errors[] = 'A reading already exists for this consumer for Billing Month ' . billing_month_label($periodDate) . '. Please edit that reading instead.';
        }
    }

    if (!$errors) {
        $stmt = $pdo->prepare("
            INSERT INTO readings (consumer_id, reading_period, previous_reading, current_reading, reading_date, meter_reader_id, recorded_by, remarks)
            VALUES (:consumer_id, :reading_period, :previous_reading, :current_reading, :reading_date, :meter_reader_id, :recorded_by, :remarks)
        ");
        $stmt->execute([
            'consumer_id' => $data['consumer_id'],
            'reading_period' => $periodDate,
            'previous_reading' => $data['previous_reading'],
            'current_reading' => $data['current_reading'],
            'reading_date' => $data['reading_date'],
            'meter_reader_id' => $data['meter_reader_id'] ?: null,
            'recorded_by' => $data['recorded_by'],
            'remarks' => $data['remarks'],
        ]);
        set_flash('success', 'Reading recorded successfully.');
        redirect('list.php?period=' . date('Y-m', strtotime($periodDate)));
    }
} elseif ($preselectedConsumer) {
    $data['previous_reading'] = get_previous_reading($pdo, $preselectedConsumer, date('Y-m-01', strtotime($period . '-01')));
}
?>

<div class="card" style="max-width:720px;">
  <div class="card-header"><h2>Reading Details</h2></div>

  <?php if ($errors): ?>
    <div class="alert alert-danger"><?= implode('<br>', array_map('h', $errors)) ?></div>
  <?php endif; ?>

  <form method="post" novalidate>
    <?= csrf_field() ?>
    <div class="form-row">
      <div class="form-group">
        <label class="required">Consumer</label>
        <select name="consumer_id" id="consumerSelect" required onchange="location.href='add.php?consumer_id='+this.value+'&period=<?= h($data['reading_period']) ?>'">
          <option value="">— Select consumer —</option>
          <?php foreach ($consumers as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $data['consumer_id'] == $c['id'] ? 'selected' : '' ?>>
              <?= h($c['account_number'] . ' — ' . $c['last_name'] . ', ' . $c['first_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
        <div class="hint">Only active consumers are listed. Selecting a consumer auto-fills the previous reading.</div>
      </div>
      <div class="form-group">
        <label class="required">Billing Month</label>
        <?= billing_month_select('reading_period', $data['reading_period'], 'required onchange="location.href=\'add.php?consumer_id=\'+document.getElementById(\'consumerSelect\').value+\'&period=\'+this.value"', 24, 30) ?>
        <div class="hint">Click to pick the month. Readings for a Billing Month compare last month's reading to the new one taken this month — changing this reloads the correct previous reading.</div>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="required">Previous Reading (m³)</label>
        <input type="number" step="0.01" id="previous_reading" name="previous_reading" value="<?= h($data['previous_reading']) ?>" required>
      </div>
      <div class="form-group">
        <label class="required">Current Reading (m³)</label>
        <input type="number" step="0.01" id="current_reading" name="current_reading" value="<?= h($data['current_reading']) ?>" required>
      </div>
      <div class="form-group">
        <label>Consumption</label>
        <div id="consumptionPreview" style="padding:9px 11px; border:1px solid var(--border); border-radius:6px; background:#f6f8f9; font-weight:700;">—</div>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="required">Reading Date</label>
        <input type="date" name="reading_date" value="<?= h($data['reading_date']) ?>" required>
      </div>
      <div class="form-group">
        <label>Meter Reader</label>
        <select name="meter_reader_id">
          <option value="">— Not specified —</option>
          <?php foreach ($meterReaders as $mr): ?>
            <option value="<?= $mr['id'] ?>" <?= (string)$data['meter_reader_id'] === (string)$mr['id'] ? 'selected' : '' ?>><?= h($mr['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <div class="hint">Manage the list in Settings → Meter Readers.</div>
      </div>
    </div>

    <div class="form-group">
      <label>Remarks</label>
      <textarea name="remarks" rows="2" placeholder="e.g. meter tampered, estimated reading, etc."><?= h($data['remarks']) ?></textarea>
    </div>

    <div class="row-actions">
      <button type="submit" class="btn btn-primary">Save Reading</button>
      <a href="list.php" class="btn btn-outline">Cancel</a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
