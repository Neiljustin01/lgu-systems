<?php
$pageTitle = 'Edit Meter Reading';
$activeNav = 'readings';
$backUrl   = 'list.php';
$backLabel = 'Back to Readings';
require_once __DIR__ . '/../includes/header.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("
    SELECT r.*, c.account_number, c.first_name, c.last_name
    FROM readings r JOIN consumers c ON c.id = r.consumer_id
    WHERE r.id = :id
");
$stmt->execute(['id' => $id]);
$reading = $stmt->fetch();

if (!$reading) {
    set_flash('error', 'Reading not found.');
    redirect('list.php');
}
$pageSub = $reading['account_number'] . ' — ' . $reading['last_name'] . ', ' . $reading['first_name'];

$hasBill = $pdo->prepare("SELECT COUNT(*) FROM billing WHERE reading_id = :id");
$hasBill->execute(['id' => $id]);
$hasBill = (int)$hasBill->fetchColumn() > 0;

$errors = [];
$data = $reading;
$meterReaders = get_meter_readers($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $data['previous_reading'] = trim($_POST['previous_reading'] ?? '');
    $data['current_reading']  = trim($_POST['current_reading'] ?? '');
    $data['reading_date']     = $_POST['reading_date'] ?? date('Y-m-d');
    $data['meter_reader_id']  = $_POST['meter_reader_id'] ?? '';
    $data['recorded_by']      = trim($_POST['recorded_by'] ?? '');
    $data['remarks']          = trim($_POST['remarks'] ?? '');

    if ($data['previous_reading'] === '') $errors[] = 'Previous reading is required.';
    if ($data['current_reading'] === '') $errors[] = 'Current reading is required.';
    if (is_numeric($data['previous_reading']) && is_numeric($data['current_reading'])
        && (float)$data['current_reading'] < (float)$data['previous_reading']) {
        $errors[] = 'Current reading cannot be lower than the previous reading.';
    }

    // A bill already generated from this reading stores its own frozen
    // copy of previous/current reading and consumption. Letting those
    // numbers change here without touching the bill would silently
    // desync the two (the bill's amount would no longer match what the
    // meter actually shows) — so, same rule as clearing a reading on the
    // grid, changing the readings themselves is blocked once a bill
    // exists. Delete the bill first (Billing → the bill → Delete) if the
    // numbers genuinely need to change.
    if ($hasBill && !$errors
        && ((float)$data['previous_reading'] !== (float)$reading['previous_reading']
            || (float)$data['current_reading'] !== (float)$reading['current_reading'])) {
        $errors[] = 'A bill has already been generated from this reading, so the Previous/Current Reading values can\'t be changed here. Delete the bill first (Billing → open the bill → Delete), then edit the reading and regenerate the bill.';
    }

    if (!$errors) {
        $stmt = $pdo->prepare("
            UPDATE readings SET previous_reading = :previous_reading, current_reading = :current_reading,
                   reading_date = :reading_date, meter_reader_id = :meter_reader_id,
                   recorded_by = :recorded_by, remarks = :remarks
            WHERE id = :id
        ");
        $stmt->execute([
            'previous_reading' => $data['previous_reading'],
            'current_reading' => $data['current_reading'],
            'reading_date' => $data['reading_date'],
            'meter_reader_id' => $data['meter_reader_id'] ?: null,
            'recorded_by' => $data['recorded_by'],
            'remarks' => $data['remarks'],
            'id' => $id,
        ]);
        set_flash('success', 'Reading updated successfully.');
        redirect('list.php?period=' . date('Y-m', strtotime($reading['reading_period'])));
    }
}
?>

<div class="card" style="max-width:680px;">
  <div class="card-header"><h2>Reading Details — Billing Month: <?= billing_month_label($reading['reading_period']) ?></h2></div>

  <?php if ($hasBill): ?>
    <div class="alert alert-info">A bill has already been generated from this reading, so Previous/Current Reading are locked below. To change them, delete the bill first (Billing → open the bill → Delete), then edit the reading and regenerate the bill. Reading Date, Meter Reader, and Remarks can still be edited freely.</div>
  <?php endif; ?>

  <?php if ($errors): ?>
    <div class="alert alert-danger"><?= implode('<br>', array_map('h', $errors)) ?></div>
  <?php endif; ?>

  <form method="post" novalidate>
    <?= csrf_field() ?>
    <div class="form-row">
      <div class="form-group">
        <label class="required">Previous Reading (m³)</label>
        <input type="number" step="0.01" id="previous_reading" name="previous_reading" value="<?= h($data['previous_reading']) ?>" required <?= $hasBill ? 'readonly' : '' ?>>
        <?php if ($hasBill): ?><div class="hint">Locked — a bill already exists for this reading.</div><?php endif; ?>
      </div>
      <div class="form-group">
        <label class="required">Current Reading (m³)</label>
        <input type="number" step="0.01" id="current_reading" name="current_reading" value="<?= h($data['current_reading']) ?>" required <?= $hasBill ? 'readonly' : '' ?>>
        <?php if ($hasBill): ?><div class="hint">Locked — a bill already exists for this reading.</div><?php endif; ?>
      </div>
      <div class="form-group">
        <label>Consumption</label>
        <div id="consumptionPreview" style="padding:9px 11px; border:1px solid var(--border); border-radius:6px; background:#f6f8f9; font-weight:700;">
          <?= number_format($data['current_reading'] - $data['previous_reading'], 2) ?> m³
        </div>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="required">Reading Date</label>
        <input type="date" name="reading_date" value="<?= h($data['reading_date']) ?>" required>
      </div>
      <div class="form-group">
        <label>Meter Reader</label>
        <select name="meter_reader_id">
          <option value="">— Not specified —</option>
          <?php foreach ($meterReaders as $mr): ?>
            <option value="<?= $mr['id'] ?>" <?= (string)($data['meter_reader_id'] ?? '') === (string)$mr['id'] ? 'selected' : '' ?>><?= h($mr['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <div class="form-group">
      <label>Remarks</label>
      <textarea name="remarks" rows="2"><?= h($data['remarks']) ?></textarea>
    </div>

    <div class="row-actions">
      <button type="submit" class="btn btn-primary">Update Reading</button>
      <a href="list.php" class="btn btn-outline">Cancel</a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
