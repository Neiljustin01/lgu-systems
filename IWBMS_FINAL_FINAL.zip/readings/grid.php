<?php
$pageTitle = 'Meter Readings';
$pageSub   = 'Encode all consumers\' readings for a billing period in one sheet';
$activeNav = 'readings';
require_once __DIR__ . '/../includes/header.php';

$period = $_GET['period'] ?? date('Y-m');
$periodDate = date('Y-m-01', strtotime($period . '-01'));
$search = trim($_GET['q'] ?? '');
$showAll = isset($_GET['show_all']);
$readerFilter = $_GET['reader'] ?? '';
// Default sort: when narrowed to one reader, follow their route order
// (matches the old printed sheet exactly); otherwise sort by name.
$defaultSort = ($readerFilter !== '' && $readerFilter !== 'none') ? 'route' : 'name';
$sort = $_GET['sort'] ?? $defaultSort;
$dir  = ($_GET['dir'] ?? 'asc') === 'desc' ? 'desc' : 'asc';

$meterReaders = get_meter_readers($pdo);
$saveErrors = [];
$savedCount = 0;

// ---------------------------------------------------------------------
// Handle bulk save
// ---------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $postPeriod = $_POST['period'] ?? $period;
    $postPeriodDate = date('Y-m-01', strtotime($postPeriod . '-01'));
    $readingDate = $_POST['reading_date'] ?? date('Y-m-d');
    $meterReaderId = $_POST['meter_reader_id'] ?: null;
    $presentValues = $_POST['present'] ?? [];
    $existingReadingIds = $_POST['existing_reading_id'] ?? [];
    $clearedCount = 0;

    // Wrap the whole batch save in one transaction so a mid-batch problem
    // (dropped DB connection, disk full, etc.) never leaves the grid
    // half-saved — either the whole batch commits, or none of it does.
    $pdo->beginTransaction();
    try {
    foreach ($presentValues as $consumerId => $present) {
        $consumerId = (int)$consumerId;
        $present = trim($present);
        $existingReadingId = (int)($existingReadingIds[$consumerId] ?? 0);

        if ($present === '') {
            // Nothing was ever saved for this row this period — a normal
            // blank/not-yet-read row. Nothing to do.
            if (!$existingReadingId) continue;

            // The field had a saved reading and the user cleared it on
            // purpose — actually remove it, unless a bill already exists
            // for it (same rule as the single-row Delete Reading action).
            $hasBill = $pdo->prepare("SELECT COUNT(*) FROM billing WHERE reading_id = :id");
            $hasBill->execute(['id' => $existingReadingId]);
            if ((int)$hasBill->fetchColumn() > 0) {
                $nameStmt = $pdo->prepare("SELECT CONCAT(last_name, ', ', first_name) FROM consumers WHERE id = :id");
                $nameStmt->execute(['id' => $consumerId]);
                $name = $nameStmt->fetchColumn() ?: "Consumer #$consumerId";
                $saveErrors[] = "$name: can't clear this reading because a bill has already been generated from it — delete the bill first.";
                continue;
            }

            $pdo->prepare("DELETE FROM readings WHERE id = :id")->execute(['id' => $existingReadingId]);
            $clearedCount++;
            continue;
        }

        if (!is_numeric($present)) {
            $saveErrors[] = "Consumer #$consumerId: present reading must be a number.";
            continue;
        }

        // Recompute previous reading server-side (never trust client for this)
        $previous = get_previous_reading($pdo, $consumerId, $postPeriodDate);

        if ((float)$present < $previous) {
            $nameStmt = $pdo->prepare("SELECT CONCAT(last_name, ', ', first_name) FROM consumers WHERE id = :id");
            $nameStmt->execute(['id' => $consumerId]);
            $name = $nameStmt->fetchColumn() ?: "Consumer #$consumerId";
            $saveErrors[] = "$name: present reading ($present) cannot be lower than previous ($previous) — skipped.";
            continue;
        }

        // If this row already has a saved reading AND a bill has already
        // been generated from it, don't let a resave through this grid
        // silently change the number the bill was calculated from — same
        // rule as clearing a reading above. Only block it if the value is
        // actually changing (re-saving the same number, e.g. from a
        // full-grid resubmit, is harmless).
        if ($existingReadingId) {
            $hasBill = $pdo->prepare("SELECT COUNT(*) FROM billing WHERE reading_id = :id");
            $hasBill->execute(['id' => $existingReadingId]);
            if ((int)$hasBill->fetchColumn() > 0) {
                $existing = $pdo->prepare("SELECT current_reading FROM readings WHERE id = :id");
                $existing->execute(['id' => $existingReadingId]);
                $existingCurrent = (float)$existing->fetchColumn();
                if ($existingCurrent !== (float)$present) {
                    $nameStmt = $pdo->prepare("SELECT CONCAT(last_name, ', ', first_name) FROM consumers WHERE id = :id");
                    $nameStmt->execute(['id' => $consumerId]);
                    $name = $nameStmt->fetchColumn() ?: "Consumer #$consumerId";
                    $saveErrors[] = "$name: can't change this reading because a bill has already been generated from it — delete the bill first, then edit the reading.";
                    continue;
                }
            }
        }

        $stmt = $pdo->prepare("
            INSERT INTO readings (consumer_id, reading_period, previous_reading, current_reading, reading_date, meter_reader_id)
            VALUES (:consumer_id, :period, :previous, :present, :reading_date, :reader)
            ON DUPLICATE KEY UPDATE
                previous_reading = VALUES(previous_reading),
                current_reading  = VALUES(current_reading),
                reading_date     = VALUES(reading_date),
                meter_reader_id  = VALUES(meter_reader_id)
        ");
        $stmt->execute([
            'consumer_id' => $consumerId,
            'period' => $postPeriodDate,
            'previous' => $previous,
            'present' => $present,
            'reading_date' => $readingDate,
            'reader' => $meterReaderId,
        ]);
        $savedCount++;
    }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        log_system_error('Reading grid save failed: ' . $e->getMessage());
        set_flash('error', 'Something went wrong while saving this batch, so nothing was changed. Please try again.');
        redirect('grid.php?' . http_build_query(['period' => $postPeriod, 'q' => $search, 'sort' => $sort, 'dir' => $dir, 'reader' => $readerFilter]));
    }

    if ($savedCount > 0 || $clearedCount > 0) {
        $parts = [];
        if ($savedCount > 0) $parts[] = "$savedCount reading(s) saved";
        if ($clearedCount > 0) $parts[] = "$clearedCount reading(s) cleared";
        set_flash($saveErrors ? 'info' : 'success',
            implode(' and ', $parts) . ' for Billing Month ' . billing_month_label($postPeriodDate) . '.'
            . ($saveErrors ? ' Some rows were skipped — see details below.' : ''));
    } elseif (!$saveErrors) {
        set_flash('info', 'No changes were made.');
    }

    if (!$saveErrors) {
        redirect('grid.php?' . http_build_query(['period' => $postPeriod, 'q' => $search, 'sort' => $sort, 'dir' => $dir, 'reader' => $readerFilter]));
    }
    // If there were errors, fall through and re-render the page with the errors shown.
    $period = $postPeriod;
    $periodDate = $postPeriodDate;
}

// ---------------------------------------------------------------------
// Build the consumer + reading grid query
// ---------------------------------------------------------------------
$activeStatuses = active_like_statuses();
$activeStatusList = "'" . implode("','", array_map(fn($s) => str_replace("'", "''", $s), $activeStatuses)) . "'";
$where = $showAll ? "1=1" : "c.status IN ($activeStatusList)";
$params = ['period1' => $periodDate, 'period2' => $periodDate];

if ($search !== '') {
    $where .= " AND (c.first_name LIKE :s1 OR c.last_name LIKE :s2 OR c.account_number LIKE :s3 OR c.meter_number LIKE :s4)";
    $params['s1'] = "%$search%";
    $params['s2'] = "%$search%";
    $params['s3'] = "%$search%";
    $params['s4'] = "%$search%";
}
if ($readerFilter !== '') {
    if ($readerFilter === 'none') {
        $where .= " AND c.default_meter_reader_id IS NULL";
    } else {
        $where .= " AND c.default_meter_reader_id = :reader";
        $params['reader'] = $readerFilter;
    }
}

$sortMap = [
    'name'        => 't.last_name, t.first_name',
    'meter'       => 't.meter_number',
    'address'     => 't.address, t.barangay, t.purok',
    'consumption' => 't.consumption',
    'route'       => 't.route_sequence IS NULL, t.route_sequence, t.last_name, t.first_name',
];
$orderBy = $sortMap[$sort] ?? $sortMap['name'];

$sql = "
    SELECT t.*, (CASE WHEN t.present_reading IS NOT NULL THEN t.present_reading - t.previous_reading ELSE NULL END) AS consumption
    FROM (
        SELECT c.id AS consumer_id, c.account_number, c.first_name, c.last_name, c.meter_number,
               c.purok, c.barangay, c.address, c.status, c.route_sequence, c.default_meter_reader_id,
               mr.name AS reader_name,
               r.id AS reading_id, r.current_reading AS present_reading, r.meter_reader_id, r.reading_date,
               COALESCE(
                   (SELECT pr.current_reading FROM readings pr
                    WHERE pr.consumer_id = c.id AND pr.reading_period < :period1
                    ORDER BY pr.reading_period DESC LIMIT 1),
                   c.meter_initial_reading
               ) AS previous_reading
        FROM consumers c
        LEFT JOIN readings r ON r.consumer_id = c.id AND r.reading_period = :period2
        LEFT JOIN meter_readers mr ON mr.id = c.default_meter_reader_id
        WHERE $where
    ) t
    ORDER BY $orderBy $dir
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$readCount = 0;
foreach ($rows as $r) if ($r['present_reading'] !== null) $readCount++;

// If narrowing to one reader, default the "meter reader for this batch"
// dropdown to the same reader — one less click for the admin.
$defaultBatchReader = ($readerFilter !== '' && $readerFilter !== 'none') ? $readerFilter : '';

function sort_link($key, $label, $sort, $dir, $period, $search, $showAll, $readerFilter) {
    $nextDir = ($sort === $key && $dir === 'asc') ? 'desc' : 'asc';
    $arrow = $sort === $key ? ($dir === 'asc' ? ' ▲' : ' ▼') : '';
    $qs = http_build_query(['period' => $period, 'q' => $search, 'sort' => $key, 'dir' => $nextDir, 'reader' => $readerFilter] + ($showAll ? ['show_all' => 1] : []));
    return '<a href="grid.php?' . $qs . '" style="color:inherit;">' . h($label) . $arrow . '</a>';
}
?>

<div class="card">
  <form method="get" class="form-row">
    <div class="form-group mb-0">
      <label>Billing Month</label>
      <?= billing_month_select('period', $period, 'onchange="this.form.submit()"') ?>
      <div class="hint">Click to pick the month you're viewing or editing. Previous reading auto-fills from the prior month. New/future months start at 0 until read.</div>
    </div>
    <div class="form-group mb-0">
      <label>Meter Reader</label>
      <select name="reader" onchange="this.form.submit()">
        <option value="">All readers</option>
        <option value="none" <?= $readerFilter === 'none' ? 'selected' : '' ?>>— Not yet assigned —</option>
        <?php foreach ($meterReaders as $mr): ?>
          <option value="<?= $mr['id'] ?>" <?= (string)$readerFilter === (string)$mr['id'] ? 'selected' : '' ?>><?= h($mr['name']) ?></option>
        <?php endforeach; ?>
      </select>
      <div class="hint">Narrows the list to one reader's route, sorted by their route order.</div>
    </div>
    <div class="form-group mb-0">
      <label>Search</label>
      <input type="text" name="q" value="<?= h($search) ?>" placeholder="Name, account #, or meter #">
    </div>
    <div class="form-group mb-0" style="align-self:end;">
      <label style="font-weight:400; display:flex; align-items:center; gap:6px;">
        <input type="checkbox" name="show_all" value="1" <?= $showAll ? 'checked' : '' ?> style="width:auto;"> Show inactive/disconnected too
      </label>
    </div>
    <input type="hidden" name="sort" value="<?= h($sort) ?>">
    <input type="hidden" name="dir" value="<?= h($dir) ?>">
    <div class="form-group mb-0" style="align-self:end;">
      <button class="btn btn-outline" type="submit">Apply</button>
      <a href="grid_print.php?<?= http_build_query(['period' => $period, 'q' => $search, 'reader' => $readerFilter] + ($showAll ? ['show_all' => 1] : [])) ?>" class="btn btn-navy" target="print_preview">🖨️ Print</a>
      <a href="list.php?period=<?= h($period) ?>" class="btn btn-outline">View as List</a>
    </div>
  </form>
</div>

<?php if ($saveErrors): ?>
  <div class="alert alert-danger">
    <strong>Some rows were not saved:</strong><br>
    <?= implode('<br>', array_map('h', $saveErrors)) ?>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-header">
    <h2>Billing Month: <?= h(billing_month_label($periodDate)) ?> <span class="text-muted">(readings <?= h(reading_range_hint($periodDate)) ?>) — <?= count($rows) ?> consumer(s), <?= $readCount ?> already read</span></h2>
  </div>

  <?php if (empty($rows)): ?>
    <div class="empty-state"><div class="ico">🧮</div>No consumers match your filters.</div>
  <?php else: ?>
  <form method="post" id="gridForm">
    <?= csrf_field() ?>
    <input type="hidden" name="period" value="<?= h($period) ?>">

    <div class="form-row" style="margin-bottom:16px;">
      <div class="form-group mb-0">
        <label>Reading Date (applies to all rows saved now)</label>
        <input type="date" name="reading_date" value="<?= date('Y-m-d') ?>">
      </div>
      <div class="form-group mb-0">
        <label>Meter Reader (applies to all rows saved now)</label>
        <select name="meter_reader_id">
          <option value="">— Not specified —</option>
          <?php foreach ($meterReaders as $mr): ?>
            <option value="<?= $mr['id'] ?>" <?= (string)$defaultBatchReader === (string)$mr['id'] ? 'selected' : '' ?>><?= h($mr['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <div class="hint">Auto-matches the reader filter above. Manage the roster in Settings → Meter Readers.</div>
      </div>
    </div>

    <div class="table-wrap">
      <table class="data-table" id="readingsGrid">
        <thead>
          <tr>
            <th><?= sort_link('route', '#', $sort, $dir, $period, $search, $showAll, $readerFilter) ?></th>
            <th><?= sort_link('name', 'Consumer Name', $sort, $dir, $period, $search, $showAll, $readerFilter) ?></th>
            <th><?= sort_link('meter', 'Meter #', $sort, $dir, $period, $search, $showAll, $readerFilter) ?></th>
            <th><?= sort_link('address', 'Address', $sort, $dir, $period, $search, $showAll, $readerFilter) ?></th>
            <?php if ($readerFilter === ''): ?><th>Reader</th><?php endif; ?>
            <th class="num">Previous</th>
            <th class="num" style="min-width:130px;">Present</th>
            <th class="num"><?= sort_link('consumption', 'Cu.M. Used', $sort, $dir, $period, $search, $showAll, $readerFilter) ?></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
          <tr>
            <td class="text-muted"><?= $r['route_sequence'] !== null ? (int)$r['route_sequence'] : '—' ?></td>
            <td><?= h($r['last_name'] . ', ' . $r['first_name']) ?> <span class="text-muted">(<?= h($r['account_number']) ?>)</span></td>
            <td><?= h($r['meter_number'] ?: '—') ?></td>
            <td><?= h(format_consumer_address($r)) ?></td>
            <?php if ($readerFilter === ''): ?><td><?= h($r['reader_name'] ?: '—') ?></td><?php endif; ?>
            <td class="num"><?= number_format($r['previous_reading'], 2) ?></td>
            <td class="num">
              <input type="number" step="0.01" class="present-input"
                     name="present[<?= $r['consumer_id'] ?>]"
                     data-previous="<?= h($r['previous_reading']) ?>"
                     value="<?= $r['present_reading'] !== null ? h($r['present_reading']) : '' ?>"
                     placeholder="0.00">
              <input type="hidden" name="existing_reading_id[<?= $r['consumer_id'] ?>]" value="<?= $r['reading_id'] !== null ? (int)$r['reading_id'] : '' ?>">
            </td>
            <td class="num consumption-cell"><?= $r['consumption'] !== null ? number_format($r['consumption'], 2) . ' m³' : '—' ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="row-actions" style="margin-top:16px;">
      <button type="submit" class="btn btn-primary">💾 Save All Readings</button>
      <span class="hint">Type a value and press <strong>Enter</strong> to jump to the next row — no clicking needed. Rows left blank are simply skipped. Clearing a value that was already saved removes that reading (unless a bill was already generated from it).</span>
    </div>
  </form>
  <?php endif; ?>
</div>

<script>
(function () {
  var inputs = Array.prototype.slice.call(document.querySelectorAll('.present-input'));

  inputs.forEach(function (input, idx) {
    // Live consumption calculation as you type — same as before.
    input.addEventListener('input', function () {
      var row = input.closest('tr');
      var cell = row.querySelector('.consumption-cell');
      var prev = parseFloat(input.dataset.previous) || 0;
      var present = parseFloat(input.value);
      if (isNaN(present) || input.value === '') {
        cell.textContent = '—';
        return;
      }
      var diff = present - prev;
      cell.textContent = diff.toFixed(2) + ' m³';
      cell.style.color = diff < 0 ? '#c23b3b' : '';
    });

    // Excel-style navigation: Enter/ArrowDown moves to the next row's
    // present field, ArrowUp moves to the previous one. No mouse needed.
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === 'ArrowDown') {
        e.preventDefault();
        var next = inputs[idx + 1];
        if (next) { next.focus(); next.select(); }
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        var prevInput = inputs[idx - 1];
        if (prevInput) { prevInput.focus(); prevInput.select(); }
      }
    });
  });

  // Jump straight into the first empty row when the page loads, so
  // encoding can start immediately without clicking.
  var firstEmpty = inputs.find(function (i) { return i.value === ''; });
  if (firstEmpty) firstEmpty.focus();
})();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
