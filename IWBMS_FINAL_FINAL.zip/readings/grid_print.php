<?php
require_once __DIR__ . '/../includes/auth.php';

$period = $_GET['period'] ?? date('Y-m');
$periodDate = date('Y-m-01', strtotime($period . '-01'));
$search = trim($_GET['q'] ?? '');
$showAll = isset($_GET['show_all']);
$readerFilter = $_GET['reader'] ?? '';

$activeStatuses = active_like_statuses();
$activeStatusList = "'" . implode("','", array_map(fn($s) => str_replace("'", "''", $s), $activeStatuses)) . "'";
$where = $showAll ? "1=1" : "c.status IN ($activeStatusList)";
$params = ['period1' => $periodDate, 'period2' => $periodDate];

if ($search !== '') {
    $where .= " AND (c.first_name LIKE :s1 OR c.last_name LIKE :s2 OR c.account_number LIKE :s3 OR c.meter_number LIKE :s4)";
    $params['s1'] = "%$search%";
    $params['s2'] = "%$search%";
    $params['s3'] = "%$search%";
    $params['s4'] = "%$search%";
}
if ($readerFilter !== '') {
    if ($readerFilter === 'none') {
        $where .= " AND c.default_meter_reader_id IS NULL";
    } else {
        $where .= " AND c.default_meter_reader_id = :reader";
        $params['reader'] = $readerFilter;
    }
}

$orderBy = ($readerFilter !== '' && $readerFilter !== 'none')
    ? "t.route_sequence IS NULL, t.route_sequence, t.last_name, t.first_name"
    : "t.last_name, t.first_name";

$sql = "
    SELECT t.*, (CASE WHEN t.present_reading IS NOT NULL THEN t.present_reading - t.previous_reading ELSE NULL END) AS consumption
    FROM (
        SELECT c.id AS consumer_id, c.account_number, c.first_name, c.last_name, c.meter_number,
               c.purok, c.barangay, c.address, c.route_sequence,
               mr.name AS reader_name,
               r.current_reading AS present_reading,
               COALESCE(
                   (SELECT pr.current_reading FROM readings pr
                    WHERE pr.consumer_id = c.id AND pr.reading_period < :period1
                    ORDER BY pr.reading_period DESC LIMIT 1),
                   c.meter_initial_reading
               ) AS previous_reading
        FROM consumers c
        LEFT JOIN readings r ON r.consumer_id = c.id AND r.reading_period = :period2
        LEFT JOIN meter_readers mr ON mr.id = c.default_meter_reader_id
        WHERE $where
    ) t
    ORDER BY $orderBy
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$muniName = get_setting($pdo, 'municipality_name', 'Municipality');
$officeName = get_setting($pdo, 'office_name', 'Water Works Office');

$readerLabel = '';
if ($readerFilter === 'none') {
    $readerLabel = 'Unassigned Consumers';
} elseif ($readerFilter !== '') {
    $stmt2 = $pdo->prepare("SELECT name FROM meter_readers WHERE id = :id");
    $stmt2->execute(['id' => $readerFilter]);
    $readerLabel = $stmt2->fetchColumn() ?: '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Meter Reading Sheet — <?= h(billing_month_label($periodDate)) ?></title>
<link rel="stylesheet" href="../assets/css/fonts.css?v=<?= asset_v('assets/css/fonts.css') ?>">
<link rel="stylesheet" href="../assets/css/style.css?v=<?= asset_v('assets/css/style.css') ?>">
<style>
  body { background:#fff; }
  .sheet { max-width: 1000px; margin: 0 auto; padding: 20px 10px; }
  table.sheet-table { width:100%; border-collapse: collapse; font-size: 12.5px; }
  table.sheet-table th, table.sheet-table td { border: 1px solid #ccc; padding: 6px 8px; }
  table.sheet-table th { background: #f3f5f7; text-align:left; }
  .fill-line { display:inline-block; min-width: 60px; border-bottom: 1px solid #333; }
</style>
</head>
<body>
<div class="sheet">
  <div class="no-print" style="text-align:right; margin-bottom:14px;">
    <button onclick="window.print()" class="btn btn-primary">🖨️ Print</button>
    <a href="grid.php?period=<?= h($period) ?>&reader=<?= h($readerFilter) ?>" class="btn btn-outline">Back</a>
  </div>

  <div class="print-header">
    <img src="../assets/logo/seal.png" alt="<?= h($muniName) ?> Seal" class="print-header-logo print-header-logo-left" width="76" height="76">
    <img src="../assets/logo/watersystem.png" alt="Water System Logo" class="print-header-logo print-header-logo-right" width="76" height="76">
    <div class="print-header-text">
      <h2><?= h($muniName) ?></h2>
      <div><?= h($officeName) ?></div>
      <h3 style="margin-top:10px;">Meter Reading Sheet — Billing Month: <?= h(billing_month_label($periodDate)) ?> <span style="font-weight:400;">(readings <?= h(reading_range_hint($periodDate)) ?>)</span></h3>
      <?php if ($readerLabel): ?><div class="text-muted">Reader: <strong><?= h($readerLabel) ?></strong></div><?php endif; ?>
    </div>
  </div>

  <div class="bill-meta-grid" style="margin-bottom:14px;">
    <div>Meter Reader: <span class="fill-line" style="min-width:220px;"><?= h($readerLabel) ?>&nbsp;</span></div>
    <div>Date: <span class="fill-line" style="min-width:150px;">&nbsp;</span></div>
  </div>

  <table class="sheet-table">
    <thead>
      <tr>
        <th>#</th>
        <th>Account #</th>
        <th>Consumer Name</th>
        <th>Meter #</th>
        <th>Address</th>
        <?php if ($readerFilter === ''): ?><th>Reader</th><?php endif; ?>
        <th>Previous</th>
        <th>Present</th>
        <th>Cu.M. Used</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= $r['route_sequence'] !== null ? (int)$r['route_sequence'] : '' ?></td>
        <td><?= h($r['account_number']) ?></td>
        <td><?= h($r['last_name'] . ', ' . $r['first_name']) ?></td>
        <td><?= h($r['meter_number'] ?: '—') ?></td>
        <td><?= h(format_consumer_address($r)) ?></td>
        <?php if ($readerFilter === ''): ?><td><?= h($r['reader_name'] ?: '—') ?></td><?php endif; ?>
        <td><?= number_format($r['previous_reading'], 2) ?></td>
        <td><?= $r['present_reading'] !== null ? number_format($r['present_reading'], 2) : '' ?></td>
        <td><?= $r['consumption'] !== null ? number_format($r['consumption'], 2) : '' ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <p class="text-muted" style="font-size:11.5px; margin-top:16px;">
    Blank "Present" and "Cu.M. Used" cells mean the reading has not been encoded in the system yet.
    Field readers may fill this sheet by hand and the office will later encode it via Meter Readings → Grid.
  </p>
</div>
  <script>
    // This page is opened in its own tab just to print — close it
    // automatically once the print dialog closes so tabs don't pile up.
    window.addEventListener('afterprint', function () {
      if (window.opener) { window.close(); }
    });
  </script>
</body>
</html>
